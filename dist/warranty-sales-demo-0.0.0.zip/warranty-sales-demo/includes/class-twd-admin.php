<?php
if (!defined('ABSPATH')) exit;

/**
 * Company back office, rendered inside the standalone admin app (see TWD_App):
 * dashboard, warranties, serials (single + bulk import), notifications log, team, settings.
 * Forms post back to the app URL with an `action` field; TWD_App::route_admin() dispatches to handle_*().
 */
final class TWD_Admin {
    const PER_PAGE = 50;

    const CAP = 'twd_manage';

    public static function cap() {
        return apply_filters('twd_capability', self::CAP);
    }

    /** Actions accepted by the app router (POST, or GET for downloads). */
    public static function actions() {
        return ['import', 'add_serial', 'serial_status', 'serial_batch', 'record_service', 'delete_service', 'set_status', 'invoice', 'export',
            'save_settings', 'run_now', 'resend_activation', 'anonymize', 'test_message', 'terms_view', 'team_add', 'team_remove', 'process_erasure', 'template', 'review_service', 'receipt', 'brevo_tool', 'backup_create', 'backup_download', 'backup_delete', 'backup_restore', 'backup_settings',
            'backup_send', 'remote_settings', 'remote_connect', 'remote_disconnect', 'remote_test', 'edit_customer', 'log_export', 'log_verify', 'log_archive', 'log_archive_settings', 'partner_save', 'partner_delete', 'partner_import', 'partner_export', 'terms_save', 'terms_assign', 'terms_delete', 'terms_pdf_draft', 'claim_update', 'claim_file'];
    }

    /** Screens of the admin app: key => [label, dashicon-like glyph, callback]. */
    public static function screens() {
        $screens = [
            'dashboard' => ['Επισκόπηση', 'dashboard', 'page_dashboard'],
            'warranties' => ['Εγγυήσεις & πελάτες', 'shield', 'page_warranties'],
            'serials' => ['Σειριακοί αριθμοί', 'barcode', 'page_serials'],
            'notifications' => ['Ειδοποιήσεις', 'bell', 'page_notifications'],
            'claims' => ['Αιτήματα εγγύησης', 'wrench', 'page_claims'],
            'terms' => ['Όροι εγγύησης', 'file', 'page_terms'],
            'partners' => ['Συνεργάτες', 'pin', 'page_partners'],
        ];
        if (self::can_admin()) {
            $screens['team'] = ['Ομάδα', 'users', 'page_team'];
            $screens['backups'] = ['Αντίγραφα ασφαλείας', 'database', 'page_backups'];
            $screens['log'] = ['Ημερολόγιο', 'scroll', 'page_log'];
        }
        $screens['settings'] = ['Ρυθμίσεις', 'settings', 'page_settings'];
        $screens['help'] = ['Οδηγός χρήσης', 'book', 'page_help'];
        $screens['changelog'] = ['Ιστορικό εκδόσεων', 'history', 'page_changelog'];
        return $screens;
    }

    /**
     * Side menu: single items and collapsible groups (only the screens this user can open).
     * @return array list of ['key' => screen] or ['group' => id, 'label', 'icon', 'items' => [keys]]
     */
    public static function nav() {
        $screens = self::screens();
        $groups = [
            'manage' => ['Διαχείριση εγγυήσεων', 'layers', ['warranties', 'serials', 'claims', 'terms']],
            'ops' => ['Λειτουργία & ασφάλεια', 'lock', ['notifications', 'team', 'backups', 'log', 'settings']],
        ];
        $order = ['dashboard', 'manage', 'partners', 'ops', 'help', 'changelog'];
        $out = [];
        foreach ($order as $k) {
            if (isset($groups[$k])) {
                $items = array_values(array_filter($groups[$k][2], function ($x) use ($screens) { return isset($screens[$x]); }));
                if ($items) $out[] = ['group' => $k, 'label' => $groups[$k][0], 'icon' => $groups[$k][1], 'items' => $items];
            } elseif (isset($screens[$k])) {
                $out[] = ['key' => $k];
            }
        }
        // Screens not placed above (e.g. added later) still appear, at the end.
        $placed = [];
        foreach ($out as $o) $placed = array_merge($placed, isset($o['items']) ? $o['items'] : [$o['key']]);
        foreach (array_diff(array_keys($screens), $placed) as $k) $out[] = ['key' => $k];
        return $out;
    }

    /** Unread counts for the menu: claims nobody opened, problem notifications nobody looked at. */
    public static function badges() {
        return array_filter([
            'claims' => TWD_Claims::count_unseen(),
            'notifications' => self::notifications_unseen(),
        ]);
    }

    /** Notifications that failed or were not delivered, not yet seen on the Ειδοποιήσεις screen. */
    private static function problem_sql() {
        return "(status = 'failed' OR delivery_status IN ('failed','complaint'))";
    }

    public static function notifications_unseen() {
        global $wpdb;
        return (int) $wpdb->get_var('SELECT COUNT(*) FROM ' . TWD_DB::table('notifications') . ' WHERE seen_at IS NULL AND ' . self::problem_sql());
    }

    /**
     * Line icons for the console (24×24, 1.75 stroke, currentColor), drawn after the Lucide icon set (ISC licence).
     */
    public static function icon($name) {
        $paths = [
            'dashboard' => '<rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/>',
            'shield' => '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
            'barcode' => '<path d="M3 7V5a2 2 0 0 1 2-2h2"/><path d="M17 3h2a2 2 0 0 1 2 2v2"/><path d="M21 17v2a2 2 0 0 1-2 2h-2"/><path d="M7 21H5a2 2 0 0 1-2-2v-2"/><path d="M8 7v10"/><path d="M12 7v10"/><path d="M17 7v10"/>',
            'bell' => '<path d="M10.268 21a2 2 0 0 0 3.464 0"/><path d="M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326"/>',
            'users' => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
            'database' => '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14a9 3 0 0 0 18 0V5"/><path d="M3 12a9 3 0 0 0 18 0"/>',
            'settings' => '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
            'logout' => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
            'menu' => '<path d="M4 6h16"/><path d="M4 12h16"/><path d="M4 18h16"/>',
            'refresh' => '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
            'clock' => '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
            'download' => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/>',
            'printer' => '<path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6"/><rect x="6" y="14" width="12" height="8" rx="1"/>',
            'cloud' => '<path d="M12 13v8"/><path d="M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242"/><path d="m8 17 4-4 4 4"/>',
            'plus' => '<path d="M5 12h14"/><path d="M12 5v14"/>',
            'upload' => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m17 8-5-5-5 5"/><path d="M12 3v12"/>',
            'scroll' => '<path d="M15 12h-5"/><path d="M15 8h-5"/><path d="M19 17V5a2 2 0 0 0-2-2H4"/><path d="M8 21h12a2 2 0 0 0 2-2v-1a1 1 0 0 0-1-1H11a1 1 0 0 0-1 1v1a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v2a1 1 0 0 0 1 1h3"/>',
            'history' => '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>',
            'wrench' => '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>',
            'layers' => '<path d="M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/><path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/>',
            'lock' => '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
            'chevron' => '<path d="m6 9 6 6 6-6"/>',
            'file' => '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/>',
            'pin' => '<path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/>',
            'book' => '<path d="M12 7v14"/><path d="M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z"/>',
        ];
        if (!isset($paths[$name])) return '';
        return '<svg class="tw-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $paths[$name] . '</svg>';
    }

    /** Platform administrators: WordPress admins and team members with team management rights. */
    public static function can_admin() {
        return current_user_can('manage_options') || current_user_can('twd_manage_team');
    }

    /** wp-admin only gets a launcher that opens the standalone app. */
    public static function init() {
        // The mark has fine detail: show it a little larger than WordPress' 20px menu icons.
        add_action('admin_head', function () {
            echo '<style>#adminmenu #toplevel_page_tw-app .wp-menu-image{background-size:26px auto!important;background-position:center!important;opacity:1}'
                . '#adminmenu #toplevel_page_tw-app .wp-menu-name{white-space:nowrap}</style>';
        });
        // Open the standalone app in a new tab straight from the wp-admin menu.
        add_action('admin_footer', function () {
            if (!current_user_can(self::cap())) return;
            echo '<script>(function(){document.querySelectorAll("#toplevel_page_tw-app > a, #toplevel_page_tw-app .wp-submenu a[href$=\'page=tw-app\']").forEach(function(a){'
                . 'a.href=' . wp_json_encode(TWD_App::admin_url()) . ';a.target="_blank";a.rel="noopener";});})();</script>';
        });
        add_action('admin_menu', function () {
            $hook = add_menu_page(TWD_App::APP_NAME, TWD_App::APP_NAME, self::cap(), 'tw-app', '__return_null', TWD_App::menu_icon(), 56);
            add_action('load-' . $hook, function () {
                wp_safe_redirect(TWD_App::admin_url());
                exit;
            });
        });
    }

    public static function url($screen = 'dashboard', array $args = []) {
        return TWD_App::admin_url($screen, $args);
    }

    // ------------------------------------------------------------------ helpers

    public static function guard($action) {
        if (!current_user_can(self::cap())) wp_die('Δεν έχετε δικαίωμα πρόσβασης.', 403);
        check_admin_referer($action);
    }

    public static function back($page, array $args = []) {
        wp_safe_redirect(self::url(preg_replace('/^tw-/', '', $page), array_filter($args, function ($v) { return $v !== null; })));
        exit;
    }

    /** Hidden inputs so GET filter forms stay inside the app. */
    public static function get_form_fields($screen) {
        foreach (TWD_App::admin_base_query() as $k => $v) {
            echo '<input type="hidden" name="' . esc_attr($k) . '" value="' . esc_attr($v) . '">';
        }
        echo '<input type="hidden" name="screen" value="' . esc_attr($screen) . '">';
    }

    public static function post($k) {
        return isset($_POST[$k]) ? trim(wp_unslash((string) $_POST[$k])) : '';
    }

    public static function q($k) {
        return isset($_GET[$k]) ? sanitize_text_field(wp_unslash((string) $_GET[$k])) : '';
    }

    public static function notice() {
        $msg = get_transient('twd_notice_' . get_current_user_id());
        if (!$msg) return;
        delete_transient('twd_notice_' . get_current_user_id());
        printf('<div class="notice notice-%s is-dismissible"><p>%s</p></div>', esc_attr($msg['type']), wp_kses_post($msg['text']));
    }

    public static function flash($text, $type = 'success') {
        set_transient('twd_notice_' . get_current_user_id(), ['text' => $text, 'type' => $type], 120);
    }

    public static function pagination($total, $paged) {
        $pages = (int) ceil($total / self::PER_PAGE);
        if ($pages <= 1) return;
        echo '<div class="tablenav"><div class="tablenav-pages"><span class="displaying-num">' . (int) $total . ' εγγραφές</span> ';
        echo paginate_links(['base' => add_query_arg('paged', '%#%'), 'format' => '', 'current' => $paged, 'total' => $pages, 'prev_text' => '« Προηγούμενη', 'next_text' => 'Επόμενη »']);
        echo '</div></div>';
    }

    private static function status_badge($status, $labels) {
        return '<span class="tw-badge tw-badge--' . esc_attr($status) . '">' . esc_html($labels[$status] ?? $status) . '</span>';
    }

    /** Latest delivery result per channel says the customer's email / mobile does not receive messages. */
    public static function contact_problems($w) {
        global $wpdb;
        $out = [];
        foreach (['email' => [$w->email, 'Το email του πελάτη (%s) απορρίπτει τα μηνύματα: %s. Ο πελάτης δεν λαμβάνει ειδοποιήσεις με email – επικοινωνήστε μαζί του για διόρθωση.'],
                  'sms' => [$w->phone_mobile, 'Τα SMS προς το κινητό του πελάτη (%s) δεν παραδίδονται: %s.']] as $ch => $def) {
            $last = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM " . TWD_DB::table('notifications') . " WHERE warranty_id = %d AND channel = %s AND recipient = %s AND delivery_status NOT IN ('', 'sent') ORDER BY id DESC LIMIT 1",
                $w->id, $ch, $def[0]));
            if ($last && in_array($last->delivery_status, ['failed', 'complaint'], true)) {
                $out[] = sprintf($def[1], $def[0], $last->delivery_detail ?: TWD_Brevo::status_labels()[$last->delivery_status]);
            }
        }
        return $out;
    }

    /** History in plain Greek instead of internal codes. */
    public static function event_label($action) {
        $map = [
            'activated' => 'Ενεργοποίηση εγγύησης', 'otp_sent' => 'Αποστολή κωδικού επαλήθευσης', 'otp_email_failed' => 'Αποτυχία email κωδικού',
            'activation_email_sent' => 'Email επιβεβαίωσης ενεργοποίησης', 'activation_email_failed' => 'Αποτυχία email επιβεβαίωσης', 'activation_email_resent' => 'Επαναποστολή email επιβεβαίωσης',
            'activation_sms_sent' => 'SMS επιβεβαίωσης ενεργοποίησης', 'activation_sms_failed' => 'Αποτυχία SMS επιβεβαίωσης',
            'portal_login' => 'Σύνδεση πελάτη στην πύλη', 'portal_data_export' => 'Λήψη δεδομένων (JSON) από τον πελάτη', 'portal_data_copy' => 'Αντίγραφο στοιχείων από τον πελάτη',
            'marketing_granted' => 'Συγκατάθεση για ενημερώσεις', 'marketing_withdrawn' => 'Ανάκληση συγκατάθεσης για ενημερώσεις',
            'service_submitted' => 'Υποβολή Service από τον πελάτη', 'service_recorded' => 'Καταχώρηση Service από την εταιρεία', 'service_approved' => 'Service: ελέγχθηκε',
            'service_rejected' => 'Service: απορρίφθηκε', 'service_deleted' => 'Διαγραφή καταχώρησης Service', 'receipt_downloaded' => 'Προβολή απόδειξης Service',
            'invoice_downloaded' => 'Προβολή παραστατικού αγοράς', 'card_printed' => 'Εκτύπωση καρτέλας', 'staff_login' => 'Σύνδεση στο διαχειριστικό', 'locked' => 'Οριστικό κλείδωμα', 'status_active' => 'Κατάσταση: Ενεργή', 'status_expired' => 'Κατάσταση: Έληξε',
            'status_void' => 'Κατάσταση: Ακυρωμένη', 'status_locked' => 'Κατάσταση: Κλειδωμένη', 'customer_corrected' => 'Διόρθωση στοιχείων πελάτη', 'anonymized' => 'Ανωνυμοποίηση στοιχείων',
            'email_undeliverable' => 'Το email δεν παραδόθηκε', 'sms_undeliverable' => 'Το SMS δεν παραδόθηκε', 'fallback_sent' => 'Αποστολή από εναλλακτικό κανάλι',
            'warranty_viewed' => 'Προβολή καρτέλας από την ομάδα', 'language_changed' => 'Αλλαγή γλώσσας επικοινωνίας',
            'erasure_requested' => 'Αίτημα διαγραφής από τον πελάτη', 'erasure_processed' => 'Εκτέλεση αιτήματος διαγραφής',
        ];
        return $map[$action] ?? $action;
    }

    public static function actor_label($actor) {
        if ($actor === 'system' || strpos($actor, 'system:') === 0) return 'Σύστημα';
        if (strpos($actor, 'customer:') === 0) return 'Πελάτης (' . substr($actor, 9) . ')';
        if (strpos($actor, 'admin:') === 0) {
            $u = get_user_by('login', substr($actor, 6));
            return $u ? $u->display_name : substr($actor, 6);
        }
        return $actor;
    }

    public static function event_details($details) {
        $d = json_decode((string) $details, true);
        if (!is_array($d)) return (string) $details;
        $names = ['note' => 'Αιτιολογία', 'milestone' => 'Service', 'date' => 'Ημερομηνία', 'technician_vat' => 'ΑΦΜ τεχνικού', 'warranty_code' => 'Κωδικός',
            'terms_version' => 'Όροι έκδοσης', 'email' => 'Email', 'by' => 'Από', 'genuine_parts' => 'Γνήσια ανταλλακτικά', 'to' => 'Παραλήπτης', 'reason' => 'Λόγος',
            'step' => 'Βήμα', 'after_failed' => 'Μετά από αποτυχία', 'source' => 'Πηγή', 'customer_name' => 'Ονοματεπώνυμο', 'phone_mobile' => 'Κινητό',
            'phone_landline' => 'Σταθερό', 'address' => 'Διεύθυνση', 'postcode' => 'Τ.Κ.', 'city' => 'Πόλη', 'changed' => 'Αλλαγές', 'lang' => 'Γλώσσα', 'partner_country' => 'Χώρα συνεργάτη', 'partner_vat' => 'ΑΦΜ συνεργάτη',
            'partner_email' => 'Email συνεργάτη', 'invoice_number' => 'Αριθμός παραστατικού'];
        $out = [];
        foreach ($d as $k => $v) {
            if ($k === 'changes' && is_array($v)) {
                foreach ($v as $field => $ch) $out[] = ($names[$field] ?? $field) . ': ' . (($ch['από'] ?? '') !== '' ? $ch['από'] : '—') . ' → ' . (($ch['σε'] ?? '') !== '' ? $ch['σε'] : '—');
                continue;
            }
            if ($v === '' || $v === null) continue;
            if ($k === 'genuine_parts') $v = $v ? 'ναι' : 'όχι';
            if ($k === 'milestone') $v = (int) $v . 'ο';
            if ($k === 'date' && preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) $v)) $v = TWD_Util::date_label($v);
            if ($k === 'source') $v = ['portal' => '«Οι εγγυήσεις μου»', 'registration' => 'ενεργοποίηση (ισχύει για όλα τα προϊόντα του πελάτη)', 'inherited' => 'ενεργοποίηση – ισχύουσα συγκατάθεση του πελάτη', 'erasure_request' => 'αίτημα διαγραφής'][$v] ?? $v;
            if ($k === 'by') $v = ['partner' => 'συνεργάτη', 'thermic' => 'εταιρεία', 'customer' => 'πελάτη'][$v] ?? $v;
            $out[] = ($names[$k] ?? $k) . ': ' . (is_scalar($v) ? $v : wp_json_encode($v, JSON_UNESCAPED_UNICODE));
        }
        return implode(' · ', $out);
    }

    private static function select_row($key, $label, $current, array $options, $desc = '') {
        echo '<tr><th><label for="tw-' . esc_attr($key) . '">' . esc_html($label) . '</label></th><td><select id="tw-' . esc_attr($key) . '" name="s[' . esc_attr($key) . ']">';
        foreach ($options as $v => $l) printf('<option value="%s"%s>%s</option>', esc_attr($v), selected($current, $v, false), esc_html($l));
        echo '</select>';
        if ($desc) echo '<p class="description">' . esc_html($desc) . '</p>';
        echo '</td></tr>';
    }

    private static function receipt_url($w, $sv) {
        return wp_nonce_url(add_query_arg(['action' => 'twd_receipt', 'id' => (int) $w->id, 'service_id' => (int) $sv->id], self::url()), 'twd_receipt');
    }

    private static function warranty_link($id, $text) {
        return '<a href="' . esc_url(self::url('warranties', ['view' => (int) $id])) . '">' . esc_html($text) . '</a>';
    }

    // ------------------------------------------------------------------ dashboard

    /**
     * Upcoming / overdue Service across active warranties up to $horizon (the schedule is computed, not stored).
     * @return array of ['w' => warranty row, 'm' => milestone]
     */
    public static function upcoming_services($today, $horizon) {
        global $wpdb;
        $upcoming = [];
        // Only warranties that can have a Service in the window are read (purchase dates that put a Service
        // between "lock period ago" and the horizon, plus rejected submissions still open), then checked exactly.
        $interval = (int) TWD_Settings::get('service_interval_years');
        $years = max(1, (int) TWD_Settings::get('warranty_years'));
        $from = TWD_Schedule::add_days($today, -max(0, (int) TWD_Settings::get('lock_offset')) - 1);
        $ranges = []; $params = [];
        for ($k = 1; $interval > 0 && $k * $interval < $years; $k++) {
            $ranges[] = '(w.purchase_date BETWEEN %s AND %s)';
            $params[] = TWD_Schedule::add_years($from, -$k * $interval);
            $params[] = TWD_Schedule::add_years(TWD_Schedule::add_days($horizon, 1), -$k * $interval);
        }
        $sv_table = TWD_DB::table('services');
        $rejected = "w.id IN (SELECT warranty_id FROM $sv_table WHERE review_status = 'rejected' AND resubmit_until >= " . $wpdb->prepare('%s', $today) . ')';
        $cond = $ranges ? '(' . implode(' OR ', $ranges) . ' OR ' . $rejected . ')' : $rejected;
        $cands = $wpdb->get_results($params ? $wpdb->prepare(TWD_Warranty::select_sql() . " WHERE w.status = 'active' AND $cond", $params) : TWD_Warranty::select_sql() . " WHERE w.status = 'active' AND $cond");
        TWD_Warranty::preload_services(array_map(function ($r) { return (int) $r->id; }, $cands));
        foreach ($cands as $row) {
            foreach (TWD_Warranty::timeline($row) as $m) {
                if ($m['type'] === 'service' && in_array($m['state'], ['upcoming', 'due', 'rejected'], true) && $m['due'] <= $horizon) {
                    $upcoming[] = ['w' => $row, 'm' => $m];
                }
            }
        }
        return $upcoming;
    }

    public static function page_dashboard() {
        global $wpdb;
        $s = TWD_DB::table('serials');
        $w = TWD_DB::table('warranties');
        $today = TWD_Schedule::today();
        $serial_counts = $wpdb->get_results("SELECT status, COUNT(*) n FROM $s GROUP BY status", OBJECT_K);
        $w_counts = $wpdb->get_results("SELECT status, COUNT(*) n FROM $w GROUP BY status", OBJECT_K);
        $n = function ($arr, $k) { return isset($arr[$k]) ? (int) $arr[$k]->n : 0; };
        $exp60 = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $w WHERE status = 'active' AND warranty_end BETWEEN %s AND %s", $today, TWD_Schedule::add_days($today, 60)));
        $last30 = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $w WHERE created_at >= %s", TWD_Schedule::add_days($today, -30) . ' 00:00:00'));

        $upcoming = self::upcoming_services($today, TWD_Schedule::add_days($today, 60));
        usort($upcoming, function ($a, $b) { return strcmp($a['m']['due'], $b['m']['due']); });
        $recent = $wpdb->get_results(TWD_Warranty::select_sql() . " ORDER BY w.created_at DESC LIMIT 10");
        $sv_t = TWD_DB::table('services');
        $recent_sv = $wpdb->get_results($wpdb->prepare("SELECT * FROM $sv_t WHERE source = 'customer' AND created_at >= %s ORDER BY id DESC LIMIT 50", TWD_Schedule::add_days($today, -30) . ' 00:00:00'));
        $last = get_option('twd_last_run');
        $labels = TWD_Util::status_labels();
        ?>
        <div class="wrap tw-wrap">
            <h1>Εγγυήσεις – Επισκόπηση</h1>
            <?php self::notice(); ?>
            <form method="get" class="tw-filters tw-lookup">
                <?php self::get_form_fields('warranties'); ?>
                <label for="tw-lookup"><strong>Αναζήτηση εγγύησης</strong></label>
                <input type="search" id="tw-lookup" name="s" placeholder="Σειριακός αριθμός, κωδικός εγγύησης, email ή τηλέφωνο" size="44" autofocus>
                <button class="button button-primary">Άνοιγμα καρτέλας</button>
            </form>
            <div class="tw-cards">
                <div class="tw-stat"><span><?php echo $n($serial_counts, 'available') + $n($serial_counts, 'registered') + $n($serial_counts, 'void'); ?></span>Σειριακοί στο σύστημα</div>
                <div class="tw-stat"><span><?php echo $n($serial_counts, 'available'); ?></span>Διαθέσιμοι (μη ενεργοποιημένοι)</div>
                <div class="tw-stat tw-stat--ok"><span><?php echo $n($w_counts, 'active'); ?></span>Ενεργές εγγυήσεις</div>
                <div class="tw-stat"><span><?php echo $n($w_counts, 'expired'); ?></span>Έληξαν</div>
                <div class="tw-stat tw-stat--bad"><span><?php echo $n($w_counts, 'locked'); ?></span>Οριστικά κλειδωμένες</div>
                <div class="tw-stat tw-stat--warn"><span><?php echo $exp60; ?></span>Λήγουν σε 60 ημέρες</div>
                <div class="tw-stat"><span><?php echo $last30; ?></span>Ενεργοποιήσεις 30 ημερών</div>
                <div class="tw-stat"><span><?php echo count($recent_sv); ?></span>Υποβολές Service 30 ημερών</div>
            </div>
            <?php $nx_check = wp_next_scheduled(TWD_Cron::HOOK); if ($nx_check && $nx_check < time() - 2 * HOUR_IN_SECONDS) : ?>
                <div class="notice notice-error"><p><strong>Οι αυτόματες εργασίες καθυστερούν</strong> (ο έλεγχος των <?php echo esc_html(wp_date('d/m H:i', $nx_check)); ?> δεν έχει γίνει): υπενθυμίσεις, αναφορές και αντίγραφα μπορεί να μη στέλνονται. Δείτε <a href="<?php echo esc_url(self::url('help')); ?>#cron">Οδηγός χρήσης → Αυτόματες εργασίες (cron)</a>.</p></div>
            <?php endif; ?>
            <p class="description">Τελευταία εκτέλεση ειδοποιήσεων: <?php echo $last ? esc_html(TWD_Util::datetime_label($last['at']) . ' – ' . (int) $last['count'] . ' ενέργειες') : 'καμία ακόμη'; ?>.
                Επόμενη: <?php $nx = wp_next_scheduled(TWD_Cron::HOOK); echo $nx ? esc_html(wp_date('d/m/Y H:i', $nx)) : '—'; ?>.</p>

            <h2>Πρόσφατες υποβολές Service από πελάτες (30 ημέρες)</h2>
            <table class="widefat striped"><thead><tr><th>Καταχώρηση</th><th>S/N</th><th>Πελάτης</th><th>Service</th><th>Ημ/νία Service</th><th>ΑΦΜ τεχνικού</th><th>Απόδειξη</th></tr></thead><tbody>
            <?php if (!$recent_sv) echo '<tr><td colspan="7">Καμία υποβολή τις τελευταίες 30 ημέρες.</td></tr>'; ?>
            <?php foreach ($recent_sv as $sv) : $pw = TWD_Warranty::get($sv->warranty_id); if (!$pw) continue; ?>
                <tr><td><?php echo esc_html(TWD_Util::datetime_label($sv->created_at)); ?></td><td><?php echo self::warranty_link($pw->id, $pw->serial); ?></td>
                    <td><?php echo esc_html($pw->customer_name); ?></td><td><?php echo (int) $sv->milestone_no; ?>ο</td>
                    <td><?php echo esc_html(TWD_Util::date_label($sv->performed_date)); ?></td><td><code><?php echo esc_html($sv->technician_vat); ?></code></td>
                    <td><?php echo esc_html($sv->receipt_number ? 'αρ. ' . $sv->receipt_number . ($sv->receipt_date ? ' / ' . TWD_Util::date_label($sv->receipt_date) : '') : ''); ?>
                        <?php echo $sv->receipt_file ? '<a href="' . esc_url(self::receipt_url($pw, $sv)) . '" target="_blank">Αρχείο</a>' : ''; ?><?php echo !$sv->receipt_number && !$sv->receipt_file ? '—' : ''; ?></td></tr>
            <?php endforeach; ?>
            </tbody></table>

            <h2>Service σε εκκρεμότητα ή τις επόμενες 60 ημέρες (<?php echo count($upcoming); ?>)</h2>
            <table class="widefat striped"><thead><tr><th>Ημ/νία Service</th><th>Ορόσημο</th><th>S/N</th><th>Πελάτης</th><th>Κινητό</th><th>Συνεργάτης</th><th>Κατάσταση</th></tr></thead><tbody>
            <?php if (!$upcoming) echo '<tr><td colspan="7">Καμία εκκρεμότητα.</td></tr>'; ?>
            <?php foreach (array_slice($upcoming, 0, 100) as $u) : $row = $u['w']; $m = $u['m']; ?>
                <tr><td><?php echo esc_html(TWD_Util::date_label($m['due'])); ?></td><td><?php echo (int) $m['no']; ?>ο (<?php echo (int) $m['years']; ?> έτη)</td>
                    <td><?php echo self::warranty_link($row->id, $row->serial); ?></td><td><?php echo esc_html($row->customer_name); ?></td>
                    <td><?php echo esc_html($row->phone_mobile); ?></td><td><?php echo esc_html($row->partner_vat . ' ' . $row->partner_email); ?></td>
                    <td><?php echo $m['state'] === 'due' ? '<strong class="tw-warn">Εκκρεμεί – κλείδωμα ' . esc_html(TWD_Util::date_label($m['lock_date'])) . '</strong>' : 'Προσεχώς'; ?></td></tr>
            <?php endforeach; ?>
            </tbody></table>

            <h2>Πρόσφατες ενεργοποιήσεις</h2>
            <table class="widefat striped"><thead><tr><th>Ημερομηνία</th><th>Κωδικός</th><th>S/N</th><th>Προϊόν</th><th>Πελάτης</th><th>Κατάσταση</th></tr></thead><tbody>
            <?php if (!$recent) echo '<tr><td colspan="6">Καμία ακόμη.</td></tr>'; ?>
            <?php foreach ($recent as $row) : ?>
                <tr><td><?php echo esc_html(TWD_Util::datetime_label($row->created_at)); ?></td><td><?php echo self::warranty_link($row->id, $row->warranty_code); ?></td>
                    <td><?php echo esc_html($row->serial); ?></td><td><?php echo esc_html($row->product_name); ?></td><td><?php echo esc_html($row->customer_name); ?></td>
                    <td><?php echo self::status_badge($row->status, $labels); ?></td></tr>
            <?php endforeach; ?>
            </tbody></table>
        </div>
        <?php
    }

    // ------------------------------------------------------------------ warranties

    /** WHERE clause shared by the list and the CSV export. */
    private static function warranty_filters(array $args) {
        global $wpdb;
        $where = ['1=1'];
        $params = [];
        if (!empty($args['s'])) {
            $like = '%' . $wpdb->esc_like($args['s']) . '%';
            $where[] = '(s.serial_no LIKE %s OR w.warranty_code LIKE %s OR w.customer_name LIKE %s OR w.email LIKE %s OR w.phone_mobile LIKE %s OR w.phone_landline LIKE %s OR w.partner_vat LIKE %s OR w.partner_email LIKE %s OR w.invoice_number LIKE %s OR s.product_name LIKE %s OR s.product_code LIKE %s OR w.postcode LIKE %s)';
            $params = array_merge($params, array_fill(0, 12, $like));
        }
        if (!empty($args['status']) && isset(TWD_Util::status_labels()[$args['status']])) {
            $where[] = 'w.status = %s';
            $params[] = $args['status'];
        }
        if (!empty($args['expiring'])) {
            $where[] = "w.status = 'active' AND w.warranty_end BETWEEN %s AND %s";
            $params[] = TWD_Schedule::today();
            $params[] = TWD_Schedule::add_days(TWD_Schedule::today(), (int) $args['expiring']);
        }
        if (!empty($args['from'])) { $where[] = 'w.purchase_date >= %s'; $params[] = $args['from']; }
        if (!empty($args['to'])) { $where[] = 'w.purchase_date <= %s'; $params[] = $args['to']; }
        $sql = implode(' AND ', $where);
        return $params ? $wpdb->prepare($sql, $params) : $sql;
    }

    /** Exact serial / warranty code from a search opens the card directly. Called by the router before output. */
    public static function maybe_open_exact() {
        global $wpdb;
        if (($_GET['screen'] ?? '') !== 'warranties' || !empty($_GET['view']) || empty($_GET['s'])) return;
        $q = trim(sanitize_text_field(wp_unslash($_GET['s'])));
        $id = $wpdb->get_var($wpdb->prepare(
            "SELECT w.id FROM " . TWD_DB::table('warranties') . " w JOIN " . TWD_DB::table('serials') . " s ON s.id = w.serial_id WHERE s.serial_no = %s OR w.warranty_code = %s LIMIT 1",
            TWD_Util::normalize_serial($q), strtoupper($q)
        ));
        if ($id) {
            wp_safe_redirect(self::url('warranties', ['view' => (int) $id]));
            exit;
        }
        // A serial that exists but was never activated: say so on the serials screen.
        $serial = TWD_Warranty::find_serial($q);
        if ($serial) {
            self::flash(sprintf('Ο σειριακός %s υπάρχει αλλά δεν έχει ενεργοποιηθεί εγγύηση (%s).', esc_html($serial->serial), esc_html(TWD_Util::serial_status_labels()[$serial->status] ?? $serial->status)), 'warning');
            wp_safe_redirect(self::url('serials', ['s' => $serial->serial]));
            exit;
        }
    }

    public static function page_warranties() {
        if (!empty($_GET['view'])) {
            // Who looked at a customer's card (once per person and card every 30 minutes).
            $vk = 'twd_viewed_' . get_current_user_id() . '_' . (int) $_GET['view'];
            if (!get_transient($vk) && ($vw = TWD_Warranty::get((int) $_GET['view']))) {
                set_transient($vk, 1, 30 * MINUTE_IN_SECONDS);
                TWD_DB::log_event('warranty_viewed', '', $vw->id, $vw->serial_id);
            }
            self::page_warranty((int) $_GET['view']);
            return;
        }
        global $wpdb;
        $args = ['s' => self::q('s'), 'status' => self::q('status'), 'expiring' => (int) self::q('expiring'), 'from' => self::q('from'), 'to' => self::q('to')];
        $where = self::warranty_filters($args);
        $paged = max(1, (int) self::q('paged'));
        $base = TWD_Warranty::select_sql() . " WHERE $where";
        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM (" . $base . ") x");
        $rows = $wpdb->get_results($base . ' ORDER BY w.created_at DESC LIMIT ' . self::PER_PAGE . ' OFFSET ' . (($paged - 1) * self::PER_PAGE));
        $labels = TWD_Util::status_labels();
        $export = wp_nonce_url(add_query_arg(array_merge(['action' => 'twd_export', 'type' => 'warranties'], array_filter($args)), self::url('warranties')), 'twd_export');
        ?>
        <div class="wrap tw-wrap">
            <h1 class="wp-heading-inline">Εγγυήσεις &amp; πελάτες</h1>
            <?php self::export_button('warranties', $export, 'Εξαγωγή Excel (με τα τρέχοντα φίλτρα)'); ?>
            <?php self::notice(); ?>
            <form method="get" class="tw-filters">
                <?php self::get_form_fields('warranties'); ?>
                <input type="search" name="s" value="<?php echo esc_attr($args['s']); ?>" placeholder="S/N, κωδικός, όνομα, email, τηλέφωνο, ΑΦΜ…" size="40">
                <select name="status"><option value="">Όλες οι καταστάσεις</option>
                    <?php foreach ($labels as $k => $l) printf('<option value="%s"%s>%s</option>', esc_attr($k), selected($args['status'], $k, false), esc_html($l)); ?>
                </select>
                <select name="expiring"><option value="">Λήξη: οποτεδήποτε</option>
                    <?php foreach ([30, 60, 90, 180, 365] as $d) printf('<option value="%d"%s>Λήγουν σε %d ημέρες</option>', $d, selected($args['expiring'], $d, false), $d); ?>
                </select>
                <label>Αγορά από <input type="date" name="from" value="<?php echo esc_attr($args['from']); ?>"></label>
                <label>έως <input type="date" name="to" value="<?php echo esc_attr($args['to']); ?>"></label>
                <button class="button">Φίλτρο</button>
            </form>
            <?php self::pagination($total, $paged); ?>
            <table class="widefat striped"><thead><tr><th>Κωδικός εγγύησης</th><th>S/N</th><th>Προϊόν</th><th>Πελάτης</th><th>Email / Κινητό</th><th>Συνεργάτης ΑΦΜ</th><th>Αγορά</th><th>Λήξη</th><th>Κατάσταση</th></tr></thead><tbody>
            <?php if (!$rows) echo '<tr><td colspan="9">Δεν βρέθηκαν εγγυήσεις.</td></tr>'; ?>
            <?php foreach ($rows as $r) : ?>
                <tr><td><?php echo self::warranty_link($r->id, $r->warranty_code); ?></td><td><code><?php echo esc_html($r->serial); ?></code></td>
                    <td><?php echo esc_html($r->product_name); ?></td><td><?php echo esc_html($r->customer_name); ?></td>
                    <td><?php echo esc_html($r->email); ?><br><?php echo esc_html($r->phone_mobile); ?></td><td><?php echo esc_html($r->partner_vat); ?></td>
                    <td><?php echo esc_html(TWD_Util::date_label($r->purchase_date)); ?></td><td><?php echo esc_html(TWD_Util::date_label($r->warranty_end)); ?></td>
                    <td><?php echo self::status_badge($r->status, $labels); ?></td></tr>
            <?php endforeach; ?>
            </tbody></table>
            <?php self::pagination($total, $paged); ?>
        </div>
        <?php
    }

    private static function page_warranty($id) {
        global $wpdb;
        $w = TWD_Warranty::get($id);
        if (!$w) { echo '<div class="wrap"><p>Η εγγύηση δεν βρέθηκε.</p></div>'; return; }
        $labels = TWD_Util::status_labels();
        $timeline = TWD_Warranty::timeline($w);
        $consents = $wpdb->get_results($wpdb->prepare("SELECT * FROM " . TWD_DB::table('consents') . " WHERE warranty_id = %d ORDER BY id", $id));
        $notes = $wpdb->get_results($wpdb->prepare("SELECT * FROM " . TWD_DB::table('notifications') . " WHERE warranty_id = %d ORDER BY id DESC", $id));
        // The newest entries on the card; the full history is in the activity log (team managers).
        $events_total = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM " . TWD_DB::table('events') . " WHERE warranty_id = %d", $id));
        $events = $wpdb->get_results($wpdb->prepare("SELECT * FROM " . TWD_DB::table('events') . " WHERE warranty_id = %d ORDER BY id DESC LIMIT 200", $id));
        $post = self::url();
        $ms_labels = ['done' => 'Καταχωρήθηκε – ελέγχθηκε', 'due' => 'Εκκρεμεί καταχώρηση', 'missed' => 'Δεν καταχωρήθηκε', 'upcoming' => 'Προσεχώς', 'before_registration' => 'Πριν από την ενεργοποίηση', 'expired' => 'Έληξε', 'submitted' => 'Καταχωρήθηκε από τον πελάτη', 'rejected' => 'Απορρίφθηκε – αναμένεται νέα υποβολή'];
        $history = TWD_Warranty::services_history($w->id);
        $validity = TWD_Warranty::validity($w);
        $consent_labels = ['terms' => 'Όροι εγγύησης', 'data_accuracy' => 'Ορθότητα στοιχείων', 'marketing' => 'Εμπορικές ενημερώσεις'];
        ?>
        <div class="wrap tw-wrap">
            <p><a href="<?php echo esc_url(self::url('warranties')); ?>">&larr; Όλες οι εγγυήσεις</a></p>
            <h1>Εγγύηση <?php echo esc_html($w->warranty_code); ?> <?php echo self::status_badge($w->status, $labels); ?>
                <a class="page-title-action tw-no-print" href="<?php echo esc_url(self::url('warranties', ['view' => $w->id, 'print' => 1])); ?>" target="_blank" rel="noopener"><?php echo self::icon('printer'); ?>Εκτύπωση καρτέλας</a></h1>
            <?php self::notice(); ?>
            <?php foreach (self::contact_problems($w) as $problem) : ?>
                <div class="notice notice-warning inline"><p>⚠ <?php echo esc_html($problem); ?></p></div>
            <?php endforeach; ?>
            <div class="tw-validity tw-validity--<?php echo $validity['ok'] ? 'ok' : 'bad'; ?>">
                <strong><?php echo $validity['ok'] ? '✔' : '✘'; ?> <?php echo esc_html($validity['title']); ?></strong>
                <ul><?php foreach ($validity['lines'] as $l) echo '<li>' . esc_html($l) . '</li>'; ?></ul>
                <small>S/N <?php echo esc_html($w->serial); ?> · <?php echo esc_html($w->product_name); ?> · αγορά <?php echo esc_html(TWD_Util::date_label($w->purchase_date)); ?> · κατάσταση στις <?php echo esc_html(TWD_Util::datetime_label(TWD_DB::now())); ?></small>
            </div>
            <?php if ($w->status === 'locked') : ?><div class="notice notice-error inline"><p><strong>Οριστικά κλειδωμένη</strong> στις <?php echo esc_html(TWD_Util::datetime_label($w->locked_at)); ?>: <?php echo esc_html($w->lock_reason); ?></p></div><?php endif; ?>
            <?php if ($w->anonymized_at) : ?><div class="notice notice-warning inline"><p>Τα προσωπικά στοιχεία ανωνυμοποιήθηκαν στις <?php echo esc_html(TWD_Util::datetime_label($w->anonymized_at)); ?>.</p></div><?php endif; ?>

            <div class="tw-columns">
                <div class="tw-panel">
                    <h2>Προϊόν &amp; εγγύηση</h2>
                    <table class="form-table tw-kv">
                        <tr><th>Σειριακός</th><td><code><?php echo esc_html($w->serial); ?></code></td></tr>
                        <tr><th>Προϊόν</th><td><?php echo esc_html(trim($w->product_name . ' ' . ($w->product_code ? '(' . $w->product_code . ')' : ''))); ?></td></tr>
                        <tr><th>Ημ. αγοράς</th><td><?php echo esc_html(TWD_Util::date_label($w->purchase_date)); ?></td></tr>
                        <tr><th>Λήξη εγγύησης</th><td><?php echo esc_html(TWD_Util::date_label($w->warranty_end)); ?></td></tr>
                        <tr><th>Ενεργοποίηση</th><td><?php echo esc_html(TWD_Util::datetime_label($w->created_at)); ?></td></tr>
                        <tr><th>Παραστατικό</th><td><?php echo esc_html($w->invoice_number); ?>
                            <?php if ($w->invoice_file) : ?> – <a href="<?php echo esc_url(wp_nonce_url(add_query_arg(['action' => 'twd_invoice', 'id' => $w->id], $post), 'twd_invoice')); ?>">Λήψη αρχείου (<?php echo esc_html($w->invoice_original_name); ?>)</a><?php endif; ?></td></tr>
                    </table>
                </div>
                <div class="tw-panel">
                    <h2>Πελάτης</h2>
                    <table class="form-table tw-kv">
                        <tr><th>Ονοματεπώνυμο</th><td><?php echo esc_html($w->customer_name); ?></td></tr>
                        <tr><th>Email</th><td><?php echo esc_html($w->email); ?></td></tr>
                        <tr><th>Κινητό</th><td><?php echo esc_html($w->phone_mobile); ?></td></tr>
                        <tr><th>Σταθερό</th><td><?php echo esc_html($w->phone_landline); ?></td></tr>
                        <tr><th>Διεύθυνση</th><td><?php echo esc_html(trim($w->address . ', ' . $w->postcode . ' ' . $w->city, ', ')); ?></td></tr>
                        <tr><th>Συνεργάτης</th><td><?php echo esc_html(TWD_Util::tax_id_text($w->partner_country, $w->partner_vat)); ?> – <?php echo esc_html($w->partner_email); ?></td></tr>
                        <tr><th>Εμπορικές ενημερώσεις</th><td><?php echo $w->marketing_opt_in ? 'Ναι' : 'Όχι'; ?></td></tr>
                        <tr><th>Γλώσσα επικοινωνίας</th><td><?php echo esc_html(TWD_I18n::languages()[$w->lang ?? 'el'] ?? 'Ελληνικά'); ?></td></tr>
                    </table>
                </div>
            </div>

            <h2>Πρόγραμμα Service &amp; λήξης</h2>
            <table class="widefat striped"><thead><tr><th>Ορόσημο</th><th>Ημερομηνία</th><th>Κλείδωμα αν δεν γίνει</th><th>Κατάσταση</th><th>Service</th><th></th></tr></thead><tbody>
            <?php foreach ($timeline as $m) : ?>
                <tr><td><?php echo $m['type'] === 'service' ? (int) $m['no'] . 'ο Service (' . (int) $m['years'] . ' έτη)' : 'Λήξη εγγύησης'; ?></td>
                    <td><?php echo esc_html(TWD_Util::date_label($m['due'])); ?></td>
                    <td><?php echo esc_html(TWD_Util::date_label($m['lock_date'])); ?></td>
                    <td><?php echo esc_html($ms_labels[$m['state']] ?? $m['state']); ?></td>
                    <td><?php if ($m['service']) : $sv = $m['service']; ?>
                        <?php echo esc_html(TWD_Util::date_label($sv->performed_date)); ?> · <?php echo esc_html(TWD_Util::tax_id_text($sv->technician_country, $sv->technician_vat)); ?>
                        <?php echo $sv->receipt_number ? '· αρ. ' . esc_html($sv->receipt_number) : ''; ?>
                        <?php echo $sv->receipt_file ? '· <a href="' . esc_url(self::receipt_url($w, $sv)) . '" target="_blank">απόδειξη</a>' : ''; ?>
                    <?php endif; ?></td>
                    <td></td></tr>
            <?php endforeach; ?>
            </tbody></table>

            <h2>Υποβολές Service (<?php echo count($history); ?>)</h2>
            <p class="description tw-no-print">Όλες οι καταχωρήσεις Service για αυτόν τον σειριακό, με τις αποδείξεις. Καμία δεν διαγράφεται όταν ο πελάτης υποβάλει ξανά. Ο έλεγχος είναι προαιρετικός: σημειώστε μια υποβολή ως ελεγμένη ή απορρίψτε την αν δεν είναι σωστή (ο πελάτης ενημερώνεται και μπορεί να υποβάλει ξανά).</p>
            <table class="widefat striped"><thead><tr><th>Καταχώρηση</th><th>Service</th><th>Ημ/νία Service</th><th>Τεχνικός</th><th>Απόδειξη</th><th>Γνήσια ανταλλ.</th><th>Από</th><th>Έλεγχος</th><th class="tw-no-print"></th></tr></thead><tbody>
            <?php if (!$history) echo '<tr><td colspan="9">Καμία υποβολή ακόμη.</td></tr>'; ?>
            <?php $latest = TWD_Warranty::services($w->id); foreach ($history as $sv) : $is_latest = isset($latest[$sv->milestone_no]) && (int) $latest[$sv->milestone_no]->id === (int) $sv->id; ?>
                <tr<?php echo $is_latest ? '' : ' class="tw-superseded"'; ?>>
                    <td><?php echo esc_html(TWD_Util::datetime_label($sv->created_at)); ?><?php echo $is_latest ? '' : '<br><small>αντικαταστάθηκε από νεότερη</small>'; ?></td>
                    <td><?php echo (int) $sv->milestone_no; ?>ο</td>
                    <td><?php echo esc_html(TWD_Util::date_label($sv->performed_date)); ?></td>
                    <td><?php echo $sv->technician_vat ? esc_html(TWD_Util::tax_id_label($sv->technician_country ?: 'GR')) . ' <code>' . esc_html($sv->technician_vat) . '</code>' . (($sv->technician_country ?: 'GR') !== 'GR' ? ' ' . esc_html(TWD_Util::countries()[$sv->technician_country] ?? '') : '') : '—'; ?><?php echo $sv->technician ? '<br>' . esc_html($sv->technician) : ''; ?><?php echo $sv->notes ? '<br><small>' . esc_html($sv->notes) . '</small>' : ''; ?></td>
                    <td><?php
                        $bits = [];
                        if ($sv->receipt_number) $bits[] = 'Αρ. <strong>' . esc_html($sv->receipt_number) . '</strong>' . ($sv->receipt_date ? '<br>' . esc_html(TWD_Util::date_label($sv->receipt_date)) : '');
                        if ($sv->receipt_file) $bits[] = '<a href="' . esc_url(self::receipt_url($w, $sv)) . '" target="_blank">' . esc_html($sv->receipt_original_name ?: 'Αρχείο') . '</a>';
                        echo $bits ? implode('<br>', $bits) : '—';
                    ?></td>
                    <td><?php echo $sv->genuine_parts ? 'Ναι' : '<strong>Όχι</strong>'; ?></td>
                    <td><?php echo esc_html(['customer' => 'Πελάτης (πύλη)', 'admin' => 'Εταιρεία'][$sv->source] ?? $sv->source); ?></td>
                    <td><?php
                        if ($sv->review_status === 'approved') echo '✔ Ελέγχθηκε' . ($sv->reviewed_at ? '<br><small>' . esc_html(TWD_Util::datetime_label($sv->reviewed_at)) . '</small>' : '');
                        elseif ($sv->review_status === 'rejected') echo '<span class="tw-danger">✘ Απορρίφθηκε</span><br><small>' . esc_html($sv->review_note) . '</small>';
                        else echo 'Δεν έχει ελεγχθεί';
                    ?></td>
                    <td class="tw-no-print">
                        <?php if ($is_latest && $sv->review_status !== 'approved') : ?>
                        <form method="post" action="<?php echo esc_url($post); ?>" class="tw-review-form">
                            <?php wp_nonce_field('twd_review_service'); ?><input type="hidden" name="action" value="twd_review_service"><input type="hidden" name="id" value="<?php echo (int) $w->id; ?>"><input type="hidden" name="milestone_no" value="<?php echo (int) $sv->milestone_no; ?>">
                            <button class="button" name="decision" value="approve">✔ Ελέγχθηκε</button>
                            <?php if ($sv->review_status !== 'rejected') : ?>
                            <input type="text" name="note" placeholder="Λόγος απόρριψης">
                            <button class="button tw-danger" name="decision" value="reject" onclick="return this.form.note.value.trim() ? confirm('Απόρριψη; Ο πελάτης θα ενημερωθεί για νέα υποβολή.') : (alert('Συμπληρώστε λόγο απόρριψης.'), false)">✘ Απόρριψη</button>
                            <?php endif; ?>
                        </form>
                        <?php endif; ?>
                        <form method="post" action="<?php echo esc_url($post); ?>" onsubmit="return confirm('Οριστική διαγραφή αυτής της καταχώρησης και της απόδειξης;')">
                            <?php wp_nonce_field('twd_delete_service'); ?><input type="hidden" name="action" value="twd_delete_service"><input type="hidden" name="id" value="<?php echo (int) $w->id; ?>"><input type="hidden" name="service_id" value="<?php echo (int) $sv->id; ?>">
                            <button class="button-link tw-danger">Διαγραφή</button></form>
                    </td></tr>
            <?php endforeach; ?>
            </tbody></table>

            <div class="tw-columns tw-no-print">
                <div class="tw-panel">
                    <h2>Καταχώρηση Service από την εταιρεία</h2>
                    <p class="description">Συνήθως το Service το καταχωρεί ο πελάτης από την πύλη. Από εδώ το καταχωρείτε εσείς (π.χ. όταν το έκανε η Thermic).</p>
                    <form method="post" action="<?php echo esc_url($post); ?>" enctype="multipart/form-data">
                        <?php wp_nonce_field('twd_record_service'); ?>
                        <input type="hidden" name="action" value="twd_record_service"><input type="hidden" name="id" value="<?php echo (int) $w->id; ?>">
                        <p><label>Ορόσημο<br><select name="milestone_no">
                            <?php $preselected = false;
                            foreach ($timeline as $m) {
                                if ($m['type'] !== 'service') continue;
                                $pick = !$preselected && in_array($m['state'], ['due', 'upcoming', 'missed'], true);
                                if ($pick) $preselected = true;
                                printf('<option value="%d"%s>%dο Service – %s%s</option>', $m['no'], $pick ? ' selected' : '', $m['no'], esc_html(TWD_Util::date_label($m['due'])), $m['service'] ? ' (καταχωρημένο)' : '');
                            } ?>
                        </select></label></p>
                        <p><label>Ημερομηνία Service<br><input type="date" name="performed_date" required max="<?php echo esc_attr(TWD_Schedule::today()); ?>"></label></p>
                        <p><label>Από<br><select name="performed_by"><option value="partner">Συνεργάτη</option><option value="thermic">Thermic</option></select></label></p>
                        <p><label>Τεχνικός / συνεργείο<br><input type="text" name="technician" class="regular-text"></label></p>
                        <p><label>ΑΦΜ τεχνικού</label><br><?php echo TWD_Util::tax_id_field('technician_vat', 'technician_country', '', 'GR', '', false); // phpcs:ignore ?></p>
                        <p><label>Αριθμός απόδειξης<br><input type="text" name="receipt_number" class="regular-text" maxlength="100"></label></p>
                        <p><label>Ημερομηνία παραστατικού<br><input type="date" name="receipt_date" max="<?php echo esc_attr(TWD_Schedule::today()); ?>"></label></p>
                        <p><label>Αρχείο απόδειξης (προαιρετικό)<br><input type="file" name="receipt_file" accept=".pdf,.jpg,.jpeg,.png"></label></p>
                        <p><label><input type="checkbox" name="genuine_parts" value="1" checked> Χρησιμοποιήθηκαν αυθεντικά ανταλλακτικά</label></p>
                        <p><label>Σημειώσεις<br><textarea name="notes" rows="2" class="large-text"></textarea></label></p>
                        <p><button class="button button-primary">Καταχώρηση Service</button></p>
                    </form>
                    <?php if ($w->status === 'locked') : ?><p class="description">Η εγγύηση είναι κλειδωμένη· η καταχώρηση Service δεν την ξεκλειδώνει αυτόματα.</p><?php endif; ?>
                </div>
                <div class="tw-panel">
                    <h2>Ενέργειες</h2>
                    <form method="post" action="<?php echo esc_url($post); ?>" class="tw-inline-form">
                        <?php wp_nonce_field('twd_set_status'); ?><input type="hidden" name="action" value="twd_set_status"><input type="hidden" name="id" value="<?php echo (int) $w->id; ?>">
                        <p><label>Αλλαγή κατάστασης<br><select name="status">
                            <?php foreach ($labels as $k => $l) printf('<option value="%s"%s>%s</option>', esc_attr($k), selected($w->status, $k, false), esc_html($l)); ?>
                        </select></label></p>
                        <p><label>Αιτιολογία (υποχρεωτική)<br><input type="text" name="note" class="regular-text" required></label></p>
                        <p><button class="button" onclick="return confirm('Αλλαγή κατάστασης της εγγύησης;')">Αποθήκευση κατάστασης</button></p>
                        <p class="description">Ο πελάτης δεν μπορεί ποτέ να επανενεργοποιήσει κλειδωμένη εγγύηση· μόνο η εταιρεία από εδώ, με καταγραφή.</p>
                    </form>
                    <hr>
                    <form method="post" action="<?php echo esc_url($post); ?>">
                        <?php wp_nonce_field('twd_resend_activation'); ?><input type="hidden" name="action" value="twd_resend_activation"><input type="hidden" name="id" value="<?php echo (int) $w->id; ?>">
                        <button class="button">Επαναποστολή email επιβεβαίωσης</button>
                    </form>
                    <?php if (!$w->anonymized_at) : ?>
                    <hr>
                    <form method="post" action="<?php echo esc_url($post); ?>" onsubmit="return confirm('Ανωνυμοποίηση: θα διαγραφούν οριστικά τα προσωπικά στοιχεία και το παραστατικό. Συνέχεια;')">
                        <?php wp_nonce_field('twd_anonymize'); ?><input type="hidden" name="action" value="twd_anonymize"><input type="hidden" name="id" value="<?php echo (int) $w->id; ?>">
                        <button class="button tw-danger">Ανωνυμοποίηση προσωπικών στοιχείων (GDPR)</button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (!$w->anonymized_at) : ?>
            <details class="tw-panel tw-edit tw-no-print">
                <summary><h2 style="display:inline-block;margin:16px 0">Διόρθωση στοιχείων πελάτη</h2></summary>
                <p class="description">Για λάθη στα στοιχεία (π.χ. λάθος email ή τηλέφωνο). Κάθε αλλαγή καταγράφεται στο ιστορικό με την παλιά και τη νέα τιμή.</p>
                <form method="post" action="<?php echo esc_url($post); ?>">
                    <?php wp_nonce_field('twd_edit_customer'); ?><input type="hidden" name="action" value="twd_edit_customer"><input type="hidden" name="id" value="<?php echo (int) $w->id; ?>">
                    <div class="tw-columns" style="margin:0;gap:0 24px">
                        <div>
                            <p><label>Ονοματεπώνυμο<input type="text" name="customer_name" value="<?php echo esc_attr($w->customer_name); ?>" required></label></p>
                            <p><label>Email<input type="email" name="email" value="<?php echo esc_attr($w->email); ?>" required></label></p>
                            <p><label>Κινητό<input type="tel" name="phone_mobile" value="<?php echo esc_attr($w->phone_mobile); ?>" required></label></p>
                            <p><label>Σταθερό<input type="tel" name="phone_landline" value="<?php echo esc_attr($w->phone_landline); ?>"></label></p>
                        </div>
                        <div>
                            <p><label>Διεύθυνση<input type="text" name="address" value="<?php echo esc_attr($w->address); ?>"></label></p>
                            <p><label>Τ.Κ.<input type="text" name="postcode" value="<?php echo esc_attr($w->postcode); ?>"></label></p>
                            <p><label>Πόλη / Περιοχή<input type="text" name="city" value="<?php echo esc_attr($w->city); ?>"></label></p>
                            <p><label>ΑΦΜ συνεργάτη</label><?php echo TWD_Util::tax_id_field('partner_vat', 'partner_country', (string) $w->partner_vat, $w->partner_country ?: 'GR', '', false); // phpcs:ignore ?></p>
                            <p><label>Email συνεργάτη<input type="email" name="partner_email" value="<?php echo esc_attr($w->partner_email); ?>"></label></p>
                            <p><label>Αριθμός παραστατικού<input type="text" name="invoice_number" value="<?php echo esc_attr($w->invoice_number); ?>"></label></p>
                        </div>
                    </div>
                    <p><label>Αιτιολογία (π.χ. «αίτημα πελάτη τηλεφωνικά»)<input type="text" name="note" required></label></p>
                    <p><button class="button button-primary">Αποθήκευση αλλαγών</button></p>
                </form>
            </details>
            <?php endif; ?>

            <?php TWD_Claims::admin_section($w); ?>

            <h2>Συγκαταθέσεις (αποδεικτικό GDPR)</h2>
            <table class="widefat striped"><thead><tr><th>Ημ/νία</th><th>Τύπος</th><th>Απόφαση</th><th>Κείμενο που εμφανίστηκε</th><th>Όροι</th><th>Πηγή</th><th>IP</th><th>Browser</th></tr></thead><tbody>
            <?php foreach ($consents as $c) : ?>
                <tr><td><?php echo esc_html(TWD_Util::datetime_label($c->created_at)); ?></td><td><?php echo esc_html($consent_labels[$c->consent_type] ?? $c->consent_type); ?></td>
                    <td><?php echo $c->granted ? '✔ Αποδοχή' : '✘ Όχι'; ?></td><td><small><?php echo esc_html($c->label_text); ?></small></td>
                    <td><?php if ($c->terms_version) : ?><?php echo esc_html(TWD_Terms::name($c->terms_set ?: TWD_Terms::BASE)); ?><br><a href="<?php echo esc_url(wp_nonce_url(add_query_arg(['action' => 'twd_terms_view', 's' => $c->terms_set ?: TWD_Terms::BASE, 'v' => $c->terms_version, 'tl' => $c->lang], $post), 'twd_terms_view')); ?>" target="_blank">κείμενο που αποδέχθηκε<?php echo $c->lang === 'en' ? ' (EN)' : ''; ?></a><br><small title="SHA-256"><?php echo esc_html(substr($c->terms_hash, 0, 12)); ?>…</small><?php endif; ?></td>
                    <td><?php echo esc_html($c->source); ?></td><td><?php echo esc_html($c->ip); ?></td><td><small><?php echo esc_html($c->user_agent); ?></small></td></tr>
            <?php endforeach; ?>
            </tbody></table>

            <h2>Ειδοποιήσεις που στάλθηκαν</h2>
            <?php self::notifications_table($notes, false); ?>

            <h2>Ιστορικό</h2>
            <?php if ($events_total > count($events)) : ?><p class="description">Εμφανίζονται οι <?php echo count($events); ?> πιο πρόσφατες από <?php echo (int) $events_total; ?> καταγραφές.<?php if (self::can_admin()) : ?> Όλες στο <a href="<?php echo esc_url(TWD_App::admin_url('log', ['from' => substr($w->created_at, 0, 10), 'wid' => $w->id])); ?>">Ημερολόγιο</a> (όσες έχουν αρχειοθετηθεί, στην καρτέλα «Αρχείο»).<?php endif; ?></p><?php endif; ?>
            <table class="widefat striped"><thead><tr><th>Ημ/νία</th><th>Ενέργεια</th><th>Από</th><th>Λεπτομέρειες</th></tr></thead><tbody>
            <?php foreach ($events as $e) : ?>
                <tr><td><?php echo esc_html(TWD_Util::datetime_label($e->created_at)); ?></td><td><?php echo esc_html(self::event_label($e->action)); ?></td><td><?php echo esc_html(self::actor_label($e->actor)); ?></td><td><small><?php echo esc_html(self::event_details($e->details)); ?></small></td></tr>
            <?php endforeach; ?>
            </tbody></table>
        </div>
        <?php
    }

    private static function notifications_table($rows, $with_warranty, array $unseen = []) {
        $ch = ['email' => 'Email', 'sms' => 'SMS', 'partner' => 'Email συνεργάτη'];
        $st = ['sent' => 'Στάλθηκε', 'failed' => 'Απέτυχε η αποστολή', 'pending' => 'Σε εξέλιξη', 'skipped' => 'Παραλείφθηκε'];
        $dl = TWD_Brevo::status_labels();
        $icon = ['sent' => '⋯', 'delivered' => '✔', 'deferred' => '⏳', 'failed' => '✘', 'complaint' => '⚠'];
        echo '<table class="widefat striped"><thead><tr><th>Ημ/νία</th>' . ($with_warranty ? '<th>Εγγύηση</th>' : '') . '<th>Βήμα</th><th>Κανάλι</th><th>Παραλήπτης</th><th>Αποτέλεσμα</th></tr></thead><tbody>';
        if (!$rows) echo '<tr><td colspan="6">Καμία.</td></tr>';
        foreach ($rows as $n) {
            $new = in_array((int) $n->id, $unseen, true);
            echo '<tr' . ($new ? ' class="tw-unread"' : '') . '><td>' . esc_html(TWD_Util::datetime_label($n->created_at)) . ($new ? ' <span class="tw-new-dot">νέο</span>' : '') . '</td>';
            if ($with_warranty) echo '<td>' . self::warranty_link($n->warranty_id, $n->serial ?? ('#' . $n->warranty_id)) . '</td>';
            echo '<td>' . esc_html(TWD_Cron::row_label($n)) . '</td><td>' . esc_html($ch[$n->channel] ?? $n->channel) . '</td><td>' . esc_html($n->recipient) . '</td><td>';
            if ($n->status === 'sent' && $n->delivery_status !== '') {
                $cls = in_array($n->delivery_status, ['failed', 'complaint'], true) ? 'tw-danger' : ($n->delivery_status === 'delivered' ? 'tw-ok' : '');
                echo '<span class="' . $cls . '">' . esc_html(($icon[$n->delivery_status] ?? '') . ' ' . ($dl[$n->delivery_status] ?? $n->delivery_status)) . '</span>';
                if ($n->delivery_at && $n->delivery_status !== 'sent') echo ' <small>' . esc_html(TWD_Util::datetime_label($n->delivery_at)) . '</small>';
                if ($n->delivery_detail && $n->delivery_status !== 'delivered') echo '<br><small>' . esc_html($n->delivery_detail) . '</small>';
            } else {
                echo esc_html($st[$n->status] ?? $n->status) . ($n->error ? '<br><small class="tw-danger">' . esc_html($n->error) . '</small>' : '');
            }
            echo '</td></tr>';
        }
        echo '</tbody></table>';
    }

    // ------------------------------------------------------------------ serials

    public static function page_serials() {
        global $wpdb;
        $t = TWD_DB::table('serials');
        $s = self::q('s');
        $status = self::q('status');
        $batch = self::q('batch');
        $where = ['1=1']; $params = [];
        if ($s !== '') { $where[] = '(s.serial_no LIKE %s OR s.product_name LIKE %s OR s.product_code LIKE %s)'; $l = '%' . $wpdb->esc_like($s) . '%'; array_push($params, $l, $l, $l); }
        if ($status !== '') { $where[] = 's.status = %s'; $params[] = $status; }
        if ($batch !== '') { $where[] = 's.import_batch = %s'; $params[] = $batch; }
        $fterms = self::q('terms_set');
        if ($fterms !== '') { $where[] = 's.terms_set = %d'; $params[] = (int) $fterms; }
        $wsql = implode(' AND ', $where);
        if ($params) $wsql = $wpdb->prepare($wsql, $params);
        $paged = max(1, (int) self::q('paged'));
        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM $t s WHERE $wsql");
        $wt = TWD_DB::table('warranties');
        $rows = $wpdb->get_results("SELECT s.*, s.serial_no AS serial, w.id wid, w.warranty_code FROM $t s LEFT JOIN $wt w ON w.serial_id = s.id WHERE $wsql"
            . ' ORDER BY s.id DESC LIMIT ' . self::PER_PAGE . ' OFFSET ' . (($paged - 1) * self::PER_PAGE));
        $labels = TWD_Util::serial_status_labels();
        $post = self::url();
        $result = get_transient('twd_import_result_' . get_current_user_id());
        if ($result) delete_transient('twd_import_result_' . get_current_user_id());
        $export = wp_nonce_url(add_query_arg(array_filter(['action' => 'twd_export', 'type' => 'serials', 's' => $s, 'status' => $status, 'batch' => $batch]), $post), 'twd_export');
        ?>
        <div class="wrap tw-wrap">
            <h1 class="wp-heading-inline">Σειριακοί αριθμοί</h1>
            <?php self::export_button('serials', $export, 'Εξαγωγή Excel'); ?>
            <?php self::notice(); ?>
            <?php if ($result) : ?>
                <div class="notice notice-info"><p><strong>Αποτέλεσμα εισαγωγής <?php echo esc_html($result['batch']); ?>:</strong>
                    νέοι <?php echo (int) $result['inserted']; ?>, υπήρχαν ήδη / διπλοί <?php echo count($result['duplicates']); ?>, μη έγκυροι <?php echo count($result['invalid']); ?>.</p>
                    <?php if ($result['duplicates']) : ?><details><summary>Διπλοί</summary><p><code><?php echo esc_html(implode(', ', array_slice($result['duplicates'], 0, 500))); ?></code></p></details><?php endif; ?>
                    <?php if ($result['invalid']) : ?><details><summary>Μη έγκυροι</summary><p><code><?php echo esc_html(implode(', ', array_slice($result['invalid'], 0, 500))); ?></code></p></details><?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="tw-columns">
                <div class="tw-panel">
                    <h2>Εισαγωγή από αρχείο (Excel / CSV)</h2>
                    <p><a class="button" href="<?php echo esc_url(wp_nonce_url(add_query_arg('action', 'twd_template', self::url('serials')), 'twd_template')); ?>"><?php echo self::icon('download'); ?>Λήψη προτύπου Excel</a>
                        <span class="description">Συμπληρώστε το πρότυπο και ανεβάστε το εδώ.</span></p>
                    <form method="post" action="<?php echo esc_url($post); ?>" enctype="multipart/form-data">
                        <?php wp_nonce_field('twd_import'); ?><input type="hidden" name="action" value="twd_import">
                        <p><input type="file" name="file" accept=".xlsx,.csv,.txt" required></p>
                        <p class="description">Πρώτο φύλλο του .xlsx ή αρχείο .csv. Στήλες: <code>Σειριακός αριθμός</code> (υποχρεωτική), <code>Κωδικός προϊόντος</code>, <code>Όνομα προϊόντος</code>, <code>Παρτίδα</code>, <code>Σημειώσεις</code> (δεκτές και οι αγγλικές: serial, product_code, product_name, batch, notes). Η στήλη «Παρτίδα» του αρχείου υπερισχύει της παρτίδας της φόρμας· όπου είναι κενή, ισχύει η παρτίδα της φόρμας. Χωρίς γραμμή επικεφαλίδων, οι στήλες διαβάζονται ως σειριακός, κωδικός, όνομα, σημειώσεις. Υπάρχοντες σειριακοί δεν αλλάζουν.</p>
                        <p><label>Προεπιλεγμένος κωδικός προϊόντος (για κενά κελιά) <input type="text" name="default_code"></label></p>
                        <p><label>Προεπιλεγμένο όνομα προϊόντος (για κενά κελιά) <input type="text" name="default_name" class="regular-text"></label></p>
<p><label>Παρτίδα <span class="description">(προαιρετικό)</span> <input type="text" name="batch" maxlength="64" list="tw-batches" placeholder="π.χ. Παραγγελία 2026-118 – κενό: αυτόματα"></label><span class="description">Ομαδοποιεί τους σειριακούς (π.χ. ανά παραγγελία, αποστολή ή προμηθευτή) για φίλτρο και εξαγωγή. Γράψτε όνομα υπάρχουσας παρτίδας για να προστεθούν σε αυτή.</span></p>
                        <p><button class="button button-primary">Εισαγωγή</button></p>
                    </form>
                </div>
                <div class="tw-panel">
                    <h2>Προσθήκη ενός ή λίγων σειριακών</h2>
                    <form method="post" action="<?php echo esc_url($post); ?>">
                        <?php wp_nonce_field('twd_add_serial'); ?><input type="hidden" name="action" value="twd_add_serial">
                        <p><label>Σειριακοί (ένας ανά γραμμή)<br><textarea name="serials" rows="5" class="large-text code" required></textarea></label></p>
                        <p><label>Κωδικός προϊόντος <input type="text" name="product_code"></label></p>
                        <p><label>Όνομα προϊόντος <input type="text" name="product_name" class="regular-text"></label></p>
                        <p><label>Παρτίδα <span class="description">(προαιρετικό)</span> <input type="text" name="batch" maxlength="64" list="tw-batches" placeholder="π.χ. Παραγγελία 2026-118 – κενό: αυτόματα"></label><span class="description">Ομαδοποιεί τους σειριακούς (π.χ. ανά παραγγελία, αποστολή ή προμηθευτή) για φίλτρο και εξαγωγή. Γράψτε όνομα υπάρχουσας παρτίδας για να προστεθούν σε αυτή.</span></p>
                        <p><button class="button button-primary">Προσθήκη</button></p>
                    </form>
                </div>
            </div>

            <form method="get" class="tw-filters">
                <?php self::get_form_fields('serials'); ?>
                <input type="search" name="s" value="<?php echo esc_attr($s); ?>" placeholder="Σειριακός ή προϊόν">
                <select name="status"><option value="">Όλοι</option><?php foreach ($labels as $k => $l) printf('<option value="%s"%s>%s</option>', esc_attr($k), selected($status, $k, false), esc_html($l)); ?></select>
                <input type="text" name="batch" value="<?php echo esc_attr($batch); ?>" placeholder="Παρτίδα" list="tw-batches">
                <select name="terms_set"><option value="">Όροι: όλοι</option><option value="0"<?php selected($fterms, '0'); ?>>Κατά ημ/νία αγοράς</option><?php foreach (TWD_Terms::sets() as $tid => $ts) if ((int) $tid !== TWD_Terms::BASE) printf('<option value="%d"%s>%s</option>', (int) $tid, selected($fterms, (string) $tid, false), esc_html($ts['name'])); ?></select>
                <datalist id="tw-batches"><?php foreach (TWD_Importer::batches() as $b) echo '<option value="' . esc_attr($b) . '">'; ?></datalist>
                <button class="button">Φίλτρο</button>
            </form>
            <form method="post" action="<?php echo esc_url($post); ?>" id="tw-batch-form" class="tw-filters tw-batch-form">
                <?php wp_nonce_field('twd_serial_batch'); ?><input type="hidden" name="action" value="twd_serial_batch">
                <?php if ($batch !== '' && $total) : ?>
                    <input type="hidden" name="old_batch" value="<?php echo esc_attr($batch); ?>">
                    <strong>Διόρθωση παρτίδας:</strong>
                    <label><input type="radio" name="scope" value="all" checked> όλοι οι <?php echo (int) $total; ?> σειριακοί της «<?php echo esc_html($batch); ?>»</label>
                    <label><input type="radio" name="scope" value="selected"> μόνο οι επιλεγμένοι</label>
                <?php else : ?>
                    <input type="hidden" name="scope" value="selected">
                    <strong>Επιλεγμένοι σειριακοί:</strong>
                <?php endif; ?>
                → νέα παρτίδα <input type="text" name="new_batch" maxlength="64" list="tw-batches" required placeholder="όνομα (νέο ή υπάρχον)">
                <button class="button">Αλλαγή παρτίδας</button>
            </form>
            <?php self::pagination($total, $paged); ?>
            <table class="widefat striped"><thead><tr><th class="check-column"><input type="checkbox" onclick="document.querySelectorAll('.tw-batch-cb').forEach(function(c){c.checked=this.checked}.bind(this))" aria-label="Επιλογή όλων"></th><th>Σειριακός</th><th>Κωδικός προϊόντος</th><th>Όνομα προϊόντος</th><th>Κατάσταση</th><th>Εγγύηση</th><th>Παρτίδα</th><th>Όροι</th><th>Καταχώρηση</th><th></th></tr></thead><tbody>
            <?php if (!$rows) echo '<tr><td colspan="10">Δεν βρέθηκαν σειριακοί.</td></tr>'; ?>
            <?php foreach ($rows as $r) : ?>
                <tr><th class="check-column"><input type="checkbox" class="tw-batch-cb" name="ids[]" value="<?php echo (int) $r->id; ?>" form="tw-batch-form"></th><td><code><?php echo esc_html($r->serial); ?></code></td><td><?php echo esc_html($r->product_code); ?></td><td><?php echo esc_html($r->product_name); ?></td>
                    <td><?php echo self::status_badge($r->status, $labels); ?></td>
                    <td><?php echo $r->wid ? self::warranty_link($r->wid, $r->warranty_code) : '—'; ?></td>
                    <td><a href="<?php echo esc_url(self::url('serials', ['batch' => $r->import_batch])); ?>"><?php echo esc_html($r->import_batch); ?></a></td>
                    <td><?php echo $r->terms_set ? '<a href="' . esc_url(self::url('serials', ['terms_set' => $r->terms_set])) . '">' . esc_html(TWD_Terms::name($r->terms_set)) . '</a>' : '<span class="description">κατά ημ/νία αγοράς</span>'; ?></td>
                    <td><?php echo esc_html(TWD_Util::datetime_label($r->created_at)); ?></td>
                    <td><?php if ($r->status !== 'registered') : $to = $r->status === 'void' ? 'available' : 'void'; ?>
                        <form method="post" action="<?php echo esc_url($post); ?>"><?php wp_nonce_field('twd_serial_status'); ?>
                            <input type="hidden" name="action" value="twd_serial_status"><input type="hidden" name="id" value="<?php echo (int) $r->id; ?>"><input type="hidden" name="to" value="<?php echo esc_attr($to); ?>">
                            <button class="button-link"><?php echo $to === 'void' ? 'Ακύρωση' : 'Επαναφορά'; ?></button></form>
                    <?php endif; ?></td></tr>
            <?php endforeach; ?>
            </tbody></table>
            <?php self::pagination($total, $paged); ?>
        </div>
        <?php
    }

    // ------------------------------------------------------------------ notifications log

    public static function page_notifications() {
        global $wpdb;
        $paged = max(1, (int) self::q('paged'));
        $n = TWD_DB::table('notifications');
        $status = self::q('status');
        if ($status === 'undelivered') $where = "WHERE n.delivery_status IN ('failed','complaint')";
        elseif ($status === 'delivered') $where = "WHERE n.delivery_status = 'delivered'";
        else $where = $status ? $wpdb->prepare('WHERE n.status = %s', $status) : '';
        // Problems nobody has looked at yet: highlighted this time, then marked as read (menu badge).
        $unseen = array_map('intval', $wpdb->get_col("SELECT id FROM $n WHERE seen_at IS NULL AND " . self::problem_sql()));
        if ($unseen) $wpdb->query($wpdb->prepare("UPDATE $n SET seen_at = %s WHERE seen_at IS NULL AND " . self::problem_sql(), TWD_DB::now()));
        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM $n n $where");
        $rows = $wpdb->get_results("SELECT n.*, s.serial_no AS serial FROM $n n LEFT JOIN " . TWD_DB::table('warranties') . " w ON w.id = n.warranty_id LEFT JOIN " . TWD_DB::table('serials') . " s ON s.id = w.serial_id $where ORDER BY n.id DESC LIMIT " . self::PER_PAGE . ' OFFSET ' . (($paged - 1) * self::PER_PAGE));
        ?>
        <div class="wrap tw-wrap">
            <h1>Ειδοποιήσεις</h1>
            <?php self::notice(); ?>
            <?php if ($unseen) : ?><div class="notice notice-warning inline"><p><?php echo esc_html(sprintf(count($unseen) === 1 ? '1 ειδοποίηση δεν στάλθηκε ή δεν παραδόθηκε από την τελευταία φορά που ανοίξατε αυτή τη σελίδα.' : '%d ειδοποιήσεις δεν στάλθηκαν ή δεν παραδόθηκαν από την τελευταία φορά που ανοίξατε αυτή τη σελίδα.', count($unseen))); ?> Σημειώνονται με «νέο» και από τώρα θεωρούνται αναγνωσμένες. <a href="<?php echo esc_url(self::url('notifications', ['status' => 'undelivered'])); ?>">Δεν παραδόθηκαν</a> · <a href="<?php echo esc_url(self::url('notifications', ['status' => 'failed'])); ?>">Απέτυχε η αποστολή</a></p></div><?php endif; ?>
            <form method="post" action="<?php echo esc_url(self::url('notifications')); ?>" class="tw-inline-form">
                <?php wp_nonce_field('twd_run_now'); ?><input type="hidden" name="action" value="twd_run_now">
                <button class="button button-primary">Εκτέλεση ελέγχου ειδοποιήσεων τώρα</button>
                <span class="description">Η εκτέλεση γίνεται αυτόματα κάθε μέρα. Δεν στέλνει ποτέ το ίδιο μήνυμα δύο φορές.</span>
            </form>
            <p><a href="<?php echo esc_url(self::url('notifications')); ?>">Όλες</a> | <a href="<?php echo esc_url(self::url('notifications', ['status' => 'failed'])); ?>">Απέτυχε η αποστολή</a> | <a href="<?php echo esc_url(self::url('notifications', ['status' => 'undelivered'])); ?>">Δεν παραδόθηκαν</a> | <a href="<?php echo esc_url(self::url('notifications', ['status' => 'delivered'])); ?>">Παραδόθηκαν</a></p>
            <?php if (!TWD_Brevo::email_enabled() && !TWD_Brevo::sms_enabled()) : ?><p class="description">Η επιβεβαίωση παράδοσης («Παραδόθηκε / Δεν παραδόθηκε») λειτουργεί όταν η αποστολή γίνεται μέσω Brevo (Ρυθμίσεις → Brevo).</p><?php endif; ?>
            <?php self::pagination($total, $paged); self::notifications_table($rows, true, $unseen); self::pagination($total, $paged); ?>
        </div>
        <?php
    }

    // ------------------------------------------------------------------ settings

    public static function page_settings() {
        $s = TWD_Settings::all();
        // Messages and terms are edited per customer language (?tl=en for English).
        $tl = self::q('tl') === 'en' ? 'en' : 'el';
        $terms = TWD_Settings::current_terms('el');
        $terms_en = TWD_Settings::terms_versions('en') ? TWD_Settings::current_terms('en') : ['version' => 0, 'text' => '', 'published_at' => '', 'lang' => 'en'];
        $tpl = $tl === 'en' ? TWD_Settings::template_defaults_en() : TWD_Settings::template_defaults();
        $post = self::url();
        $tab = self::q('tab') ?: 'general';
        $tabs = ['general' => 'Γενικά', 'sender' => 'Αποστολέας', 'app' => 'Εφαρμογή & εμφάνιση', 'schedule' => 'Εγγύηση & ειδοποιήσεις', 'terms' => 'Όροι & συγκαταθέσεις', 'messages' => 'Κείμενα μηνυμάτων', 'brevo' => 'Brevo (email & SMS)', 'sms' => 'Άλλος πάροχος SMS', 'security' => 'Ασφάλεια', 'privacy' => 'GDPR'];
        $field = function ($key, $label, $type = 'text', $desc = '', $attrs = '') use ($s) {
            echo '<tr><th><label for="tw-' . esc_attr($key) . '">' . esc_html($label) . '</label></th><td>';
            if ($type === 'checkbox') {
                echo '<label><input type="checkbox" id="tw-' . esc_attr($key) . '" name="s[' . esc_attr($key) . ']" value="1" ' . checked((int) $s[$key], 1, false) . '> ' . esc_html($desc) . '</label>';
            } elseif ($type === 'textarea') {
                echo '<textarea id="tw-' . esc_attr($key) . '" name="s[' . esc_attr($key) . ']" rows="3" class="large-text" ' . $attrs . '>' . esc_textarea($s[$key]) . '</textarea>';
                if ($desc) echo '<p class="description">' . wp_kses_post($desc) . '</p>';
            } else {
                echo '<input type="' . esc_attr($type) . '" id="tw-' . esc_attr($key) . '" name="s[' . esc_attr($key) . ']" value="' . esc_attr($s[$key]) . '" class="' . ($type === 'number' ? 'small-text' : 'regular-text') . '" ' . $attrs . '>';
                if ($desc) echo '<p class="description">' . wp_kses_post($desc) . '</p>';
            }
            echo '</td></tr>';
        };
        ?>
        <div class="wrap tw-wrap">
            <h1>Ρυθμίσεις εγγυήσεων</h1>
            <?php self::notice(); ?>
            <nav class="nav-tab-wrapper">
                <?php foreach ($tabs as $k => $l) printf('<a class="nav-tab%s" href="%s">%s</a>', $tab === $k ? ' nav-tab-active' : '', esc_url(self::url('settings', ['tab' => $k])), esc_html($l)); ?>
            </nav>
            <form method="post" action="<?php echo esc_url($post); ?>" enctype="multipart/form-data">
                <?php wp_nonce_field('twd_save_settings'); ?>
                <input type="hidden" name="action" value="twd_save_settings"><input type="hidden" name="tab" value="<?php echo esc_attr($tab); ?>"><input type="hidden" name="tl" value="<?php echo esc_attr($tl); ?>">
                <table class="form-table">
                <?php if ($tab === 'general') :
                    $field('company_name', 'Επωνυμία');
                    $field('company_contact', 'Στοιχεία επικοινωνίας για Service', 'text', 'Εμφανίζεται στα μηνύματα: «…ή απευθείας στη Thermic: <em>αυτό το κείμενο</em>».');
                    $field('company_contact_en', 'Στοιχεία επικοινωνίας (English)', 'text', 'Για τους πελάτες στα αγγλικά, π.χ. <code>Thermic – tel. +30 210 0000000 – service@example.com</code>. Κενό = το ελληνικό κείμενο.');
                    $field('register_url', 'Σελίδα ενεργοποίησης (προαιρετικό)', 'url', 'Αφήστε κενό για την αυτόνομη σελίδα <code>' . esc_html(TWD_App::public_url()) . '</code>. Συμπληρώστε μόνο αν βάλατε το shortcode <code>[thermic_warranty_register]</code> σε δική σας σελίδα του site.');
                    $field('register_url_en', 'Σελίδα ενεργοποίησης – English (προαιρετικό)', 'url', 'Η αγγλική σελίδα με το shortcode <code>[thermic_warranty_register]</code>. Κενό = η παραπάνω σελίδα στα αγγλικά (μετάφραση Polylang ή <code>?lang=en</code>).');
                    $field('portal_url', 'Σελίδα «Οι εγγυήσεις μου» (προαιρετικό)', 'url', 'Αφήστε κενό για την αυτόνομη σελίδα <code>' . esc_html(TWD_App::public_url('my')) . '</code>. Συμπληρώστε μόνο αν χρησιμοποιείτε το shortcode <code>[thermic_warranty_portal]</code>. Μπαίνει στα email.');
                    $field('portal_url_en', 'Σελίδα «My warranties» – English (προαιρετικό)', 'url', 'Η αγγλική σελίδα με το shortcode <code>[thermic_warranty_portal]</code>. Μπαίνει στα email των πελατών που επικοινωνούν στα αγγλικά. Κενό = η παραπάνω σελίδα στα αγγλικά.');
                    $field('admin_emails', 'Email εταιρείας για ειδοποιήσεις', 'text', 'Ένα ή περισσότερα, χωρισμένα με κόμμα.');
                    $field('admin_digest', 'Ημερήσια αναφορά', 'checkbox', 'Κάθε πρωί (περίπου 09:00) email στα «Email εταιρείας για ειδοποιήσεις» με όσα έγιναν τις τελευταίες 24 ώρες: υπενθυμίσεις, αποτυχίες, μηνύματα που δεν παραδόθηκαν, λήξεις και κλειδώματα, νέες ενεργοποιήσεις, υποβολές Service. Στέλνεται μόνο αν υπάρχει κάτι.');
                    self::select_row('invoice_mode', 'Αρχείο παραστατικού αγοράς (ενεργοποίηση)', TWD_Settings::invoice_mode(), [
                        'required' => 'Υποχρεωτικό ανέβασμα αρχείου',
                        'optional' => 'Προαιρετικό ανέβασμα αρχείου',
                        'off' => 'Χωρίς αρχείο (μόνο αριθμός παραστατικού και ημερομηνία αγοράς)',
                    ], 'Ο αριθμός παραστατικού και η ημερομηνία αγοράς ζητούνται πάντα.');
                    self::select_row('service_proof_mode', 'Απόδειξη Service (υποβολή πελάτη)', TWD_Settings::service_proof_mode(), [
                        'upload' => 'Ανέβασμα αρχείου (φωτογραφία ή PDF)',
                        'fields' => 'Αριθμός και ημερομηνία παραστατικού (χωρίς αρχείο)',
                        'both' => 'Και τα δύο: αριθμός, ημερομηνία και αρχείο',
                    ]);
                    $field('invoice_max_mb', 'Μέγιστο μέγεθος αρχείου (MB)', 'number', '', 'min="1" max="50"');
                    $on = TWD_Util::enabled_countries();
                    ?>
                    <tr><th>Χώρες για τον ΑΦΜ</th><td>
                        <p class="description" style="margin-top:0">Ποιες χώρες εμφανίζονται στη λίστα δίπλα στον ΑΦΜ συνεργάτη και τεχνικού (στη φόρμα ενεργοποίησης και στην υποβολή Service). Η Ελλάδα εμφανίζεται πάντα· αν είναι η μόνη, το πεδίο δεν έχει λίστα χωρών. Η «Άλλη χώρα» δέχεται οποιονδήποτε αριθμό φορολογικού μητρώου.</p>
                        <input type="hidden" name="s[tax_countries][]" value="GR">
                        <p class="tw-export-tools" style="margin:8px 0"><button type="button" class="button" data-tw-tc="all">Όλες</button> <button type="button" class="button" data-tw-tc="none">Μόνο Ελλάδα</button></p>
                        <div class="tw-country-grid">
                            <?php foreach (TWD_Util::countries() as $code => $name) : ?>
                                <label><input type="checkbox" name="s[tax_countries][]" value="<?php echo esc_attr($code); ?>" <?php checked(isset($on[$code])); ?> <?php disabled($code === 'GR'); ?>> <span class="tw-cc"><?php echo esc_html(TWD_Util::tax_prefix($code)); ?></span> <?php echo esc_html($name); ?></label>
                            <?php endforeach; ?>
                        </div>
                        <script>
                        document.querySelectorAll('[data-tw-tc]').forEach(function (b) { b.addEventListener('click', function () {
                            var all = b.getAttribute('data-tw-tc') === 'all';
                            document.querySelectorAll('.tw-country-grid input:not([disabled])').forEach(function (c) { c.checked = all; });
                        }); });
                        </script>
                    </td></tr>
                    <?php
                elseif ($tab === 'app') :
                    $field('admin_slug', 'Διεύθυνση διαχειριστικού', 'text', 'Το διαχειριστικό ανοίγει στο <code>' . esc_html(home_url('/')) . '<strong>' . esc_html($s['admin_slug']) . '</strong>/</code>.', 'pattern="[a-z0-9\\-]+"');
                    $field('public_slug', 'Διεύθυνση σελίδων πελατών', 'text', 'Ενεργοποίηση: <code>' . esc_html(TWD_App::public_url()) . '</code> – Οι εγγυήσεις μου: <code>' . esc_html(TWD_App::public_url('my')) . '</code>', 'pattern="[a-z0-9\\-]+"');
                    ?>
                    <tr><th>Λογότυπο</th><td>
                        <?php if ($s['logo_url']) : ?><p class="tw-logo-preview"><img src="<?php echo esc_url($s['logo_url']); ?>" alt=""></p><?php endif; ?>
                        <p><input type="file" name="logo_file" accept="image/png,image/jpeg,image/webp"></p>
                        <p class="description">PNG, JPG ή WEBP, ιδανικά με διάφανο φόντο (PNG), έως 2 MB. Εμφανίζεται στο μενού, στη σύνδεση, στις σελίδες πελατών και στην εκτύπωση καρτέλας.</p>
                        <p><label>ή διεύθυνση εικόνας (URL)<input type="url" name="s[logo_url]" value="<?php echo esc_attr($s['logo_url']); ?>" class="regular-text"></label></p>
                        <?php if ($s['logo_url']) : ?><p><label><input type="checkbox" name="logo_remove" value="1"> Αφαίρεση λογοτύπου</label></p><?php endif; ?>
                    </td></tr>
                    <?php
                    [$c1, $c2] = TWD_App::colors(); ?>
                    <tr><th>Χρώματα</th><td>
                        <div class="tw-colors">
                            <label class="tw-color"><span class="tw-color-title">Κύριο χρώμα</span>
                                <span class="tw-color-row"><input type="color" value="<?php echo esc_attr($c1); ?>" data-tw-color="brand"><input type="text" name="s[brand_color]" value="<?php echo esc_attr($c1); ?>" pattern="#[0-9a-fA-F]{6}" maxlength="7" class="tw-color-hex"></span>
                                <span class="description">Κουμπιά, ενεργό μενού, σύνδεσμοι, εικονίδια τίτλων, σελίδες πελατών, email.</span></label>
                            <label class="tw-color"><span class="tw-color-title">Δευτερεύον χρώμα</span>
                                <span class="tw-color-row"><input type="color" value="<?php echo esc_attr($c2); ?>" data-tw-color="side"><input type="text" name="s[brand_color_2]" value="<?php echo esc_attr($c2); ?>" pattern="#[0-9a-fA-F]{6}" maxlength="7" class="tw-color-hex"></span>
                                <span class="description">Αριστερό μενού, σελίδα σύνδεσης, κάτω μέρος σελίδων πελατών.</span></label>
                        </div>
                        <p class="description">Η αλλαγή φαίνεται αμέσως σε αυτή τη σελίδα· πατήστε «Αποθήκευση» για να κρατηθεί. Το χρώμα των γραμμάτων προσαρμόζεται αυτόματα ώστε να διαβάζονται. <button type="button" class="button-link" id="tw-color-reset">Επαναφορά προεπιλογών</button></p>
                        <script>
                        (function () {
                            function light(hex) {
                                var h = hex.replace('#', ''), w = [0.2126, 0.7152, 0.0722], l = 0;
                                for (var i = 0; i < 3; i++) { var c = parseInt(h.substr(i * 2, 2), 16) / 255; c = c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); l += w[i] * c; }
                                return l > 0.45;
                            }
                            var root = document.documentElement.style;
                            function apply(kind, hex) {
                                if (!/^#[0-9a-fA-F]{6}$/.test(hex)) return;
                                if (kind === 'brand') { root.setProperty('--tw-brand', hex); root.setProperty('--tw-brand-ink', light(hex) ? '#111827' : '#ffffff'); }
                                else {
                                    var L = light(hex);
                                    root.setProperty('--tw-side', hex);
                                    root.setProperty('--tw-side-2', 'color-mix(in srgb,' + hex + ' 88%,' + (L ? '#000' : '#fff') + ')');
                                    root.setProperty('--tw-side-ink', L ? 'rgba(17,24,39,.72)' : 'rgba(255,255,255,.72)');
                                    root.setProperty('--tw-side-strong', L ? '#111827' : '#ffffff');
                                    root.setProperty('--tw-side-hover', L ? 'rgba(0,0,0,.06)' : 'rgba(255,255,255,.07)');
                                    root.setProperty('--tw-side-line', L ? 'rgba(0,0,0,.1)' : 'rgba(255,255,255,.08)');
                                }
                            }
                            document.querySelectorAll('[data-tw-color]').forEach(function (picker) {
                                var hex = picker.parentNode.querySelector('.tw-color-hex'), kind = picker.getAttribute('data-tw-color');
                                picker.addEventListener('input', function () { hex.value = picker.value; apply(kind, picker.value); });
                                hex.addEventListener('input', function () { if (/^#[0-9a-fA-F]{6}$/.test(hex.value)) { picker.value = hex.value; apply(kind, hex.value); } });
                            });
                            document.getElementById('tw-color-reset').addEventListener('click', function () {
                                [['brand', '#c8102e'], ['side', '#0f1320']].forEach(function (d) {
                                    var p = document.querySelector('[data-tw-color="' + d[0] + '"]'); p.value = d[1]; p.parentNode.querySelector('.tw-color-hex').value = d[1]; apply(d[0], d[1]);
                                });
                            });
                        })();
                        </script>
                    </td></tr>
                    <?php
                    ?>
                    <tr><th>Εκτύπωση καρτέλας &amp; όρων (PDF)</th><td>
                        <p class="description" style="margin-top:0">Υδατογράφημα (watermark) σε κάθε σελίδα της εκτυπωμένης καρτέλας εγγύησης και του PDF των όρων εγγύησης.</p>
                        <p><select name="s[pdf_watermark]" id="tw-wm-type">
                            <?php foreach (['text' => 'Κείμενο', 'logo' => 'Λογότυπο', 'none' => 'Χωρίς υδατογράφημα'] as $k => $l) printf('<option value="%s"%s>%s</option>', esc_attr($k), selected($s['pdf_watermark'], $k, false), esc_html($l)); ?>
                        </select>
                        <input type="text" name="s[pdf_watermark_text]" value="<?php echo esc_attr($s['pdf_watermark_text']); ?>" placeholder="<?php echo esc_attr($s['company_name']); ?>" class="regular-text" id="tw-wm-text"></p>
                        <p class="tw-range"><label for="tw-wm-op">Διαφάνεια</label>
                            <input type="range" min="0" max="40" step="1" name="s[pdf_watermark_opacity]" id="tw-wm-op" value="<?php echo (int) $s['pdf_watermark_opacity']; ?>">
                            <output id="tw-wm-out"><?php echo (int) $s['pdf_watermark_opacity']; ?>%</output></p>
                        <div class="tw-wm-preview"><span id="tw-wm-sample" style="opacity:<?php echo esc_attr((string) ((int) $s['pdf_watermark_opacity'] / 100)); ?>"><?php echo esc_html($s['pdf_watermark_text'] ?: $s['company_name']); ?></span></div>
                        <p class="description">Κενό κείμενο = η επωνυμία. Το «Λογότυπο» χρησιμοποιεί την εικόνα του πεδίου «Λογότυπο». Προτείνεται 4–10%.</p>
                        <script>
                        (function () {
                            var r = document.getElementById('tw-wm-op'), o = document.getElementById('tw-wm-out'), smp = document.getElementById('tw-wm-sample'), t = document.getElementById('tw-wm-text'), ty = document.getElementById('tw-wm-type');
                            function upd() { o.textContent = r.value + '%'; smp.style.opacity = r.value / 100; smp.textContent = t.value || t.placeholder; t.style.display = ty.value === 'text' ? '' : 'none'; smp.parentNode.style.display = ty.value === 'none' ? 'none' : ''; }
                            [r, t, ty].forEach(function (e) { e.addEventListener('input', upd); e.addEventListener('change', upd); }); upd();
                        })();
                        </script>
                    </td></tr>
                    <?php
                    ?>
                    <tr><th><label for="tw-session">Διάρκεια σύνδεσης</label></th><td>
                        <select id="tw-session" name="s[staff_session_minutes]">
                            <?php foreach (TWD_Staff_Auth::SESSION_CHOICES as $m) printf('<option value="%d"%s>%s</option>', $m, selected(TWD_Staff_Auth::session_minutes(), $m, false), esc_html($m < 60 ? $m . ' λεπτά' : ($m < 1440 ? ($m / 60) . ($m === 60 ? ' ώρα' : ' ώρες') : '1 ημέρα'))); ?>
                        </select>
                        <p class="description">Μετά από τόσο χρόνο από τη σύνδεση, το μέλος της ομάδας αποσυνδέεται αυτόματα. Στο αριστερό μενού φαίνεται ο χρόνος που απομένει, με κουμπί ανανέωσης που τον ξεκινά από την αρχή. Ισχύει από την επόμενη σύνδεση ή ανανέωση.</p>
                    </td></tr>
                    <?php
                    $field('staff_2fa', 'Διπλή επαλήθευση ομάδας', 'checkbox', 'Μετά τον κωδικό πρόσβασης, η ομάδα λαμβάνει κωδικό μίας χρήσης στο email (συνιστάται).');
                elseif ($tab === 'schedule') :
                    $field('warranty_years', 'Διάρκεια εγγύησης (έτη)', 'number', 'Από την ημερομηνία αγοράς.', 'min="1" max="50"');
                    $field('service_interval_years', 'Service ανά (έτη)', 'number', '0 = χωρίς περιοδικό Service. Με 12 έτη και 3: Service στα 3, 6 και 9 έτη, λήξη στα 12.', 'min="0" max="50"');
                    $field('reminder_offsets', 'Ημέρες ειδοποιήσεων', 'text', 'Σε σχέση με κάθε ημερομηνία (Service ή λήξη), χωρισμένες με κόμμα. Αρνητικές = πριν. Προεπιλογή: <code>-60,-30,0,30</code>.');
                    $field('lock_offset', 'Οριστικό κλείδωμα (ημέρες μετά)', 'number', 'Προεπιλογή 45, δηλαδή 15 ημέρες μετά το τέλος της περιόδου των 30 ημερών.', 'min="0" max="365"');
                    $field('lock_on_missed_service', 'Κλείδωμα για Service', 'checkbox', 'Κλείδωμα της εγγύησης αν δεν καταγραφεί Service έως την ημερομηνία κλειδώματος.');
                    $field('lock_on_expiry', 'Κλείδωμα μετά τη λήξη', 'checkbox', 'Οριστικό κλείδωμα μετά τη λήξη των 12 ετών.');
                    $field('notify_partner', 'Κοινοποίηση στον συνεργάτη', 'checkbox', 'Αποστολή αντιγράφου των υπενθυμίσεων Service και στο email του συνεργάτη.');
                    $field('catchup_days', 'Καθυστερημένη αποστολή (ημέρες)', 'number', 'Αν η αυτόματη εκτέλεση χάσει μέρες (π.χ. το site ήταν εκτός λειτουργίας), μια υπενθύμιση στέλνεται έως τόσες ημέρες αργότερα. Παλαιότερες παραλείπονται.', 'min="0" max="60"');
                    $field('service_submit_window_days', 'Υποβολή Service από τον πελάτη (ημέρες πριν)', 'number', 'Πόσες ημέρες πριν από την ημερομηνία Service ανοίγει η φόρμα υποβολής στην πύλη. Η υποβολή επιτρέπεται έως την ημερομηνία κλειδώματος.', 'min="0" max="365"');
                    $field('service_resubmit_days', 'Προθεσμία νέας υποβολής μετά από απόρριψη (ημέρες)', 'number', 'Αν απορρίψετε μια υποβολή, ο πελάτης έχει τόσες ημέρες (και τουλάχιστον έως την κανονική ημερομηνία κλειδώματος) για να υποβάλει ξανά.', 'min="1" max="120"');
                    $field('service_notify_company', 'Email για κάθε υποβολή Service', 'checkbox', 'Αποστολή email στην εταιρεία κάθε φορά που ένας πελάτης καταχωρεί Service. Χωρίς αυτό, οι υποβολές φαίνονται στην καρτέλα κάθε εγγύησης και στην Επισκόπηση.');
                    $field('max_registration_delay_days', 'Προθεσμία ενεργοποίησης (ημέρες)', 'number', 'Μέγιστες ημέρες από την αγορά έως την ενεργοποίηση. 0 = χωρίς όριο.', 'min="0"');
                elseif ($tab === 'terms') : ?>
                    <tr><th>Όροι εγγύησης</th><td><p>Τα κείμενα των όρων, οι εκδόσεις τους και η ανάθεσή τους σε ημερομηνίες αγοράς ή σειριακούς ορίζονται στην ενότητα <a href="<?php echo esc_url(self::url('terms')); ?>"><strong>Όροι εγγύησης</strong></a>. Εδώ ρυθμίζετε τα κείμενα των checkbox της ενεργοποίησης.</p></td></tr>
                    <?php
                    $field('terms_label', 'Checkbox όρων (υποχρεωτικό)', 'textarea');
                    $field('accuracy_label', 'Checkbox ορθότητας στοιχείων (υποχρεωτικό)', 'textarea');
                    $field('marketing_label', 'Checkbox εμπορικών ενημερώσεων (προαιρετικό, αρχικά αποεπιλεγμένο)', 'textarea');
                    ?>
                    <tr><td colspan="2"><h2 style="margin:12px 0 0">English – για πελάτες που χρησιμοποιούν την πλατφόρμα στα αγγλικά</h2></td></tr>
                    <?php
                    $field('terms_label_en', 'Terms checkbox (English)', 'textarea');
                    $field('accuracy_label_en', 'Accuracy checkbox (English)', 'textarea');
                    $field('marketing_label_en', 'Marketing checkbox (English)', 'textarea');
                elseif ($tab === 'messages') : ?>
                    <tr><td colspan="2"><p class="description">Διαθέσιμα πεδία: <code>{customer_name} {serial} {warranty_code} {product_name} {product_code} {purchase_date} {warranty_end} {due_date} {days} {years} {milestone_no} {grace_end_date} {lock_date} {partner_email} {company_name} {company_contact} {portal_url} {service_schedule}</code>, και για τους κωδικούς επαλήθευσης <code>{code} {minutes}</code>. Αφήστε ένα πεδίο κενό για το προεπιλεγμένο κείμενο. Κενό SMS = δεν στέλνεται SMS σε αυτό το βήμα.</p></td></tr>
                    <?php
                    ?>
                    <tr><td colspan="2"><p class="tw-lang-tabs">Γλώσσα μηνυμάτων:
                        <a class="button<?php echo $tl === 'el' ? ' button-primary' : ''; ?>" href="<?php echo esc_url(self::url('settings', ['tab' => 'messages'])); ?>">Ελληνικά</a>
                        <a class="button<?php echo $tl === 'en' ? ' button-primary' : ''; ?>" href="<?php echo esc_url(self::url('settings', ['tab' => 'messages', 'tl' => 'en'])); ?>">English</a>
                        <span class="description">Κάθε πελάτης λαμβάνει τα μηνύματα στη γλώσσα του (αυτή με την οποία ενεργοποίησε, ή όποια επέλεξε στο «Οι εγγυήσεις μου»).</span></p></td></tr>
                    <?php
                    $sfx = $tl === 'en' ? '_en' : '';
                    $field('email_footer_login' . $sfx, $tl === 'en' ? 'Footer: customer sign-in codes (English)' : 'Υποσέλιδο: κωδικοί σύνδεσης πελατών', 'textarea', 'Κάτω από τα email με κωδικό επαλήθευσης/σύνδεσης προς τους πελάτες. Δεκτό το <code>{company_name}</code>. Κενό = χωρίς υποσέλιδο.');
                    $field('email_footer_service' . $sfx, $tl === 'en' ? 'Footer: warranty & Service messages (English)' : 'Υποσέλιδο: μηνύματα εγγύησης & Service', 'textarea', 'Κάτω από τα υπόλοιπα email προς τους πελάτες (ενεργοποίηση, υπενθυμίσεις, Service, λήξη). Κενό = χωρίς υποσέλιδο. Τα email προς την ομάδα δεν έχουν υποσέλιδο.');
                    foreach ($tpl as $key => $def) : $saved = $s[$tl === 'en' ? 'templates_en' : 'templates'][$key] ?? []; ?>
                        <tr><th><?php echo esc_html($def['label']); ?><br><code><?php echo esc_html($key); ?></code></th><td>
                            <p><input type="text" class="large-text" name="tpl[<?php echo esc_attr($key); ?>][subject]" value="<?php echo esc_attr($saved['subject'] ?? ''); ?>" placeholder="<?php echo esc_attr($def['subject']); ?>"></p>
                            <p><textarea class="large-text" rows="6" name="tpl[<?php echo esc_attr($key); ?>][body]" placeholder="<?php echo esc_attr($def['body']); ?>"><?php echo esc_textarea($saved['body'] ?? ''); ?></textarea></p>
                            <?php if (!in_array($key, ['registration_otp', 'login_otp', 'erasure_otp', 'erasure_done'], true)) : ?>
                            <p><label>SMS<br><textarea class="large-text" rows="2" name="tpl[<?php echo esc_attr($key); ?>][sms]" placeholder="<?php echo esc_attr($def['sms']); ?>"><?php echo esc_textarea($saved['sms'] ?? ''); ?></textarea></label></p>
                            <?php endif; ?>
                        </td></tr>
                    <?php endforeach;
                elseif ($tab === 'brevo') : ?>
                    <tr><td colspan="2"><p class="description">Με το Brevo τα email και τα SMS φεύγουν από τους servers του Brevo, και για κάθε μήνυμα καταγράφεται αν <strong>παραδόθηκε</strong> στον πελάτη. Το αποτέλεσμα φαίνεται στην καρτέλα κάθε εγγύησης και στις Ειδοποιήσεις.</p></td></tr>
                    <tr><th><label for="tw-brevo_api_key">API key</label></th><td>
                        <input type="password" id="tw-brevo_api_key" name="brevo_api_key_new" class="regular-text" autocomplete="off" placeholder="<?php echo $s['brevo_api_key'] ? esc_attr('Αποθηκευμένο: …' . substr($s['brevo_api_key'], -6)) : 'xkeysib-…'; ?>">
                        <p class="description">Brevo → Settings → SMTP &amp; API → API Keys. Αφήστε κενό για να κρατήσετε το αποθηκευμένο.</p></td></tr>
                    <?php
                    $field('brevo_email', 'Email μέσω Brevo', 'checkbox', 'Όλα τα email της πλατφόρμας (υπενθυμίσεις, επιβεβαιώσεις, κωδικοί) στέλνονται μέσω Brevo.');
                    $field('brevo_sender_email', 'Email αποστολέα', 'email', 'Επιβεβαιωμένο στο Brevo (Senders &amp; IP). Κενό = το email της καρτέλας «Αποστολέας».');
                    $field('brevo_sender_name', 'Όνομα αποστολέα', 'text', 'Κενό = η επωνυμία της καρτέλας «Αποστολέας».');
                    $field('brevo_reply_to', 'Απαντήσεις πελατών στο', 'email', 'Κενό = το Reply-To της καρτέλας «Αποστολέας».');
                    $field('brevo_sms', 'SMS μέσω Brevo', 'checkbox', 'Τα SMS στέλνονται μέσω Brevo (χρειάζονται μονάδες SMS στον λογαριασμό).');
                    $field('brevo_sms_sender', 'Αποστολέας SMS', 'text', 'Έως 11 λατινικοί χαρακτήρες, π.χ. THERMIC.', 'maxlength="11"');
                    $field('fallback_channel', 'Εναλλακτικό κανάλι', 'checkbox', 'Αν μια υπενθύμιση δεν παραδοθεί με email, στέλνεται με SMS (και το αντίστροφο).');
                    ?>
                    <tr><th>Αναφορές παράδοσης (webhook)</th><td>
                        <code style="word-break:break-all"><?php echo esc_html(TWD_Brevo::webhook_url()); ?></code>
                        <p class="description">Για τα SMS ρυθμίζεται αυτόματα με κάθε μήνυμα. Για τα email πατήστε «Ρύθμιση αναφορών email στο Brevo» παρακάτω, ή προσθέστε τη διεύθυνση χειροκίνητα στο Brevo → Transactional → Settings → Webhook (συμβάντα: Delivered, Hard bounce, Soft bounce, Blocked, Spam, Invalid, Deferred, Error).</p></td></tr>
                    <?php
                elseif ($tab === 'sms') : ?>
                    <tr><td colspan="2"><p class="description">Μόνο αν δεν χρησιμοποιείτε το Brevo για τα SMS. Με άλλον πάροχο δεν υπάρχει επιβεβαίωση παράδοσης.</p></td></tr>
                    <?php
                    $field('sms_enabled', 'SMS', 'checkbox', 'Αποστολή SMS μαζί με τα email (ενεργοποίηση, Service, λήξη).');
                    $field('sms_sender', 'Αποστολέας (Sender ID)', 'text', 'Έως 11 λατινικοί χαρακτήρες, εγκεκριμένο από τον πάροχο.');
                    $field('sms_url', 'URL του παρόχου', 'url', 'Το endpoint αποστολής του παρόχου σας (π.χ. Yuboto, Apifon, Routee, Twilio). Δεκτά πεδία: <code>{to} {to_no_plus} {text} {sender}</code>.');
                    $field('sms_method', 'Μέθοδος HTTP', 'text', 'POST ή GET.');
                    $field('sms_headers', 'Headers', 'textarea', 'Ένα ανά γραμμή, π.χ. <code>Authorization: Bearer …</code>.');
                    $field('sms_body', 'Σώμα αιτήματος', 'textarea', 'Για POST. Πεδία: <code>{to} {to_no_plus} {text} {sender}</code>. Για JSON οι τιμές μπαίνουν με σωστό escaping.');
                elseif ($tab === 'sender') :
                    $host = preg_replace('/^www\./', '', (string) wp_parse_url(home_url(), PHP_URL_HOST));
                    ?>
                    <tr><td colspan="2"><p class="description">Από ποιον φαίνεται ότι έρχονται <strong>όλα</strong> τα email της πλατφόρμας: κωδικοί OTP, επιβεβαιώσεις, υπενθυμίσεις Service, ειδοποιήσεις της ομάδας και η ημερήσια αναφορά. Ισχύει και για το Brevo, εκτός αν εκεί ορίσετε διαφορετικά στοιχεία.</p></td></tr>
                    <?php
                    $field('email_from_name', 'Επωνυμία αποστολέα', 'text', 'Το όνομα που βλέπει ο παραλήπτης, π.χ. «Thermic Sol – Εγγυήσεις». Κενό = η επωνυμία από τα Γενικά (' . esc_html($s['company_name']) . ').', 'placeholder="' . esc_attr($s['company_name']) . '"');
                    $field('email_from_address', 'Email αποστολέα', 'email', 'Διεύθυνση του domain σας, π.χ. <code>warranty@' . esc_html($host) . '</code> ή <code>noreply@' . esc_html($host) . '</code>. Κενό = η προεπιλογή της ιστοσελίδας (συνήθως <code>wordpress@' . esc_html($host) . '</code>), γι’ αυτό τα μηνύματα φαίνονται να έρχονται από το «WordPress».', 'placeholder="warranty@' . esc_attr($host) . '"');
                    $field('email_reply_to', 'Απαντήσεις στο (Reply-To)', 'email', 'Προαιρετικό: πού πηγαίνει η απάντηση αν ο πελάτης πατήσει «Απάντηση», π.χ. <code>service@' . esc_html($host) . '</code>.');
                    ?>
                    <tr><td colspan="2"><div class="tw-tip"><span>💡</span><span>Για να μην πηγαίνουν τα μηνύματα στα ανεπιθύμητα, το email αποστολέα πρέπει να ανήκει στο domain σας και να στέλνεται μέσω Brevo ή SMTP (π.χ. WP Mail SMTP) με SPF/DKIM. Αν χρησιμοποιείτε SMTP plugin με ενεργή την επιλογή «Force From Email / Name», αυτό υπερισχύει: απενεργοποιήστε την ή βάλτε εκεί τα ίδια στοιχεία. Με «Αποστολή δοκιμής» παρακάτω βλέπετε πώς φτάνει το μήνυμα.</span></div></td></tr>
                    <?php
                elseif ($tab === 'security') :
                    $st = TWD_Guard::stats(30);
                    ?>
                    <tr><td colspan="2"><h2 style="margin:4px 0 0">Κωδικοί μίας χρήσης (OTP)</h2></td></tr>
                    <tr><th><label for="tw-otp-min">Διάρκεια κωδικού</label></th><td>
                        <select id="tw-otp-min" name="s[otp_minutes]">
                            <?php foreach (TWD_OTP::MINUTE_CHOICES as $m) printf('<option value="%d"%s>%d λεπτά</option>', $m, selected(TWD_OTP::ttl_minutes(), $m, false), $m); ?>
                        </select>
                        <p class="description">Πόσο ισχύει ο κωδικός που στέλνεται με email στους πελάτες (ενεργοποίηση, «Οι εγγυήσεις μου») και στην ομάδα (σύνδεση, ορισμός κωδικού πρόσβασης). Στην οθόνη του κωδικού φαίνεται ο χρόνος που απομένει.</p>
                    </td></tr>
                    <tr><th><label for="tw-portal-session">Διάρκεια σύνδεσης πελατών</label></th><td>
                        <select id="tw-portal-session" name="s[portal_session_minutes]">
                            <?php foreach (TWD_OTP::SESSION_CHOICES as $m) printf('<option value="%d"%s>%s</option>', $m, selected(TWD_OTP::session_minutes(), $m, false), $m >= 60 ? ($m / 60) . ($m === 60 ? ' ώρα' : ' ώρες') : $m . ' λεπτά'); ?>
                        </select>
                        <p class="description">Πόσο μένει συνδεδεμένος ο πελάτης στις «Οι εγγυήσεις μου». Κάτω δεξιά στη σελίδα βλέπει συνεχώς τον χρόνο που απομένει, με κουμπί ανανέωσης (↻) που τον ξεκινά από την αρχή· στο τελευταίο λεπτό η ένδειξη γίνεται κόκκινη. Όταν λήξει, αποσυνδέεται και χρειάζεται νέο κωδικό.</p>
                    </td></tr>
                    <tr><td colspan="2"><h2 style="margin:8px 0 0">Πρόσβαση με IP</h2>
                        <p><?php if (TWD_Access::active()) : ?><strong style="color:#15803d">Ενεργός.</strong> Το <?php echo esc_html(TWD_App::APP_NAME); ?> ανοίγει μόνο από: <code><?php echo esc_html(implode(', ', TWD_Access::allowed_list())); ?></code>.
                        <?php else : ?><strong>Ανενεργός.</strong> Το <?php echo esc_html(TWD_App::APP_NAME); ?> ανοίγει από οποιαδήποτε σύνδεση.<?php endif; ?>
                        Η IP σας: <code><?php echo esc_html(TWD_Access::visitor_ip()); ?></code>.</p>
                        <p class="description">Τον περιορισμό τον ενεργοποιούν και τον αλλάζουν μόνο οι διαχειριστές της ιστοσελίδας<?php if (current_user_can('manage_options')) : ?>, από <a href="<?php echo esc_url(TWD_Access::admin_page_url()); ?>" target="_blank" rel="noopener">Warranty Manager → Πρόσβαση με IP</a><?php endif; ?>.</p></td></tr>
                    <tr><td colspan="2"><h2 style="margin:8px 0 0">Προστασία φορμών</h2><p class="description">Προστασία από bots και αυτόματες υποβολές σε όλες τις φόρμες: σύνδεση ομάδας, ενεργοποίηση εγγύησης, σύνδεση πελάτη στο «Οι εγγυήσεις μου» και υποβολή Service.</p>
                        <?php if (TWD_Guard::disabled_by_constant()) : ?><div class="notice notice-warning inline"><p>Το Turnstile είναι απενεργοποιημένο από το <code>wp-config.php</code> (<code>TWD_DISABLE_TURNSTILE</code>). Το honeypot παραμένει ενεργό.</p></div><?php endif; ?></td></tr>
                    <tr><th>Honeypot</th><td><p><strong>Πάντα ενεργό.</strong> Κάθε φόρμα έχει ένα κρυφό πεδίο που δεν βλέπει ο άνθρωπος· τα bots το συμπληρώνουν και η υποβολή απορρίπτεται. Επίσης απορρίπτονται φόρμες που στάλθηκαν σε λιγότερο από <?php echo (int) TWD_Guard::MIN_SECONDS; ?> δευτερόλεπτα από το άνοιγμά τους.</p>
                        <p class="description">Τελευταίες 30 ημέρες: <?php echo (int) $st['honeypot']; ?> μπλοκαρίστηκαν από το honeypot · <?php echo (int) $st['too_fast']; ?> ως πολύ γρήγορες · <?php echo (int) $st['turnstile']; ?> από το Turnstile.</p></td></tr>
                    <tr><td colspan="2"><h2 style="margin:8px 0 0">Cloudflare Turnstile</h2>
                        <p class="description">Δωρεάν έλεγχος «δεν είμαι ρομπότ» της Cloudflare, συνήθως χωρίς καμία ενέργεια από τον χρήστη (χωρίς εικόνες, χωρίς cookies διαφήμισης). Δημιουργήστε widget στο <a href="https://dash.cloudflare.com/?to=/:account/turnstile" target="_blank" rel="noopener">Cloudflare → Turnstile</a> → «Add widget», δηλώστε το domain <code><?php echo esc_html(wp_parse_url(home_url(), PHP_URL_HOST)); ?></code>, Widget mode «Managed», και αντιγράψτε εδώ τα δύο κλειδιά. Δεν χρειάζεται το site να είναι στο Cloudflare.</p></td></tr>
                    <?php
                    $field('turnstile_site_key', 'Site key', 'text', '', 'autocomplete="off" spellcheck="false"');
                    ?>
                    <tr><th><label for="tw-ts-secret">Secret key</label></th><td>
                        <input type="password" id="tw-ts-secret" name="turnstile_secret_new" class="regular-text" autocomplete="off" placeholder="<?php echo $s['turnstile_secret'] ? esc_attr('Αποθηκευμένο: …' . substr($s['turnstile_secret'], -6)) : '0x4AAA…'; ?>">
                        <p class="description">Αφήστε κενό για να κρατήσετε το αποθηκευμένο.</p></td></tr>
                    <?php
                    $field('turnstile_staff', 'Σύνδεση ομάδας', 'checkbox', 'Έλεγχος στη «Σύνδεση» και στην «Πρώτη σύνδεση / ξέχασα τον κωδικό» του διαχειριστικού.');
                    $field('turnstile_public', 'Φόρμες πελατών', 'checkbox', 'Έλεγχος στην ενεργοποίηση εγγύησης (1ο και 3ο βήμα) και στη σύνδεση στο «Οι εγγυήσεις μου».');
                    ?>
                    <tr><th>Δοκιμή κλειδιών</th><td>
                        <div id="tw-ts-test" style="max-width:340px"></div>
                        <p class="description" id="tw-ts-test-msg">Για να ενεργοποιηθεί το Turnstile, αυτός ο έλεγχος πρέπει να ολοκληρωθεί (✔) πριν πατήσετε «Αποθήκευση». Έτσι επιβεβαιώνεται ότι τα κλειδιά δουλεύουν σε αυτό το domain και κανείς δεν κλειδώνεται έξω. Αν ο έλεγχος αποτύχει, τα κλειδιά αποθηκεύονται αλλά η προστασία μένει ανενεργή.</p>
                        <script>
                        (function () {
                            var key = document.getElementById('tw-turnstile_site_key'), box = document.getElementById('tw-ts-test'), msg = document.getElementById('tw-ts-test-msg'), id = null, shown = '';
                            function draw() {
                                var k = key.value.trim();
                                if (!window.turnstile || k === shown) return;
                                if (id !== null) { window.turnstile.remove(id); id = null; }
                                shown = k;
                                if (k) id = window.turnstile.render(box, { sitekey: k, action: 'settings_test', language: 'el', 'error-callback': function () { msg.style.color = '#b32d2e'; } });
                            }
                            window.twTsSettings = draw;
                            key.addEventListener('change', draw);
                            var sc = document.createElement('script');
                            sc.src = <?php echo wp_json_encode(TWD_Guard::SCRIPT . '?render=explicit&onload=twTsSettings'); ?>;
                            sc.async = true;
                            document.head.appendChild(sc);
                        })();
                        </script>
                    </td></tr>
                    <tr><td colspan="2"><p class="description">Αν κάτι πάει στραβά και δεν μπορείτε να συνδεθείτε, προσθέστε στο <code>wp-config.php</code> τη γραμμή <code>define('TWD_DISABLE_TURNSTILE', true);</code> – το Turnstile σταματά αμέσως, το honeypot μένει.</p></td></tr>
                    <?php
                elseif ($tab === 'privacy') :
                    $field('privacy_url', 'Σελίδα Πολιτικής Απορρήτου', 'url', 'Η σελίδα του site με την πολιτική απορρήτου, όπου βάλατε το shortcode <code>[' . TWD_Privacy_Text::SHORTCODE . ']</code>. Μπαίνει ως σύνδεσμος στη φόρμα ενεργοποίησης και στις σελίδες της εφαρμογής. Κενό = η Πολιτική Απορρήτου της ιστοσελίδας (WordPress).');
                    $field('privacy_url_en', 'Σελίδα Πολιτικής Απορρήτου – English', 'url', 'Η αγγλική σελίδα με το shortcode (π.χ. <code>[' . TWD_Privacy_Text::SHORTCODE . ' lang=&quot;en&quot;]</code>). Κενό = η ελληνική σελίδα στα αγγλικά.');
                    echo '<tr><th>Κείμενα πολιτικής απορρήτου</th><td><p class="description" style="margin-top:0">Γράψτε εδώ την πολιτική απορρήτου στα ελληνικά και στα αγγλικά, με την ίδια μπάρα μορφοποίησης όπως στους όρους εγγύησης. Στη σελίδα του site βάλτε το shortcode <code>[' . esc_html(TWD_Privacy_Text::SHORTCODE) . ']</code>: δείχνει το κείμενο στη γλώσσα του επισκέπτη, με την ημερομηνία τελευταίας ενημέρωσης. Για συγκεκριμένη γλώσσα: <code>[' . esc_html(TWD_Privacy_Text::SHORTCODE) . ' lang="en"]</code>.</p></td></tr>';
                    TWD_Privacy_Text::admin_rows();
                    $field('retention_months_after_end', 'Αυτόματη ανωνυμοποίηση (μήνες)', 'number', 'Μήνες μετά τη λήξη ή το κλείδωμα για αυτόματη ανωνυμοποίηση των προσωπικών στοιχείων. Το ιστορικό του προϊόντος μένει. 0 = απενεργοποιημένο. Ορίστε το σε συνεννόηση με τον νομικό σύμβουλο / DPO.', 'min="0"');
                    ?>
                    <tr><th>Διαγραφή από τον πελάτη</th><td><p class="description" style="margin-top:0">Στις «Οι εγγυήσεις μου» → «Διαγραφή των στοιχείων μου» ο πελάτης βλέπει το παρακάτω κείμενο, επιλέγει «Επιθυμώ τη διαγραφή των στοιχείων μου» και επιβεβαιώνει με κωδικό που λαμβάνει στο email (μήνυμα «Κωδικός επιβεβαίωσης διαγραφής στοιχείων» στα Κείμενα μηνυμάτων). Με τον σωστό κωδικό τα στοιχεία όλων των εγγυήσεών του ανωνυμοποιούνται αμέσως, και λαμβάνει email επιβεβαίωσης. Η ενέργεια καταγράφεται στο Ημερολόγιο.</p></td></tr>
                    <?php foreach (['erase_text' => 'Κείμενο πριν τη διαγραφή (Ελληνικά)', 'erase_text_en' => 'Κείμενο πριν τη διαγραφή (English)'] as $ek => $el) : ?>
                        <tr><th><label for="tw-<?php echo esc_attr($ek); ?>"><?php echo esc_html($el); ?></label></th><td>
                            <textarea id="tw-<?php echo esc_attr($ek); ?>" name="s[<?php echo esc_attr($ek); ?>]" rows="12" class="large-text"<?php echo $ek === 'erase_text_en' ? ' lang="en"' : ''; ?> placeholder="<?php echo esc_attr(TWD_Settings::erase_text_default($ek === 'erase_text_en' ? 'en' : 'el')); ?>"><?php echo esc_textarea($s[$ek]); ?></textarea>
                            <p class="description">Κενό = το προτεινόμενο κείμενο (φαίνεται αχνά μέσα στο πεδίο). Κενή γραμμή = νέα παράγραφος· γραμμές που αρχίζουν με «•» εμφανίζονται ως λίστα.</p>
                        </td></tr>
                    <?php endforeach; ?>
                    <tr><th>Παλαιότερα αιτήματα</th><td><p class="description">Αιτήματα διαγραφής που υποβλήθηκαν με τον παλιό τρόπο (επιβεβαίωση από email και εκτέλεση από την ομάδα) εμφανίζονται παρακάτω.</p></td></tr>
                <?php endif; ?>
                </table>
                <p class="submit"><button type="submit" class="button button-primary" id="submit">Αποθήκευση</button></p>
            </form>
            <?php if ($tab === 'privacy') self::erasure_requests(); ?>
            <?php if ($tab === 'brevo') self::brevo_tools(); ?>
            <?php if (in_array($tab, ['messages', 'sms', 'general', 'brevo', 'sender'], true)) : $tpl = $tab === 'messages' && $tl === 'en' ? TWD_Settings::template_defaults_en() : TWD_Settings::template_defaults(); ?>
                <h2>Δοκιμαστική αποστολή</h2>
                <form method="post" action="<?php echo esc_url($post); ?>" class="tw-inline-form">
                    <?php wp_nonce_field('twd_test_message'); ?><input type="hidden" name="action" value="twd_test_message"><input type="hidden" name="tab" value="<?php echo esc_attr($tab); ?>"><input type="hidden" name="tl" value="<?php echo esc_attr($tl); ?>">
                    <select name="template"><?php foreach ($tpl as $k => $d) printf('<option value="%s">%s</option>', esc_attr($k), esc_html($d['label'])); ?></select>
                    <input type="email" name="email" placeholder="email" value="<?php echo esc_attr(wp_get_current_user()->user_email); ?>">
                    <input type="tel" name="phone" placeholder="κινητό (για SMS)">
                    <button class="button">Αποστολή δοκιμής</button>
                </form>
            <?php endif; ?>
        </div>
        <?php
    }

    // ------------------------------------------------------------------ backups

    private static function days_label($days) {
        if ($days >= 2) return (int) floor($days) . ' ημέρες';
        return $days >= 1 ? '1 ημέρα' : 'λιγότερο από 1 ημέρα';
    }

    private static function size_label($bytes) {
        if ($bytes >= 1048576) return number_format_i18n($bytes / 1048576, 1) . ' MB';
        return number_format_i18n(max(1, $bytes / 1024), 0) . ' KB';
    }

    public static function page_backups() {
        if (!self::can_admin()) { echo '<p>Δεν έχετε πρόσβαση.</p>'; return; }
        $s = TWD_Settings::all();
        $list = TWD_Backup::all();
        $post = self::url('backups');
        $next = wp_next_scheduled(TWD_Backup::HOOK);
        $types = ['auto' => 'Αυτόματο', 'manual' => 'Χειροκίνητο', 'prerestore' => 'Πριν από επαναφορά'];
        ?>
        <div class="wrap tw-wrap">
            <h1>Αντίγραφα ασφαλείας</h1>
            <?php self::notice(); ?>
            <p class="description">Κάθε αντίγραφο περιέχει όλα τα δεδομένα της πλατφόρμας: σειριακούς, εγγυήσεις και πελάτες, υποβολές Service, συγκαταθέσεις, ιστορικό ειδοποιήσεων, ρυθμίσεις και όρους, καθώς και τα αρχεία (παραστατικά, αποδείξεις). Δεν περιλαμβάνει τα κλειδιά πρόσβασης (Brevo) ούτε την υπόλοιπη ιστοσελίδα (σελίδες, χρήστες, εμφάνιση), που καλύπτονται από το backup της φιλοξενίας.</p>

            <form method="post" action="<?php echo esc_url($post); ?>" class="tw-inline-form">
                <?php wp_nonce_field('twd_backup_create'); ?><input type="hidden" name="action" value="twd_backup_create">
                <button class="button button-primary"><?php echo self::icon('plus'); ?>Δημιουργία αντιγράφου τώρα</button>
                <span class="description">Αυτόματα αντίγραφα: <?php echo $s['backup_daily']
                    ? esc_html(sprintf('%d την ημέρα (%s) – επόμενο %s – στον server κρατούνται τα τελευταία %d (≈ %s)', TWD_Backup::per_day(), implode(', ', TWD_Backup::times()), $next ? wp_date('d/m/Y H:i', $next) : '—', (int) $s['backup_keep'], self::days_label((int) $s['backup_keep'] / TWD_Backup::per_day())))
                    : '<strong>ανενεργά</strong>'; ?>.</span>
            </form>

            <table class="widefat striped"><thead><tr><th>Ημερομηνία</th><th>Τύπος</th><th>Μέγεθος</th><th>Περιεχόμενο</th><th>Κρυπτογράφηση</th><th>Εκτός server</th><th></th></tr></thead><tbody>
            <?php if (!$list) echo '<tr><td colspan="7">Δεν υπάρχει αντίγραφο ακόμη.</td></tr>'; ?>
            <?php foreach ($list as $b) : $m = TWD_Backup::manifest($b['path']); ?>
                <tr><td><?php echo esc_html(TWD_Util::datetime_label($b['time'])); ?></td><td><?php echo esc_html($types[$b['type']] ?? $b['type']); ?></td>
                    <td><?php echo esc_html(self::size_label($b['size'])); ?></td>
                    <td><?php echo $m ? esc_html(sprintf('%d εγγυήσεις, %d σειριακοί, %d αρχεία', $m['rows']['warranties'] ?? 0, $m['rows']['serials'] ?? 0, $m['files'] ?? 0)) : '—'; ?></td>
                    <td><?php echo $m && !empty($m['encrypted']) ? '🔒 Ναι' : 'Όχι'; ?></td>
                    <td><?php $si = TWD_Backup_Remote::sent_info($b['file']); echo $si ? '✔ ' . esc_html(TWD_Backup_Remote::label($si['service'])) . '<br><small>' . esc_html(TWD_Util::datetime_label($si['at'])) . '</small>' : '—'; ?></td>
                    <td class="tw-row-actions">
                        <?php if (TWD_Backup_Remote::enabled() && $m && !empty($m['encrypted'])) : ?>
                        <form method="post" action="<?php echo esc_url($post); ?>"><?php wp_nonce_field('twd_backup_send'); ?><input type="hidden" name="action" value="twd_backup_send"><input type="hidden" name="file" value="<?php echo esc_attr($b['file']); ?>">
                            <button class="button" title="Αποστολή στο <?php echo esc_attr(TWD_Backup_Remote::label()); ?>"><?php echo self::icon('cloud'); ?>Αποστολή</button></form>
                        <?php endif; ?>
                        <a class="button" href="<?php echo esc_url(wp_nonce_url(add_query_arg(['action' => 'twd_backup_download', 'file' => $b['file']], $post), 'twd_backup_download')); ?>">Λήψη</a>
                        <form method="post" action="<?php echo esc_url($post); ?>" onsubmit="return confirm('ΕΠΑΝΑΦΟΡΑ: όλα τα τωρινά δεδομένα της πλατφόρμας θα αντικατασταθούν με αυτά του <?php echo esc_attr(TWD_Util::datetime_label($b['time'])); ?>. Πριν από την επαναφορά θα κρατηθεί αντίγραφο της τωρινής κατάστασης. Συνέχεια;')">
                            <?php wp_nonce_field('twd_backup_restore'); ?><input type="hidden" name="action" value="twd_backup_restore"><input type="hidden" name="file" value="<?php echo esc_attr($b['file']); ?>">
                            <?php if ($m && !empty($m['encrypted'])) : ?><input type="password" name="password" placeholder="κωδικός" size="10"><?php endif; ?>
                            <button class="button">Επαναφορά</button></form>
                        <form method="post" action="<?php echo esc_url($post); ?>" onsubmit="return confirm('Οριστική διαγραφή του αντιγράφου;')">
                            <?php wp_nonce_field('twd_backup_delete'); ?><input type="hidden" name="action" value="twd_backup_delete"><input type="hidden" name="file" value="<?php echo esc_attr($b['file']); ?>">
                            <button class="button-link tw-danger">Διαγραφή</button></form>
                    </td></tr>
            <?php endforeach; ?>
            </tbody></table>

            <div class="tw-columns">
                <div class="tw-panel">
                    <h2>Επαναφορά από αρχείο</h2>
                    <p class="description">Για αντίγραφο που έχετε κατεβάσει (π.χ. από άλλον server). Όλα τα τωρινά δεδομένα θα αντικατασταθούν· πριν από αυτό κρατείται αυτόματα αντίγραφο της τωρινής κατάστασης.</p>
                    <form method="post" action="<?php echo esc_url($post); ?>" enctype="multipart/form-data" onsubmit="return confirm('Όλα τα τωρινά δεδομένα θα αντικατασταθούν με αυτά του αρχείου. Συνέχεια;')">
                        <?php wp_nonce_field('twd_backup_restore'); ?><input type="hidden" name="action" value="twd_backup_restore">
                        <p><input type="file" name="backup_file" accept=".zip" required></p>
                        <p><input type="password" name="password" placeholder="Κωδικός (αν είναι κρυπτογραφημένο)" class="regular-text"></p>
                        <p><button class="button">Επαναφορά από αρχείο</button></p>
                    </form>
                </div>
                <div class="tw-panel">
                    <h2>Ρυθμίσεις</h2>
                    <form method="post" action="<?php echo esc_url($post); ?>">
                        <?php wp_nonce_field('twd_backup_settings'); ?><input type="hidden" name="action" value="twd_backup_settings">
                        <p><label><input type="checkbox" name="backup_daily" value="1" <?php checked((int) $s['backup_daily'], 1); ?>> Αυτόματα αντίγραφα</label></p>
                        <p><label>Πόσα την ημέρα <select name="backup_per_day" id="tw-per-day" class="tw-inline-select">
                            <?php foreach (array_keys(TWD_Backup::PER_DAY) as $n) printf('<option value="%d"%s>%d</option>', $n, selected(TWD_Backup::per_day(), $n, false), $n); ?>
                        </select></label>
                        <label>πρώτο στις <input type="time" name="backup_time" value="<?php echo esc_attr(preg_match('/^\d{2}:\d{2}$/', $s['backup_time']) ? $s['backup_time'] : '03:30'); ?>" required></label></p>
                        <p class="description">Τα υπόλοιπα γίνονται σε ίσα διαστήματα μέσα στο 24ωρο, π.χ. 2 την ημέρα με πρώτο στις 03:30 → 03:30 και 15:30. Προτιμήστε ώρες με λίγη κίνηση στο site.</p>
                        <p><label>Διατήρηση <strong>στον server</strong> των τελευταίων <input type="number" name="backup_keep" id="tw-keep" value="<?php echo (int) $s['backup_keep']; ?>" min="1" max="365" class="small-text"> αυτόματων αντιγράφων</label>
                            <span class="description" id="tw-keep-days"></span></p>
                        <p class="description">Τα παλαιότερα αυτόματα αντίγραφα σβήνονται από τον server. Τα χειροκίνητα και όσα γίνονται «πριν από επαναφορά» δεν σβήνονται αυτόματα. Για την υπηρεσία εκτός server (OneDrive κ.λπ.) ισχύει η ξεχωριστή ρύθμιση «Διατήρηση εκεί».</p>
                        <script>
                        (function () {
                            var pd = document.getElementById('tw-per-day'), k = document.getElementById('tw-keep'), out = document.getElementById('tw-keep-days');
                            function upd() { var d = (parseInt(k.value, 10) || 0) / (parseInt(pd.value, 10) || 1); out.textContent = '≈ ' + (d >= 2 ? Math.floor(d) + ' ημέρες' : (d >= 1 ? '1 ημέρα' : 'λιγότερο από 1 ημέρα')); }
                            pd.addEventListener('change', upd); k.addEventListener('input', upd); upd();
                        })();
                        </script>
                        <p><label>Κωδικός κρυπτογράφησης (AES-256)<br><input type="password" name="backup_password" class="regular-text" autocomplete="new-password" placeholder="<?php echo $s['backup_password'] ? 'Ορισμένος – αφήστε κενό για να μείνει' : 'Χωρίς κρυπτογράφηση'; ?>"></label></p>
                        <?php if ($s['backup_password']) : ?><p><label><input type="checkbox" name="backup_password_clear" value="1"> Κατάργηση κρυπτογράφησης</label></p><?php endif; ?>
                        <p class="description">Συνιστάται: το αρχείο περιέχει προσωπικά δεδομένα πελατών. Φυλάξτε τον κωδικό σε ασφαλές μέρος – χωρίς αυτόν το αντίγραφο δεν ανοίγει. Ισχύει για τα νέα αντίγραφα.</p>
                        <p><button class="button button-primary">Αποθήκευση</button></p>
                    </form>
                </div>
            </div>
            <?php self::remote_panel(); ?>
        </div>
        <?php
    }

    private static function remote_panel() {
        $s = TWD_Settings::all();
        $post = self::url('backups');
        $svc = TWD_Backup_Remote::service();
        $tokens = TWD_Backup_Remote::tokens();
        $status = get_option(TWD_Backup_Remote::STATUS);
        $secret_ph = function ($k) use ($s) { return $s[$k] ? 'Αποθηκευμένο – αφήστε κενό για να μείνει' : ''; };
        $oauth = [
            'gdrive' => ['Google Drive', 'Google Cloud Console → APIs & Services: ενεργοποιήστε το «Google Drive API», στο «OAuth consent screen» ορίστε την εφαρμογή, και στο «Credentials» δημιουργήστε «OAuth client ID» τύπου «Web application» με Authorized redirect URI την παρακάτω διεύθυνση.', 'backup_gdrive_client_id', 'backup_gdrive_client_secret', 'Client ID', 'Client secret'],
            'onedrive' => ['OneDrive', 'Microsoft Entra admin center (portal.azure.com) → App registrations → New registration, με Redirect URI τύπου «Web» την παρακάτω διεύθυνση. Μετά: Certificates & secrets → New client secret, και API permissions → Microsoft Graph → Files.ReadWrite, offline_access, User.Read.', 'backup_onedrive_client_id', 'backup_onedrive_client_secret', 'Application (client) ID', 'Client secret (Value)'],
            'dropbox' => ['Dropbox', 'dropbox.com/developers/apps → Create app → «Scoped access», «App folder». Στο Permissions ενεργοποιήστε files.content.write, files.content.read, files.metadata.read και account_info.read, και στο Settings προσθέστε στα Redirect URIs την παρακάτω διεύθυνση.', 'backup_dropbox_app_key', 'backup_dropbox_app_secret', 'App key', 'App secret'],
        ];
        ?>
        <div class="tw-panel tw-remote">
            <h2>Αποστολή εκτός server</h2>
            <p class="description">Κάθε αυτόματο αντίγραφο ανεβαίνει και σε μια υπηρεσία της εταιρείας, ώστε να υπάρχει ακόμη κι αν χαθεί ο server. Στέλνονται μόνο <strong>κρυπτογραφημένα</strong> αντίγραφα (περιέχουν προσωπικά δεδομένα πελατών)<?php echo $s['backup_password'] ? '.' : ' – <strong class="tw-danger">ορίστε πρώτα κωδικό κρυπτογράφησης στις Ρυθμίσεις αντιγράφων.</strong>'; ?></p>
            <?php if ($status) : ?>
                <p>Τελευταία αποστολή: <?php echo esc_html(TWD_Util::datetime_label($status['at'])); ?> – <?php echo esc_html(TWD_Backup_Remote::label($status['service'])); ?> –
                    <?php echo $status['ok'] ? '<span class="tw-ok">✔ επιτυχής</span>' : '<span class="tw-danger">✘ ' . esc_html($status['message']) . '</span>'; ?></p>
            <?php endif; ?>
            <form method="post" action="<?php echo esc_url($post); ?>" id="tw-remote-form">
                <?php wp_nonce_field('twd_remote_settings'); ?><input type="hidden" name="action" value="twd_remote_settings">
                <table class="form-table">
                    <tr><th><label for="tw-backup_remote">Υπηρεσία</label></th><td><select id="tw-backup_remote" name="backup_remote">
                        <?php foreach (TWD_Backup_Remote::services() as $k => $l) printf('<option value="%s"%s>%s</option>', esc_attr($k), selected($svc, $k, false), esc_html($l)); ?>
                    </select></td></tr>
                    <tr data-remote="gdrive onedrive dropbox"><th>Φάκελος</th><td><input type="text" name="backup_remote_folder" value="<?php echo esc_attr($s['backup_remote_folder']); ?>" class="regular-text"></td></tr>
                    <tr data-remote="gdrive onedrive dropbox ftp"><th>Διατήρηση εκεί</th><td>τα τελευταία <input type="number" name="backup_remote_keep" value="<?php echo (int) $s['backup_remote_keep']; ?>" min="1" max="3650" class="small-text"> αυτόματα αντίγραφα</td></tr>
                    <tr data-remote="gdrive onedrive dropbox ftp"><th>Χειροκίνητα αντίγραφα</th><td><label><input type="checkbox" name="backup_remote_manual" value="1" <?php checked((int) $s['backup_remote_manual'], 1); ?>> Αποστολή και των χειροκίνητων αντιγράφων</label></td></tr>
                    <?php foreach ($oauth as $k => $o) : ?>
                        <tr data-remote="<?php echo esc_attr($k); ?>"><th>Ρύθμιση <?php echo esc_html($o[0]); ?></th><td>
                            <p class="description"><?php echo esc_html($o[1]); ?></p>
                            <p>Redirect URI: <code style="word-break:break-all"><?php echo esc_html(TWD_Backup_Remote::redirect_uri()); ?></code></p>
                            <?php if (!get_option('permalink_structure')) : ?><p class="tw-danger">Χρειάζονται «φιλικά» permalinks (ρυθμίσεις της ιστοσελίδας → Μόνιμοι σύνδεσμοι) για τη σύνδεση.</p><?php endif; ?>
                        </td></tr>
                        <tr data-remote="<?php echo esc_attr($k); ?>"><th><?php echo esc_html($o[4]); ?></th><td><input type="text" name="<?php echo esc_attr($o[2]); ?>" value="<?php echo esc_attr($s[$o[2]]); ?>" class="regular-text" autocomplete="off"></td></tr>
                        <tr data-remote="<?php echo esc_attr($k); ?>"><th><?php echo esc_html($o[5]); ?></th><td><input type="password" name="<?php echo esc_attr($o[3]); ?>" class="regular-text" autocomplete="new-password" placeholder="<?php echo esc_attr($secret_ph($o[3])); ?>"></td></tr>
                        <?php if ($k === 'onedrive') : ?>
                        <tr data-remote="onedrive"><th>Tenant</th><td><input type="text" name="backup_onedrive_tenant" value="<?php echo esc_attr($s['backup_onedrive_tenant']); ?>" class="regular-text"><p class="description">Για εταιρικό Microsoft 365 / OneDrive for Business: το <strong>Directory (tenant) ID</strong> (Entra → App registrations → η εφαρμογή → Overview). Το <code>common</code> λειτουργεί μόνο αν η εφαρμογή έχει δηλωθεί «multi-tenant».</p></td></tr>
                        <?php endif; ?>
                        <tr data-remote="<?php echo esc_attr($k); ?>"><th>Λογαριασμός</th><td>
                            <?php if (TWD_Backup_Remote::connected($k)) : ?>
                                <span class="tw-ok">✔ Συνδεδεμένο</span> <?php echo !empty($tokens[$k]['account']) ? esc_html($tokens[$k]['account']) : ''; ?> <small>(<?php echo esc_html(TWD_Util::datetime_label($tokens[$k]['connected_at'] ?? '')); ?>)</small>
                                <button class="button-link tw-danger" form="tw-remote-disconnect-<?php echo esc_attr($k); ?>">Αποσύνδεση</button>
                            <?php else : ?>
                                <button class="button button-primary" form="tw-remote-connect-<?php echo esc_attr($k); ?>">Σύνδεση με <?php echo esc_html($o[0]); ?></button>
                                <p class="description">Αποθηκεύστε πρώτα τα στοιχεία παραπάνω. Θα μεταφερθείτε στη σελίδα της υπηρεσίας για να εγκρίνετε την πρόσβαση με τον λογαριασμό της εταιρείας.</p>
                            <?php endif; ?>
                        </td></tr>
                    <?php endforeach; ?>
                    <tr data-remote="ftp"><th>Server</th><td><input type="text" name="backup_ftp_host" value="<?php echo esc_attr($s['backup_ftp_host']); ?>" class="regular-text" placeholder="ftp.example.gr"> θύρα <input type="number" name="backup_ftp_port" value="<?php echo (int) $s['backup_ftp_port']; ?>" class="small-text"></td></tr>
                    <tr data-remote="ftp"><th>Σύνδεση</th><td><select name="backup_ftp_mode"><option value="ftps" <?php selected($s['backup_ftp_mode'], 'ftps'); ?>>FTPS (κρυπτογραφημένη, συνιστάται)</option><option value="ftp" <?php selected($s['backup_ftp_mode'], 'ftp'); ?>>FTP (χωρίς κρυπτογράφηση)</option></select>
                        <label><input type="checkbox" name="backup_ftp_passive" value="1" <?php checked((int) $s['backup_ftp_passive'], 1); ?>> Passive mode</label></td></tr>
                    <tr data-remote="ftp"><th>Χρήστης</th><td><input type="text" name="backup_ftp_user" value="<?php echo esc_attr($s['backup_ftp_user']); ?>" class="regular-text" autocomplete="off"></td></tr>
                    <tr data-remote="ftp"><th>Κωδικός</th><td><input type="password" name="backup_ftp_password" class="regular-text" autocomplete="new-password" placeholder="<?php echo esc_attr($secret_ph('backup_ftp_password')); ?>"></td></tr>
                    <tr data-remote="ftp"><th>Φάκελος</th><td><input type="text" name="backup_ftp_path" value="<?php echo esc_attr($s['backup_ftp_path']); ?>" class="regular-text"></td></tr>
                </table>
                <p><button class="button button-primary">Αποθήκευση</button>
                    <?php if ($svc !== 'none') : ?><button class="button" form="tw-remote-test">Δοκιμή σύνδεσης</button><?php endif; ?></p>
            </form>
            <?php foreach (array_keys($oauth) as $k) : ?>
                <form method="post" action="<?php echo esc_url($post); ?>" id="tw-remote-connect-<?php echo esc_attr($k); ?>"><?php wp_nonce_field('twd_remote_connect'); ?><input type="hidden" name="action" value="twd_remote_connect"><input type="hidden" name="service" value="<?php echo esc_attr($k); ?>"></form>
                <form method="post" action="<?php echo esc_url($post); ?>" id="tw-remote-disconnect-<?php echo esc_attr($k); ?>" onsubmit="return confirm('Αποσύνδεση;')"><?php wp_nonce_field('twd_remote_disconnect'); ?><input type="hidden" name="action" value="twd_remote_disconnect"><input type="hidden" name="service" value="<?php echo esc_attr($k); ?>"></form>
            <?php endforeach; ?>
            <form method="post" action="<?php echo esc_url($post); ?>" id="tw-remote-test"><?php wp_nonce_field('twd_remote_test'); ?><input type="hidden" name="action" value="twd_remote_test"></form>
            <script>
            (function () {
                var sel = document.getElementById('tw-backup_remote');
                function show() { document.querySelectorAll('#tw-remote-form [data-remote]').forEach(function (r) { r.hidden = r.getAttribute('data-remote').split(' ').indexOf(sel.value) < 0; }); }
                sel.addEventListener('change', show); show();
            })();
            </script>
        </div>
        <?php
    }

    private static function backup_guard($action) {
        self::guard($action);
        if (!self::can_admin()) wp_die('Δεν έχετε πρόσβαση.', 403);
    }

    public static function handle_backup_create() {
        self::backup_guard('twd_backup_create');
        $r = TWD_Backup::create('manual');
        if (is_wp_error($r)) {
            self::flash('Αποτυχία: ' . esc_html($r->get_error_message()), 'error');
        } else {
            $msg = sprintf('Το αντίγραφο δημιουργήθηκε (%s). <a href="%s">Λήψη</a>', esc_html(self::size_label($r['size'])),
                esc_url(wp_nonce_url(add_query_arg(['action' => 'twd_backup_download', 'file' => $r['file']], self::url('backups')), 'twd_backup_download')));
            $type = 'success';
            if (TWD_Backup_Remote::enabled() && TWD_Settings::get('backup_remote_manual')) {
                $sent = TWD_Backup::send_remote($r);
                $msg .= $sent === true ? ' Στάλθηκε στο ' . esc_html(TWD_Backup_Remote::label()) . '.' : ' Η αποστολή απέτυχε: ' . esc_html($sent->get_error_message());
                if ($sent !== true) $type = 'warning';
            }
            self::flash($msg, $type);
        }
        self::back('tw-backups');
    }

    public static function handle_backup_download() {
        if (!current_user_can(self::cap()) || !self::can_admin()) wp_die('', 403);
        check_admin_referer('twd_backup_download');
        $b = TWD_Backup::find(sanitize_file_name(wp_unslash($_GET['file'] ?? '')));
        if (!$b) wp_die('Το αντίγραφο δεν βρέθηκε.');
        TWD_DB::log_event('backup_downloaded', ['file' => $b['file']]);
        nocache_headers();
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $b['file'] . '"');
        header('Content-Length: ' . $b['size']);
        readfile($b['path']);
        exit;
    }

    public static function handle_backup_delete() {
        self::backup_guard('twd_backup_delete');
        $b = TWD_Backup::find(sanitize_file_name(self::post('file')));
        if ($b) { @unlink($b['path']); TWD_DB::log_event('backup_deleted', ['file' => $b['file']]); self::flash('Το αντίγραφο διαγράφηκε.'); }
        self::back('tw-backups');
    }

    public static function handle_backup_restore() {
        self::backup_guard('twd_backup_restore');
        $password = (string) wp_unslash($_POST['password'] ?? '');
        if (!empty($_FILES['backup_file']['tmp_name']) && is_uploaded_file($_FILES['backup_file']['tmp_name'])) {
            $path = $_FILES['backup_file']['tmp_name'];
        } else {
            $b = TWD_Backup::find(sanitize_file_name(self::post('file')));
            if (!$b) { self::flash('Το αντίγραφο δεν βρέθηκε.', 'error'); self::back('tw-backups'); }
            $path = $b['path'];
        }
        $r = TWD_Backup::restore($path, $password);
        if (is_wp_error($r)) {
            self::flash('Η επαναφορά δεν έγινε: ' . esc_html($r->get_error_message()), 'error');
        } else {
            self::flash(sprintf('Η επαναφορά ολοκληρώθηκε από το αντίγραφο της %s: %d εγγυήσεις, %d σειριακοί, %d αρχεία. Η προηγούμενη κατάσταση φυλάχθηκε ως αντίγραφο «Πριν από επαναφορά».',
                esc_html(TWD_Util::datetime_label($r['manifest']['created_at'] ?? '')), $r['rows']['warranties'] ?? 0, $r['rows']['serials'] ?? 0, $r['files']));
        }
        self::back('tw-backups');
    }

    public static function handle_remote_settings() {
        self::backup_guard('twd_remote_settings');
        $svc = sanitize_key(self::post('backup_remote'));
        $v = [
            'backup_remote' => isset(TWD_Backup_Remote::services()[$svc]) ? $svc : 'none',
            'backup_remote_folder' => trim(sanitize_text_field(self::post('backup_remote_folder')), '/ ') ?: 'Warranty Manager Backups',
            'backup_remote_keep' => max(1, min(3650, (int) self::post('backup_remote_keep'))),
            'backup_remote_manual' => empty($_POST['backup_remote_manual']) ? 0 : 1,
            'backup_ftp_passive' => empty($_POST['backup_ftp_passive']) ? 0 : 1,
            'backup_ftp_mode' => self::post('backup_ftp_mode') === 'ftp' ? 'ftp' : 'ftps',
            'backup_ftp_port' => max(1, min(65535, (int) self::post('backup_ftp_port') ?: 21)),
        ];
        foreach (['backup_gdrive_client_id', 'backup_onedrive_client_id', 'backup_dropbox_app_key', 'backup_onedrive_tenant', 'backup_ftp_host', 'backup_ftp_user', 'backup_ftp_path'] as $k) {
            if (isset($_POST[$k])) $v[$k] = sanitize_text_field(self::post($k));
        }
        foreach (['backup_gdrive_client_secret', 'backup_onedrive_client_secret', 'backup_dropbox_app_secret', 'backup_ftp_password'] as $k) {
            $val = (string) wp_unslash($_POST[$k] ?? '');
            if ($val !== '') $v[$k] = trim($val);
        }
        if ($v['backup_remote_folder'] !== TWD_Settings::get('backup_remote_folder')) $v['backup_gdrive_folder_id'] = '';
        TWD_Settings::update($v);
        TWD_DB::log_event('remote_settings', ['service' => $v['backup_remote']]);
        self::flash('Οι ρυθμίσεις αποστολής αποθηκεύτηκαν.' . ($v['backup_remote'] !== 'none' && !TWD_Settings::get('backup_password') ? ' Ορίστε κωδικό κρυπτογράφησης – χωρίς αυτόν δεν στέλνονται αντίγραφα.' : ''));
        self::back('tw-backups');
    }

    public static function handle_remote_connect() {
        self::backup_guard('twd_remote_connect');
        $url = TWD_Backup_Remote::auth_url(sanitize_key(self::post('service')));
        if (is_wp_error($url)) { self::flash(esc_html($url->get_error_message()), 'error'); self::back('tw-backups'); }
        wp_redirect($url); // external: the provider's consent page
        exit;
    }

    public static function handle_remote_disconnect() {
        self::backup_guard('twd_remote_disconnect');
        $svc = sanitize_key(self::post('service'));
        TWD_Backup_Remote::disconnect($svc);
        TWD_DB::log_event('remote_disconnected', ['service' => $svc]);
        self::flash('Αποσυνδέθηκε.');
        self::back('tw-backups');
    }

    public static function handle_remote_test() {
        self::backup_guard('twd_remote_test');
        $r = TWD_Backup_Remote::test();
        self::flash($r === true ? 'Η σύνδεση με ' . esc_html(TWD_Backup_Remote::label()) . ' λειτουργεί: ανέβηκε και σβήστηκε ένα δοκιμαστικό αρχείο.' : 'Αποτυχία: ' . esc_html($r->get_error_message()), $r === true ? 'success' : 'error');
        self::back('tw-backups');
    }

    public static function handle_backup_send() {
        self::backup_guard('twd_backup_send');
        $b = TWD_Backup::find(sanitize_file_name(self::post('file')));
        if (!$b) { self::flash('Το αντίγραφο δεν βρέθηκε.', 'error'); self::back('tw-backups'); }
        $r = TWD_Backup_Remote::send($b['path']);
        self::flash($r === true ? 'Το αντίγραφο στάλθηκε στο ' . esc_html(TWD_Backup_Remote::label()) . '.' : 'Αποτυχία αποστολής: ' . esc_html($r->get_error_message()), $r === true ? 'success' : 'error');
        self::back('tw-backups');
    }

    public static function handle_backup_settings() {
        self::backup_guard('twd_backup_settings');
        $time = self::post('backup_time');
        $values = [
            'backup_daily' => empty($_POST['backup_daily']) ? 0 : 1,
            'backup_keep' => max(1, min(365, (int) self::post('backup_keep'))),
            'backup_per_day' => isset(TWD_Backup::PER_DAY[(int) self::post('backup_per_day')]) ? (int) self::post('backup_per_day') : 1,
            'backup_time' => preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $time) ? $time : '03:30',
        ];
        $pw = (string) wp_unslash($_POST['backup_password'] ?? '');
        if ($pw !== '') $values['backup_password'] = $pw;
        if (!empty($_POST['backup_password_clear'])) $values['backup_password'] = '';
        TWD_Settings::update($values);
        TWD_Backup::reschedule();
        TWD_DB::log_event('backup_settings', ['auto' => $values['backup_daily'], 'per_day' => $values['backup_per_day'], 'time' => $values['backup_time'], 'keep' => $values['backup_keep'], 'encrypted' => (string) TWD_Settings::get('backup_password') !== '']);
        self::flash('Οι ρυθμίσεις αντιγράφων αποθηκεύτηκαν.');
        self::back('tw-backups');
    }

    // ------------------------------------------------------------------ Brevo tools

    private static function brevo_tools() {
        $post = self::url('settings', ['tab' => 'brevo']);
        $log = get_option(TWD_Brevo::LOG_OPTION, []);
        ?>
        <h2>Έλεγχος &amp; ρύθμιση</h2>
        <form method="post" action="<?php echo esc_url($post); ?>" class="tw-inline-form">
            <?php wp_nonce_field('twd_brevo_tool'); ?><input type="hidden" name="action" value="twd_brevo_tool">
            <button class="button" name="tool" value="account">Έλεγχος σύνδεσης &amp; μονάδων SMS</button>
            <button class="button" name="tool" value="webhook">Ρύθμιση αναφορών email στο Brevo</button>
        </form>
        <h2>Τελευταίες αναφορές από το Brevo</h2>
        <p class="description">Χρήσιμο για έλεγχο μετά την ενεργοποίηση: εδώ φαίνεται ό,τι στέλνει το Brevo για τα μηνύματά σας.</p>
        <table class="widefat striped"><thead><tr><th>Λήψη</th><th>Συμβάν</th><th>Παραλήπτης</th><th>Μήνυμα</th></tr></thead><tbody>
        <?php if (!$log) echo '<tr><td colspan="4">Καμία αναφορά ακόμη.</td></tr>'; ?>
        <?php foreach (array_slice((array) $log, 0, 30) as $l) : $d = (array) $l['data']; ?>
            <tr><td><?php echo esc_html(TWD_Util::datetime_label($l['at'])); ?></td>
                <td><?php echo esc_html((string) ($d['event'] ?? ($d['msg_status'] ?? ($d['status'] ?? '?')))); ?><?php echo !empty($d['reason']) ? '<br><small>' . esc_html((string) $d['reason']) . '</small>' : ''; ?></td>
                <td><?php echo esc_html((string) ($d['email'] ?? ($d['to'] ?? ($d['recipient'] ?? '')))); ?></td>
                <td><small><?php echo esc_html((string) ($d['message-id'] ?? ($d['messageId'] ?? ''))); ?></small></td></tr>
        <?php endforeach; ?>
        </tbody></table>
        <?php
    }

    public static function handle_brevo_tool() {
        self::guard('twd_brevo_tool');
        if (self::post('tool') === 'webhook') {
            $r = TWD_Brevo::ensure_email_webhook();
            self::flash($r === true ? 'Οι αναφορές παράδοσης email ρυθμίστηκαν στο Brevo.' : 'Αποτυχία: ' . esc_html($r), $r === true ? 'success' : 'error');
        } else {
            $a = TWD_Brevo::account();
            if (is_wp_error($a)) {
                self::flash('Αποτυχία σύνδεσης: ' . esc_html($a->get_error_message()), 'error');
            } else {
                self::flash(sprintf('Σύνδεση OK – λογαριασμός %s%s. Μονάδες SMS: %s.%s', esc_html($a['email']), $a['company'] ? ' (' . esc_html($a['company']) . ')' : '',
                    $a['sms_credits'] === null ? '—' : esc_html((string) $a['sms_credits']), $a['email_plan'] ? ' Πακέτο: ' . esc_html($a['email_plan']) . '.' : ''));
            }
        }
        self::back('tw-settings', ['tab' => 'brevo']);
    }

    // ------------------------------------------------------------------ documentation

    /** Public logo image (not in the private folder: it is shown on public pages and in emails). @return string|WP_Error URL */
    private static function store_logo(array $file) {
        if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name']) || (int) $file['error'] !== UPLOAD_ERR_OK) return new WP_Error('logo', 'Το λογότυπο δεν ανέβηκε σωστά.');
        if ((int) $file['size'] > 2 * 1048576) return new WP_Error('logo', 'Το λογότυπο ξεπερνά τα 2 MB.');
        $check = wp_check_filetype_and_ext($file['tmp_name'], $file['name'], ['png' => 'image/png', 'jpg|jpeg' => 'image/jpeg', 'webp' => 'image/webp']);
        if (empty($check['ext']) || empty($check['type'])) return new WP_Error('logo', 'Επιτρέπονται μόνο εικόνες PNG, JPG ή WEBP.');
        $u = wp_upload_dir();
        $dir = trailingslashit($u['basedir']) . 'thermic-warranty-brand';
        if (!is_dir($dir)) wp_mkdir_p($dir);
        $name = 'logo-' . bin2hex(random_bytes(4)) . '.' . $check['ext'];
        if (!@move_uploaded_file($file['tmp_name'], $dir . '/' . $name)) return new WP_Error('logo', 'Αδυναμία αποθήκευσης του λογοτύπου.');
        @chmod($dir . '/' . $name, 0644);
        TWD_DB::log_event('logo_uploaded', ['file' => $name]);
        return trailingslashit($u['baseurl']) . 'thermic-warranty-brand/' . $name;
    }

    /** Print / PDF document of a warranty card (own page, no console chrome). */
    public static function render_print($id) {
        $w = TWD_Warranty::get($id);
        if (!$w) wp_die('Η εγγύηση δεν βρέθηκε.');
        $s = TWD_Settings::all();
        TWD_DB::log_event('card_printed', '', $w->id, $w->serial_id);
        include TWD_DIR . 'templates/print-warranty.php';
    }

    public static function page_help() {
        $s = TWD_Settings::all();
        include TWD_DIR . 'templates/help.php';
    }

    public static function page_log() { TWD_Activity::page(); }
    public static function handle_log_export() { TWD_Activity::export(); }
    public static function handle_log_verify() { TWD_Activity::verify_action(); }
    public static function handle_log_archive() { TWD_Activity::archive_action(); }
    public static function handle_log_archive_settings() { TWD_Activity::archive_settings_action(); }

    public static function page_changelog() {
        $log = include TWD_DIR . 'includes/changelog.php';
        ?>
        <div class="wrap tw-wrap">
            <h1>Ιστορικό εκδόσεων</h1>
            <p class="description" style="max-width:760px;margin-top:-10px">Οι αλλαγές σε κάθε έκδοση του <?php echo esc_html(TWD_App::APP_NAME); ?>, με τη νεότερη πρώτη. Αναλυτικά για κάθε λειτουργία: <a href="<?php echo esc_url(self::url('help')); ?>">Οδηγός χρήσης</a>.</p>
            <div class="tw-changelog">
            <?php foreach ($log as $ver => $items) : ?>
                <section class="tw-help-card tw-changelog-item<?php echo $ver === TWD_VERSION ? ' is-current' : ''; ?>">
                    <h2>Έκδοση <?php echo esc_html($ver); ?><?php if ($ver === TWD_VERSION) : ?> <span class="tw-changelog-badge">Τρέχουσα</span><?php endif; ?></h2>
                    <ul><?php foreach ($items as $it) echo '<li>' . esc_html($it) . '</li>'; ?></ul>
                </section>
            <?php endforeach; ?>
            </div>
        </div>
        <?php
    }

    // ------------------------------------------------------------------ team

    public static function page_team() {
        if (!current_user_can('manage_options') && !current_user_can('twd_manage_team')) { echo '<p>Δεν έχετε πρόσβαση.</p>'; return; }
        $users = get_users(['role__in' => ['administrator', TWD_App::ROLE], 'orderby' => 'display_name']);
        $post = self::url('team');
        ?>
        <div class="wrap tw-wrap">
            <h1>Ομάδα</h1>
            <?php self::notice(); ?>
            <p class="description">Τα μέλη της ομάδας συνδέονται στο <code><?php echo esc_html(TWD_App::admin_url()); ?></code> με email και κωδικό<?php echo TWD_Settings::get('staff_2fa') ? ', και επιβεβαιώνουν με κωδικό μίας χρήσης στο email' : ''; ?>. Έχουν δικαιώματα στο <?php echo esc_html(TWD_App::APP_NAME); ?> της <?php echo esc_html(TWD_Settings::get('company_name')); ?>, δεν έχουν πρόσβαση στη διαχείριση της Ιστοσελίδας.</p>
            <table class="widefat striped"><thead><tr><th>Όνομα</th><th>Email</th><th>Ρόλος</th><th>Τελευταία σύνδεση</th><th></th></tr></thead><tbody>
            <?php foreach ($users as $u) : $is_admin = user_can($u, 'manage_options'); $last = get_user_meta($u->ID, 'twd_last_login', true); ?>
                <tr><td><?php echo esc_html($u->display_name); ?></td><td><?php echo esc_html($u->user_email); ?></td>
                    <td><?php echo $is_admin ? 'Διαχειριστής' : (user_can($u, 'twd_manage_team') ? 'Υπεύθυνος εγγυήσεων (διαχείριση ομάδας)' : 'Διαχειριστής εγγυήσεων'); ?></td>
                    <td><?php echo $last ? esc_html(TWD_Util::datetime_label($last)) : '—'; ?></td>
                    <td><?php if (!$is_admin && $u->ID !== get_current_user_id()) : ?>
                        <form method="post" action="<?php echo esc_url($post); ?>" onsubmit="return confirm('Αφαίρεση πρόσβασης;')"><?php wp_nonce_field('twd_team_remove'); ?>
                            <input type="hidden" name="action" value="twd_team_remove"><input type="hidden" name="user_id" value="<?php echo (int) $u->ID; ?>">
                            <button class="button-link tw-danger">Αφαίρεση πρόσβασης</button></form>
                    <?php endif; ?></td></tr>
            <?php endforeach; ?>
            </tbody></table>
            <div class="tw-panel" style="max-width:640px;margin-top:20px">
                <h2>Νέο μέλος</h2>
                <form method="post" action="<?php echo esc_url($post); ?>">
                    <?php wp_nonce_field('twd_team_add'); ?><input type="hidden" name="action" value="twd_team_add">
                    <p><label>Ονοματεπώνυμο<br><input type="text" name="name" class="regular-text" required></label></p>
                    <p><label>Email<br><input type="email" name="email" class="regular-text" required></label></p>
                    <p><label><input type="checkbox" name="manage_team" value="1"> Μπορεί να διαχειρίζεται και την ομάδα</label></p>
                    <p><button class="button button-primary">Προσθήκη &amp; αποστολή πρόσκλησης</button></p>
                    <p class="description">Το μέλος λαμβάνει email με τον σύνδεσμο του διαχειριστικού και ορίζει μόνο του κωδικό από την επιλογή «Πρώτη σύνδεση / ξέχασα τον κωδικό».</p>
                </form>
            </div>
        </div>
        <?php
    }

    public static function handle_team_add() {
        self::guard('twd_team_add');
        if (!current_user_can('manage_options') && !current_user_can('twd_manage_team')) wp_die('', 403);
        $email = strtolower(sanitize_email(self::post('email')));
        $name = sanitize_text_field(self::post('name'));
        if (!is_email($email)) { self::flash('Μη έγκυρο email.', 'error'); self::back('tw-team'); }
        $user = get_user_by('email', $email);
        if (!$user) {
            $login = sanitize_user(current(explode('@', $email)), true) ?: 'tw-user';
            $base = $login; $i = 1;
            while (username_exists($login)) $login = $base . (++$i);
            $id = wp_insert_user(['user_login' => $login, 'user_email' => $email, 'display_name' => $name, 'first_name' => $name,
                'user_pass' => wp_generate_password(32, true, true), 'role' => TWD_App::ROLE]);
            if (is_wp_error($id)) { self::flash($id->get_error_message(), 'error'); self::back('tw-team'); }
            $user = get_user_by('id', $id);
        } elseif (!user_can($user, 'manage_options')) {
            $user->add_role(TWD_App::ROLE);
        }
        if (!empty($_POST['manage_team'])) $user->add_cap('twd_manage_team'); else $user->remove_cap('twd_manage_team');
        $s = TWD_Settings::all();
        TWD_Messenger::send_email($email, sprintf('Πρόσβαση στο διαχειριστικό εγγυήσεων – %s', $s['company_name']),
            sprintf("Γεια σας %s,\n\nσας δόθηκε πρόσβαση στο διαχειριστικό εγγυήσεων της %s:\n%s\n\nΓια την πρώτη σύνδεση επιλέξτε «Πρώτη σύνδεση / ξέχασα τον κωδικό», βάλτε το email σας (%s) και ορίστε κωδικό.",
                $name ?: $user->display_name, $s['company_name'], TWD_App::admin_url(), $email));
        TWD_DB::log_event('team_added', ['user' => $email]);
        self::flash(sprintf('Το μέλος %s προστέθηκε και ενημερώθηκε με email.', esc_html($email)));
        self::back('tw-team');
    }

    public static function handle_team_remove() {
        self::guard('twd_team_remove');
        if (!current_user_can('manage_options') && !current_user_can('twd_manage_team')) wp_die('', 403);
        $user = get_user_by('id', (int) self::post('user_id'));
        if ($user && !user_can($user, 'manage_options') && $user->ID !== get_current_user_id()) {
            $user->remove_role(TWD_App::ROLE);
            $user->remove_cap('twd_manage_team');
            $user->remove_cap(self::CAP);
            WP_Session_Tokens::get_instance($user->ID)->destroy_all();
            TWD_DB::log_event('team_removed', ['user' => $user->user_email]);
            self::flash('Η πρόσβαση αφαιρέθηκε.');
        }
        self::back('tw-team');
    }

    // ------------------------------------------------------------------ GDPR erasure requests (WordPress user_request posts)

    private static function erasure_requests() {
        $reqs = get_posts(['post_type' => 'user_request', 'post_name__in' => ['remove_personal_data'], 'post_status' => ['request-pending', 'request-confirmed', 'request-completed'], 'numberposts' => 50, 'orderby' => 'date', 'order' => 'DESC']);
        $st = ['request-pending' => 'Αναμένει επιβεβαίωση από τον πελάτη', 'request-confirmed' => 'Επιβεβαιωμένο – προς εκτέλεση', 'request-completed' => 'Ολοκληρώθηκε'];
        echo '<h2>Αιτήματα διαγραφής</h2><table class="widefat striped"><thead><tr><th>Ημ/νία</th><th>Email</th><th>Κατάσταση</th><th></th></tr></thead><tbody>';
        if (!$reqs) echo '<tr><td colspan="4">Κανένα αίτημα.</td></tr>';
        foreach ($reqs as $r) {
            echo '<tr><td>' . esc_html(TWD_Util::datetime_label($r->post_date)) . '</td><td>' . esc_html($r->post_title) . '</td><td>' . esc_html($st[$r->post_status] ?? $r->post_status) . '</td><td>';
            if ($r->post_status === 'request-confirmed') {
                echo '<form method="post" action="' . esc_url(self::url('settings', ['tab' => 'privacy'])) . '" onsubmit="return confirm(\'Εκτέλεση διαγραφής για ' . esc_attr($r->post_title) . ';\')">';
                wp_nonce_field('twd_process_erasure');
                echo '<input type="hidden" name="action" value="twd_process_erasure"><input type="hidden" name="request_id" value="' . (int) $r->ID . '"><button class="button">Εκτέλεση</button></form>';
            }
            echo '</td></tr>';
        }
        echo '</tbody></table>';
    }

    public static function handle_process_erasure() {
        self::guard('twd_process_erasure');
        $r = get_post((int) self::post('request_id'));
        if (!$r || $r->post_type !== 'user_request' || $r->post_status !== 'request-confirmed') {
            self::flash('Το αίτημα δεν βρέθηκε ή δεν έχει επιβεβαιωθεί.', 'error');
            self::back('tw-settings', ['tab' => 'privacy']);
        }
        $res = TWD_Privacy::eraser($r->post_title);
        wp_update_post(['ID' => $r->ID, 'post_status' => 'request-completed']);
        update_post_meta($r->ID, '_wp_user_request_completed_timestamp', time());
        TWD_DB::log_event('erasure_processed', ['email' => TWD_Util::mask_email($r->post_title), 'removed' => $res['items_removed'], 'retained' => $res['items_retained']]);
        self::flash('Ολοκληρώθηκε. ' . esc_html(implode(' ', $res['messages']) ?: 'Τα στοιχεία ανωνυμοποιήθηκαν.'));
        self::back('tw-settings', ['tab' => 'privacy']);
    }

    // ------------------------------------------------------------------ handlers

    public static function handle_save_settings() {
        self::guard('twd_save_settings');
        $tab = sanitize_key(self::post('tab'));
        $in = isset($_POST['s']) && is_array($_POST['s']) ? wp_unslash($_POST['s']) : [];
        $defaults = TWD_Settings::defaults();
        $checkboxes = [
            'general' => ['admin_digest'],
            'app' => ['staff_2fa'],
            'brevo' => ['brevo_email', 'brevo_sms', 'fallback_channel'],
            'schedule' => ['lock_on_missed_service', 'lock_on_expiry', 'notify_partner', 'service_notify_company'],
            'sms' => ['sms_enabled'],
            'security' => ['turnstile_staff', 'turnstile_public'],
            'sender' => [],
        ];
        $numbers = ['service_submit_window_days', 'service_resubmit_days', 'warranty_years', 'service_interval_years', 'lock_offset', 'catchup_days', 'max_registration_delay_days', 'invoice_max_mb', 'retention_months_after_end'];
        $multiline = ['erase_text', 'erase_text_en', 'sms_headers', 'sms_body', 'terms_label', 'accuracy_label', 'marketing_label', 'email_footer_login', 'email_footer_service', 'terms_label_en', 'accuracy_label_en', 'marketing_label_en', 'email_footer_login_en', 'email_footer_service_en'];
        $urls = ['portal_url', 'register_url', 'privacy_url', 'portal_url_en', 'register_url_en', 'privacy_url_en', 'sms_url', 'logo_url'];
        $values = [];
        foreach ($in as $k => $v) {
            if (!array_key_exists($k, $defaults) || $k === 'templates' || $k === 'templates_en' || strpos($k, 'ip_') === 0) continue; // IP lock: wp-admin only
            if (in_array($k, $numbers, true)) $values[$k] = max(0, (int) $v);
            elseif (in_array($k, $urls, true)) $values[$k] = esc_url_raw(trim($v));
            elseif (in_array($k, $multiline, true)) $values[$k] = sanitize_textarea_field($v);
            elseif ($k === 'admin_slug' || $k === 'public_slug') $values[$k] = sanitize_title($v) ?: $defaults[$k];
            elseif ($k === 'invoice_mode') $values[$k] = in_array($v, ['required', 'optional', 'off'], true) ? $v : 'required';
            elseif ($k === 'service_proof_mode') $values[$k] = in_array($v, ['upload', 'fields', 'both'], true) ? $v : 'upload';
            elseif ($k === 'tax_countries') $values[$k] = array_values(array_intersect(array_keys(TWD_Util::countries()), array_map('strtoupper', array_map('sanitize_key', (array) $v))));
            elseif ($k === 'otp_minutes') $values[$k] = in_array((int) $v, TWD_OTP::MINUTE_CHOICES, true) ? (int) $v : 2;
            elseif ($k === 'portal_session_minutes') $values[$k] = in_array((int) $v, TWD_OTP::SESSION_CHOICES, true) ? (int) $v : 60;
            elseif ($k === 'staff_session_minutes') $values[$k] = in_array((int) $v, TWD_Staff_Auth::SESSION_CHOICES, true) ? (int) $v : 120;
            elseif ($k === 'pdf_watermark') $values[$k] = in_array($v, ['text', 'logo', 'none'], true) ? $v : 'text';
            elseif ($k === 'pdf_watermark_opacity') $values[$k] = max(0, min(100, (int) $v));
            elseif ($k === 'brand_color' || $k === 'brand_color_2') $values[$k] = sanitize_hex_color($v) ?: $defaults[$k];
            elseif ($k === 'reminder_offsets') $values[$k] = implode(',', array_filter(array_map('trim', explode(',', $v)), function ($p) { return preg_match('/^[+-]?\d+$/', $p); }));
            else $values[$k] = sanitize_text_field($v);
        }
        foreach ($checkboxes[$tab] ?? [] as $cb) $values[$cb] = empty($in[$cb]) ? 0 : 1;
        if ($tab === 'privacy') {
            foreach (['el', 'en'] as $pl) {
                if (isset($_POST['privacy_text_' . $pl]) && TWD_Privacy_Text::save($pl, wp_unslash((string) $_POST['privacy_text_' . $pl]))) {
                    TWD_DB::log_event('privacy_text_saved', ['lang' => strtoupper($pl)]);
                }
            }
        }
        if (isset($values['warranty_years'])) $values['warranty_years'] = max(1, $values['warranty_years']);
        if ($tab === 'sms' && isset($values['sms_method'])) $values['sms_method'] = strtoupper($values['sms_method']) === 'GET' ? 'GET' : 'POST';

        $tl = self::post('tl') === 'en' ? 'en' : 'el';
        if ($tab === 'messages' && isset($_POST['tpl']) && is_array($_POST['tpl'])) {
            $tpl = [];
            foreach (wp_unslash($_POST['tpl']) as $key => $f) {
                if (!isset(TWD_Settings::template_defaults()[$key]) || !is_array($f)) continue;
                $tpl[$key] = [
                    'subject' => sanitize_text_field($f['subject'] ?? ''),
                    'body' => sanitize_textarea_field($f['body'] ?? ''),
                    'sms' => sanitize_textarea_field($f['sms'] ?? ''),
                ];
            }
            $values[$tl === 'en' ? 'templates_en' : 'templates'] = $tpl;
        }
        $msg = 'Οι ρυθμίσεις αποθηκεύτηκαν.';
        if ($tab === 'app') {
            if (!empty($_POST['logo_remove'])) $values['logo_url'] = '';
            if (!empty($_FILES['logo_file']['name'])) {
                $logo = self::store_logo($_FILES['logo_file']);
                if (is_wp_error($logo)) { self::flash(esc_html($logo->get_error_message()), 'error'); self::back('tw-settings', ['tab' => $tab]); }
                $values['logo_url'] = $logo;
                $msg .= ' Το λογότυπο ανέβηκε.';
            }
        }
        if ($tab === 'security') {
            $newsecret = trim(self::post('turnstile_secret_new'));
            if ($newsecret !== '') $values['turnstile_secret'] = sanitize_text_field($newsecret);
            unset($values['turnstile_secret_new']);
            if (!empty($values['turnstile_staff']) || !empty($values['turnstile_public'])) {
                $site = $values['turnstile_site_key'] ?? '';
                $secret = $values['turnstile_secret'] ?? TWD_Settings::get('turnstile_secret');
                $token = sanitize_text_field(self::post('cf-turnstile-response'));
                if ($site === '' || $secret === '') $err = 'Συμπληρώστε Site key και Secret key.';
                elseif ($token === '') $err = 'Η «Δοκιμή κλειδιών» δεν ολοκληρώθηκε. Ελέγξτε ότι το Site key είναι σωστό και ότι το domain έχει δηλωθεί στο widget της Cloudflare.';
                else {
                    $r = TWD_Guard::siteverify($secret, $token);
                    $err = $r === true ? '' : ($r === 'invalid-input-secret' ? 'Το Secret key δεν είναι σωστό.'
                        : ($r === 'network' ? 'Δεν ήταν δυνατή η επικοινωνία με την Cloudflare. Δοκιμάστε ξανά.'
                        : 'Ο έλεγχος απέτυχε (' . esc_html($r) . '). Ελέγξτε ότι Site key και Secret key ανήκουν στο ίδιο widget.'));
                }
                if ($err !== '') {
                    $values['turnstile_staff'] = 0;
                    $values['turnstile_public'] = 0;
                    TWD_Settings::update($values);
                    self::flash('Τα κλειδιά αποθηκεύτηκαν, αλλά το Turnstile δεν ενεργοποιήθηκε: ' . $err, 'error');
                    self::back('tw-settings', ['tab' => $tab]);
                }
                $msg .= ' Το Turnstile επιβεβαιώθηκε και είναι ενεργό.';
            }
        }
        if ($tab === 'brevo') {
            $newkey = trim(self::post('brevo_api_key_new'));
            if ($newkey !== '') $values['brevo_api_key'] = sanitize_text_field($newkey);
            unset($values['brevo_webhook_token']);
            if (!empty($values['brevo_email']) && !is_email($values['brevo_sender_email'] ?? '') && !is_email(TWD_Settings::get('email_from_address'))) {
                $msg .= ' Προσοχή: συμπληρώστε email αποστολέα επιβεβαιωμένο στο Brevo.';
            }
        }
        if ($tab === 'terms' && isset($_POST['terms_text'])) {
            $before = (int) TWD_Settings::current_terms()['version'];
            $v = TWD_Settings::save_terms(sanitize_textarea_field(wp_unslash($_POST['terms_text'])));
            if ($v !== $before) {
                $msg .= sprintf(' Δημιουργήθηκε νέα έκδοση όρων v%d.', $v);
                TWD_DB::log_event('terms_published', ['version' => $v]);
            }
            $en_text = trim(sanitize_textarea_field(wp_unslash($_POST['terms_text_en'] ?? '')));
            if ($en_text !== '' || TWD_Settings::terms_versions('en')) {
                $before_en = TWD_Settings::terms_versions('en') ? (int) TWD_Settings::current_terms('en')['version'] : 0;
                $ve = TWD_Settings::save_terms($en_text, 'en');
                if ($ve !== $before_en) {
                    $msg .= sprintf(' Δημιουργήθηκε νέα αγγλική έκδοση όρων v%d.', $ve);
                    TWD_DB::log_event('terms_published', ['version' => $ve . ' (EN)']);
                }
            }
        }
        if ($tab === 'schedule') {
            $old = TWD_Settings::all();
            foreach (['warranty_years', 'service_interval_years'] as $k) {
                if (isset($values[$k]) && (int) $old[$k] !== (int) $values[$k]) {
                    $msg .= ' Προσοχή: η αλλαγή διάρκειας ισχύει για νέες ενεργοποιήσεις· η ημερομηνία λήξης των υπαρχουσών εγγυήσεων δεν αλλάζει.';
                    break;
                }
            }
        }
        $old = TWD_Settings::all();
        if ((isset($values['admin_slug']) && $values['admin_slug'] !== $old['admin_slug']) || (isset($values['public_slug']) && $values['public_slug'] !== $old['public_slug'])) {
            if (($values['admin_slug'] ?? $old['admin_slug']) === ($values['public_slug'] ?? $old['public_slug'])) {
                self::flash('Οι δύο διευθύνσεις πρέπει να είναι διαφορετικές.', 'error');
                self::back('tw-settings', ['tab' => $tab]);
            }
            update_option('twd_flush_rewrite', 1, false);
            TWD_Settings::update($values);
            // The admin URL itself may have changed: go to the new one.
            set_transient('twd_notice_' . get_current_user_id(), ['text' => $msg . ' Η διεύθυνση άλλαξε.', 'type' => 'success'], 120);
            TWD_App::register_rewrites();
            flush_rewrite_rules(false);
            delete_option('twd_flush_rewrite');
            wp_safe_redirect(TWD_App::admin_url('settings', ['tab' => $tab]));
            exit;
        }
        $before = TWD_Settings::all();
        TWD_Settings::update($values);
        // What changed, for the activity log; secrets are noted as changed without their values.
        $secret = ['brevo_api_key', 'turnstile_secret', 'backup_password', 'backup_gdrive_client_secret', 'backup_onedrive_client_secret', 'backup_dropbox_app_secret', 'backup_ftp_password', 'sms_headers', 'brevo_webhook_token'];
        $changed = [];
        foreach ($values as $k => $v) {
            $o = $before[$k] ?? null;
            if (wp_json_encode($o) === wp_json_encode($v)) continue;
            if (in_array($k, $secret, true)) $changed[] = $k . ' (άλλαξε)';
            elseif (is_array($v) || is_array($o) || mb_strlen((string) $v) > 60 || mb_strlen((string) $o) > 60) $changed[] = $k;
            else $changed[] = $k . ': ' . ((string) $o === '' ? '—' : (string) $o) . ' → ' . ((string) $v === '' ? '—' : (string) $v);
        }
        if ($changed) TWD_DB::log_event('settings_saved', ['section' => $tab, 'changed' => implode(' · ', $changed)]);
        self::flash($msg);
        self::back('tw-settings', ['tab' => $tab, 'tl' => $tl === 'en' && $tab === 'messages' ? 'en' : null]);
    }

    public static function handle_terms_view() {
        if (!current_user_can(self::cap())) wp_die('', 403);
        check_admin_referer('twd_terms_view');
        $t = TWD_Terms::version((int) ($_GET['s'] ?? TWD_Terms::BASE) ?: TWD_Terms::BASE, (int) ($_GET['v'] ?? 0), self::q('tl') === 'en' ? 'en' : 'el');
        if (!$t) wp_die('Δεν βρέθηκε.');
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><meta charset="utf-8"><title>' . esc_html($t['set_name']) . '</title><body style="font-family:sans-serif;max-width:800px;margin:2em auto;line-height:1.5">';
        echo '<p><strong>' . esc_html($t['set_name']) . ($t['lang'] === 'en' ? ' (English)' : '') . '</strong> – κείμενο της ' . esc_html(TWD_Util::datetime_label($t['published_at'])) . '<br><small>SHA-256: ' . esc_html($t['hash']) . '</small></p><hr>';
        echo '<style>table{border-collapse:collapse;margin:1em 0}th,td{border:1px solid #ccc;padding:6px 10px;text-align:left;vertical-align:top}th{background:#f3f4f6}</style>' . TWD_Terms::html($t['text']) . '</body>';
        exit;
    }

    public static function handle_import() {
        self::guard('twd_import');
        if (empty($_FILES['file']['tmp_name']) || !is_uploaded_file($_FILES['file']['tmp_name'])) {
            self::flash('Επιλέξτε αρχείο.', 'error');
            self::back('tw-serials');
        }
        $rows = TWD_Importer::read_file($_FILES['file']['tmp_name'], $_FILES['file']['name']);
        if (is_wp_error($rows)) {
            self::flash($rows->get_error_message(), 'error');
            self::back('tw-serials');
        }
        $res = TWD_Importer::import(TWD_Importer::to_records($rows), [
            'product_code' => sanitize_text_field(self::post('default_code')),
            'product_name' => sanitize_text_field(self::post('default_name')),
        ], self::post('batch'));
        set_transient('twd_import_result_' . get_current_user_id(), $res, 600);
        self::back('tw-serials', ['batch' => $res['inserted'] && strpos($res['batch'], ', ') === false ? $res['batch'] : null]);
    }

    public static function handle_template() {
        if (!current_user_can(self::cap())) wp_die('', 403);
        check_admin_referer('twd_template');
        $file = TWD_Importer::template_xlsx();
        nocache_headers();
        if ($file) {
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="protypo-seiriakon.xlsx"');
            header('Content-Length: ' . filesize($file));
            readfile($file);
            @unlink($file);
        } else { // no ZipArchive on the server: CSV that Excel opens the same way
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="protypo-seiriakon.csv"');
            echo "\xEF\xBB\xBF" . implode(';', TWD_Importer::TEMPLATE_HEADERS) . "\r\n";
        }
        exit;
    }

    public static function handle_add_serial() {
        self::guard('twd_add_serial');
        $records = [];
        foreach (preg_split('/\r?\n/', self::post('serials')) as $line) {
            if (trim($line) === '') continue;
            $records[] = ['serial' => TWD_Util::normalize_serial($line), 'product_code' => sanitize_text_field(self::post('product_code')), 'product_name' => sanitize_text_field(self::post('product_name')), 'notes' => ''];
        }
        $res = TWD_Importer::import($records, [], self::post('batch'));
        set_transient('twd_import_result_' . get_current_user_id(), $res, 600);
        self::back('tw-serials', ['batch' => $res['inserted'] && strpos($res['batch'], ', ') === false ? $res['batch'] : null]);
    }

    /** Renames a whole batch, or moves the ticked serials to another (new or existing) batch. */
    public static function handle_serial_batch() {
        global $wpdb;
        self::guard('twd_serial_batch');
        $t = TWD_DB::table('serials');
        $new = mb_substr(trim(sanitize_text_field(self::post('new_batch'))), 0, 64);
        $old = mb_substr(trim(sanitize_text_field(self::post('old_batch'))), 0, 64);
        if ($new === '') { self::flash('Γράψτε το όνομα της νέας παρτίδας.', 'error'); self::back('tw-serials', ['batch' => $old ?: null]); }
        if (self::post('scope') === 'all' && $old !== '') {
            $n = (int) $wpdb->query($wpdb->prepare("UPDATE $t SET import_batch = %s WHERE import_batch = %s", $new, $old));
            $what = 'όλοι οι σειριακοί της «' . $old . '»';
        } else {
            $ids = array_values(array_filter(array_map('intval', (array) ($_POST['ids'] ?? []))));
            if (!$ids) { self::flash('Δεν επιλέξατε σειριακούς. Τικάρετε τα κουτάκια στη λίστα.', 'error'); self::back('tw-serials', ['batch' => $old ?: null]); }
            $n = 0;
            foreach (array_chunk($ids, 500) as $chunk) {
                $n += (int) $wpdb->query($wpdb->prepare("UPDATE $t SET import_batch = %s WHERE id IN (" . implode(',', array_fill(0, count($chunk), '%d')) . ')', array_merge([$new], $chunk)));
            }
            $what = count($ids) . ' επιλεγμένοι σειριακοί';
        }
        TWD_DB::log_event('serials_batch', ($old !== '' ? $old . ' → ' : '→ ') . $new . ' (' . $n . ')');
        self::flash('Η παρτίδα άλλαξε σε «' . $new . '» για ' . $n . ' σειριακούς (' . $what . ').');
        self::back('tw-serials', ['batch' => $new]);
    }

    public static function page_claims() { TWD_Claims::page(); }
    public static function handle_claim_update() { TWD_Claims::handle_update(); }
    public static function handle_claim_file() { TWD_Claims::handle_file(); }
    public static function page_terms() { TWD_Terms::page(); }
    public static function handle_terms_save() { TWD_Terms::handle_save(); }
    public static function handle_terms_assign() { TWD_Terms::handle_assign(); }
    public static function handle_terms_delete() { TWD_Terms::handle_delete(); }
    public static function handle_terms_pdf_draft() { TWD_Terms::handle_pdf_draft(); }
    public static function page_partners() { TWD_Partners::page(); }
    public static function handle_partner_save() { TWD_Partners::handle_save(); }
    public static function handle_partner_delete() { TWD_Partners::handle_delete(); }
    public static function handle_partner_import() { TWD_Partners::handle_import(); }
    public static function handle_partner_export() { TWD_Partners::handle_export(); }

    public static function handle_serial_status() {
        global $wpdb;
        self::guard('twd_serial_status');
        $id = (int) self::post('id');
        $to = self::post('to') === 'void' ? 'void' : 'available';
        $from = $to === 'void' ? 'available' : 'void';
        $wpdb->query($wpdb->prepare("UPDATE " . TWD_DB::table('serials') . " SET status = %s WHERE id = %d AND status = %s", $to, $id, $from));
        TWD_DB::log_event('serial_' . $to, '', 0, $id);
        self::flash($to === 'void' ? 'Ο σειριακός ακυρώθηκε και δεν μπορεί να ενεργοποιηθεί.' : 'Ο σειριακός είναι ξανά διαθέσιμος.');
        self::back('tw-serials');
    }

    private static function warranty_from_post() {
        $w = TWD_Warranty::get((int) self::post('id'));
        if (!$w) wp_die('Η εγγύηση δεν βρέθηκε.');
        return $w;
    }

    public static function handle_record_service() {
        self::guard('twd_record_service');
        $w = self::warranty_from_post();
        $no = (int) self::post('milestone_no');
        $date = self::post('performed_date');
        $valid = false;
        foreach (TWD_Schedule::milestones($w->purchase_date, $w->warranty_end) as $m) if ($m['type'] === 'service' && $m['no'] === $no) $valid = true;
        $tech_country = strtoupper(sanitize_key(self::post('technician_country'))) ?: 'GR';
        if (!isset(TWD_Util::countries()[$tech_country])) $tech_country = 'GR';
        [$vat, $vat_err] = self::post('technician_vat') === '' ? ['', null] : TWD_Util::tax_id($tech_country, self::post('technician_vat'));
        if (!$valid || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            self::flash('Μη έγκυρα στοιχεία Service.', 'error');
        } elseif ($vat_err) {
            self::flash('Τεχνικός: ' . $vat_err, 'error');
        } else {
            $rd = self::post('receipt_date');
            $receipt = ['file' => '', 'name' => '', 'number' => sanitize_text_field(self::post('receipt_number')),
                'date' => preg_match('/^\d{4}-\d{2}-\d{2}$/', $rd) ? $rd : null];
            if (!empty($_FILES['receipt_file']['name'])) {
                $file = TWD_Util::store_invoice($_FILES['receipt_file'], 'της απόδειξης');
                if (is_wp_error($file)) { self::flash($file->get_error_message(), 'error'); self::back('tw-warranties', ['view' => $w->id]); }
                $receipt['file'] = $file['file'];
                $receipt['name'] = $file['name'];
            }
            TWD_Warranty::record_service($w, $no, $date, self::post('performed_by') === 'thermic' ? 'thermic' : 'partner',
                sanitize_text_field(self::post('technician')), !empty($_POST['genuine_parts']), sanitize_textarea_field(self::post('notes')), $vat, $receipt, $tech_country);
            self::flash(sprintf('Καταχωρήθηκε το %dο Service.', $no));
        }
        self::back('tw-warranties', ['view' => $w->id]);
    }

    public static function handle_review_service() {
        self::guard('twd_review_service');
        $w = self::warranty_from_post();
        $no = (int) self::post('milestone_no');
        $approve = self::post('decision') === 'approve';
        $note = sanitize_text_field(self::post('note'));
        if (!$approve && $note === '') {
            self::flash('Για απόρριψη χρειάζεται αιτιολογία (θα τη δει ο πελάτης).', 'error');
            self::back('tw-warranties', ['view' => $w->id]);
        }
        $row = TWD_Warranty::review_service($w, $no, $approve, $note);
        if (is_wp_error($row)) {
            self::flash($row->get_error_message(), 'error');
        } else {
            if ($approve) {
                self::flash('Η υποβολή σημειώθηκε ως ελεγμένη.');
            } else {
                $vars = TWD_Warranty::service_vars($w, $row);
                $r = TWD_Messenger::send_template_email($w->email, 'service_rejected', $vars);
                TWD_Messenger::send_template_sms($w->phone_mobile, 'service_rejected', $vars);
                self::flash(sprintf('Η υποβολή απορρίφθηκε. Ο πελάτης μπορεί να υποβάλει ξανά έως %s.', TWD_Util::date_label($row->resubmit_until))
                    . ($r === true ? ' Ο πελάτης ενημερώθηκε με email.' : ' Το email προς τον πελάτη απέτυχε: ' . esc_html($r)), $r === true ? 'success' : 'warning');
            }
        }
        $back = self::post('back');
        if ($back === 'dashboard') self::back('tw-dashboard');
        self::back('tw-warranties', ['view' => $w->id]);
    }

    public static function handle_receipt() {
        if (!current_user_can(self::cap())) wp_die('', 403);
        check_admin_referer('twd_receipt');
        $w = TWD_Warranty::get((int) ($_GET['id'] ?? 0));
        $sv = $w ? TWD_Warranty::service_row((int) ($_GET['service_id'] ?? 0)) : null;
        if ($sv && (int) $sv->warranty_id !== (int) $w->id) $sv = null;
        $path = $sv ? TWD_Util::invoice_path($sv->receipt_file) : '';
        if (!$path) wp_die('Το αρχείο δεν βρέθηκε.');
        TWD_DB::log_event('receipt_downloaded', ['milestone' => (int) $sv->milestone_no], $w->id, $w->serial_id);
        $type = wp_check_filetype($path, TWD_Util::invoice_mimes());
        nocache_headers();
        header('Content-Type: ' . ($type['type'] ?: 'application/octet-stream'));
        header('Content-Disposition: inline; filename="' . rawurlencode($sv->receipt_original_name ?: basename($path)) . '"');
        header('X-Content-Type-Options: nosniff');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }

    public static function handle_delete_service() {
        self::guard('twd_delete_service');
        $w = self::warranty_from_post();
        $sv = TWD_Warranty::service_row((int) self::post('service_id'));
        if ($sv && (int) $sv->warranty_id === (int) $w->id) {
            TWD_Warranty::delete_service($sv);
            TWD_DB::log_event('service_deleted', ['milestone' => (int) $sv->milestone_no, 'date' => $sv->performed_date, 'source' => $sv->source], $w->id, $w->serial_id);
            self::flash('Η καταχώρηση Service διαγράφηκε.');
        }
        self::back('tw-warranties', ['view' => $w->id]);
    }

    public static function handle_set_status() {
        self::guard('twd_set_status');
        $w = self::warranty_from_post();
        $status = self::post('status');
        $note = sanitize_text_field(self::post('note'));
        if (!isset(TWD_Util::status_labels()[$status]) || $note === '') {
            self::flash('Επιλέξτε κατάσταση και συμπληρώστε αιτιολογία.', 'error');
        } elseif ($status === 'locked') {
            TWD_Warranty::lock($w, $note, null);
            self::flash('Η εγγύηση κλειδώθηκε.');
        } else {
            TWD_Warranty::set_status($w, $status, $note);
            self::flash('Η κατάσταση άλλαξε.');
        }
        self::back('tw-warranties', ['view' => $w->id]);
    }

    public static function handle_edit_customer() {
        global $wpdb;
        self::guard('twd_edit_customer');
        $w = self::warranty_from_post();
        if ($w->anonymized_at) self::back('tw-warranties', ['view' => $w->id]);
        $note = sanitize_text_field(self::post('note'));
        $new = [
            'customer_name' => sanitize_text_field(self::post('customer_name')),
            'email' => strtolower(sanitize_email(self::post('email'))),
            'phone_mobile' => TWD_Util::clean_phone(self::post('phone_mobile')),
            'phone_landline' => TWD_Util::clean_phone(self::post('phone_landline')),
            'address' => sanitize_text_field(self::post('address')),
            'postcode' => preg_replace('/\s+/', '', sanitize_text_field(self::post('postcode'))),
            'city' => sanitize_text_field(self::post('city')),
            'partner_vat' => trim(self::post('partner_vat')),
            'partner_country' => isset(TWD_Util::countries()[strtoupper(self::post('partner_country'))]) ? strtoupper(self::post('partner_country')) : 'GR',
            'partner_email' => strtolower(sanitize_email(self::post('partner_email'))),
            'invoice_number' => sanitize_text_field(self::post('invoice_number')),
        ];
        $errors = [];
        if ($note === '') $errors[] = 'συμπληρώστε αιτιολογία';
        if (mb_strlen($new['customer_name']) < 3) $errors[] = 'ονοματεπώνυμο';
        if (!is_email($new['email'])) $errors[] = 'email';
        if (!TWD_Util::valid_mobile($new['phone_mobile'])) $errors[] = 'κινητό';
        if (self::post('phone_landline') !== '' && $new['phone_landline'] === '') $errors[] = 'σταθερό';
        if ($new['partner_vat'] !== '') {
            [$new['partner_vat'], $vat_err] = TWD_Util::tax_id($new['partner_country'], $new['partner_vat']);
            if ($vat_err) $errors[] = 'ΑΦΜ συνεργάτη (' . $vat_err . ')';
        }
        if ($new['partner_email'] !== '' && !is_email($new['partner_email'])) $errors[] = 'email συνεργάτη';
        if ($errors) {
            self::flash('Δεν αποθηκεύτηκε – ελέγξτε: ' . esc_html(implode(', ', $errors)) . '.', 'error');
            self::back('tw-warranties', ['view' => $w->id]);
        }
        $changes = [];
        foreach ($new as $k => $v) {
            if ((string) $w->$k !== (string) $v) $changes[$k] = ['από' => (string) $w->$k, 'σε' => (string) $v];
        }
        if (!$changes) { self::flash('Δεν υπήρξε καμία αλλαγή.', 'info'); self::back('tw-warranties', ['view' => $w->id]); }
        $wpdb->update(TWD_DB::table('warranties'), array_merge(array_intersect_key($new, $changes), ['updated_at' => TWD_DB::now()]), ['id' => $w->id]);
        TWD_DB::log_event('customer_corrected', ['note' => $note, 'changes' => $changes], $w->id, $w->serial_id);
        self::flash(sprintf('Αποθηκεύτηκαν %d αλλαγές.', count($changes)) . (isset($changes['email']) ? ' Το νέο email χρησιμοποιείται από τώρα για ειδοποιήσεις και για τη σύνδεση του πελάτη.' : ''));
        self::back('tw-warranties', ['view' => $w->id]);
    }

    public static function handle_resend_activation() {
        self::guard('twd_resend_activation');
        $w = self::warranty_from_post();
        $r = TWD_Messenger::send_template_email($w->email, 'activation', TWD_Messenger::warranty_vars($w));
        TWD_DB::log_event($r === true ? 'activation_email_resent' : 'activation_email_failed', $r === true ? '' : $r, $w->id, $w->serial_id);
        self::flash($r === true ? 'Το email στάλθηκε.' : 'Αποτυχία: ' . esc_html($r), $r === true ? 'success' : 'error');
        self::back('tw-warranties', ['view' => $w->id]);
    }

    public static function handle_anonymize() {
        self::guard('twd_anonymize');
        $w = self::warranty_from_post();
        TWD_Warranty::anonymize($w);
        self::flash('Τα προσωπικά στοιχεία ανωνυμοποιήθηκαν.');
        self::back('tw-warranties', ['view' => $w->id]);
    }

    public static function handle_invoice() {
        if (!current_user_can(self::cap())) wp_die('', 403);
        check_admin_referer('twd_invoice');
        $w = TWD_Warranty::get((int) ($_GET['id'] ?? 0));
        $path = $w ? TWD_Util::invoice_path($w->invoice_file) : '';
        if (!$path) wp_die('Το αρχείο δεν βρέθηκε.');
        TWD_DB::log_event('invoice_downloaded', '', $w->id, $w->serial_id);
        $type = wp_check_filetype($path, TWD_Util::invoice_mimes());
        nocache_headers();
        header('Content-Type: ' . ($type['type'] ?: 'application/octet-stream'));
        header('Content-Disposition: inline; filename="' . rawurlencode($w->invoice_original_name ?: basename($path)) . '"');
        header('X-Content-Type-Options: nosniff');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }

    public static function handle_run_now() {
        self::guard('twd_run_now');
        $lines = TWD_Cron::run();
        self::flash($lines ? 'Ολοκληρώθηκε: ' . count($lines) . ' ενέργειες.<br>' . implode('<br>', array_map('esc_html', array_slice($lines, 0, 50))) : 'Ολοκληρώθηκε: τίποτα για αποστολή σήμερα.');
        self::back('tw-notifications');
    }

    public static function handle_test_message() {
        self::guard('twd_test_message');
        $key = sanitize_key(self::post('template'));
        $tab = sanitize_key(self::post('tab'));
        $fake = (object) [
            'customer_name' => 'Δοκιμαστικός Πελάτης', 'email' => sanitize_email(self::post('email')), 'serial' => 'TEST-000123',
            'product_name' => 'Δοκιμαστικό προϊόν', 'product_code' => 'TST-01', 'warranty_code' => 'TW-TEST-TEST-TEST',
            'purchase_date' => TWD_Schedule::today(), 'warranty_end' => TWD_Schedule::warranty_end(TWD_Schedule::today()), 'partner_email' => 'partner@example.com',
            'lang' => self::post('tl') === 'en' ? 'en' : 'el',
        ];
        $vars = TWD_Messenger::warranty_vars($fake, ['due_date' => TWD_Util::date_label(TWD_Schedule::add_days(TWD_Schedule::today(), 30)), 'days' => 30, 'years' => 3,
            'milestone_no' => 1, 'grace_end_date' => '—', 'lock_date' => '—', 'code' => '123456', 'minutes' => TWD_OTP::ttl_minutes()]);
        $out = [];
        if (is_email($fake->email)) {
            $r = TWD_Messenger::send_template_email($fake->email, $key, $vars);
            $out[] = 'Email: ' . ($r === true ? 'στάλθηκε' : 'αποτυχία – ' . $r);
        }
        $phone = self::post('phone');
        if ($phone !== '') {
            $t = TWD_Settings::template($key);
            $r = TWD_Messenger::send_sms($phone, TWD_Messenger::render($t['sms'] ?: 'Δοκιμαστικό SMS', $vars));
            $out[] = 'SMS: ' . ($r === true ? 'στάλθηκε' : 'αποτυχία – ' . $r);
        }
        self::flash($out ? esc_html(implode(' | ', $out)) : 'Συμπληρώστε email ή κινητό.', $out ? 'info' : 'error');
        self::back('tw-settings', ['tab' => $tab]);
    }

    /** Exportable columns per list: key => [default header, value]. Order here = order in the file. */
    public static function export_columns($type) {
        if ($type === 'serials') {
            $sl = TWD_Util::serial_status_labels();
            return [
                'serial' => ['Σειριακός αριθμός', function ($r) { return $r->serial_no; }],
                'product_code' => ['Κωδικός προϊόντος', function ($r) { return $r->product_code; }],
                'product_name' => ['Όνομα προϊόντος', function ($r) { return $r->product_name; }],
                'status' => ['Κατάσταση', function ($r) use ($sl) { return $sl[$r->status] ?? $r->status; }],
                'batch' => ['Παρτίδα εισαγωγής', function ($r) { return $r->import_batch; }],
                'created' => ['Καταχώρηση', function ($r) { return TWD_Util::datetime_label($r->created_at); }],
            ];
        }
        $wl = TWD_Util::status_labels();
        return [
            'warranty_code' => ['Κωδικός εγγύησης', function ($r) { return $r->warranty_code; }],
            'serial' => ['Σειριακός αριθμός', function ($r) { return $r->serial; }],
            'product_code' => ['Κωδικός προϊόντος', function ($r) { return $r->product_code; }],
            'product_name' => ['Όνομα προϊόντος', function ($r) { return $r->product_name; }],
            'status' => ['Κατάσταση', function ($r) use ($wl) { return $wl[$r->status] ?? $r->status; }],
            'customer_name' => ['Ονοματεπώνυμο', function ($r) { return $r->customer_name; }],
            'email' => ['Email', function ($r) { return $r->email; }],
            'phone_mobile' => ['Κινητό', function ($r) { return $r->phone_mobile; }],
            'phone_landline' => ['Σταθερό', function ($r) { return $r->phone_landline; }],
            'address' => ['Διεύθυνση', function ($r) { return $r->address; }],
            'postcode' => ['Τ.Κ.', function ($r) { return $r->postcode; }],
            'city' => ['Πόλη', function ($r) { return $r->city; }],
            'partner_vat' => ['ΑΦΜ συνεργάτη', function ($r) { return $r->partner_vat; }],
            'partner_country' => ['Χώρα συνεργάτη', function ($r) { return TWD_Util::countries()[$r->partner_country ?: 'GR'] ?? $r->partner_country; }],
            'partner_email' => ['Email συνεργάτη', function ($r) { return $r->partner_email; }],
            'invoice_number' => ['Αριθμός παραστατικού', function ($r) { return $r->invoice_number; }],
            'purchase_date' => ['Ημερομηνία αγοράς', function ($r) { return TWD_Util::date_label($r->purchase_date); }],
            'warranty_end' => ['Λήξη εγγύησης', function ($r) { return TWD_Util::date_label($r->warranty_end); }],
            'next_service' => ['Επόμενο Service', function ($r) { $n = TWD_Warranty::next_service($r); return $n ? TWD_Util::date_label($n['due']) : ''; }],
            'marketing' => ['Ενημερώσεις & προσφορές', function ($r) { return $r->marketing_opt_in ? 'Ναι' : 'Όχι'; }],
            'lang' => ['Γλώσσα', function ($r) { return TWD_I18n::languages()[$r->lang ?? 'el'] ?? 'Ελληνικά'; }],
            'lock_reason' => ['Λόγος κλειδώματος', function ($r) { return $r->lock_reason; }],
            'created' => ['Ενεργοποίηση', function ($r) { return TWD_Util::datetime_label($r->created_at); }],
        ];
    }

    /** Columns most recently chosen by this user (or all, by default): [ [key, header], ... ]. */
    private static function export_choice($type) {
        $defs = self::export_columns($type);
        $saved = get_user_meta(get_current_user_id(), 'twd_export_' . $type, true);
        $out = [];
        if (is_array($saved) && !empty($saved['cols'])) {
            foreach ($saved['cols'] as $k) if (isset($defs[$k])) $out[] = [$k, ($saved['labels'][$k] ?? '') !== '' ? $saved['labels'][$k] : $defs[$k][0]];
        }
        if (!$out) foreach ($defs as $k => $d) $out[] = [$k, $d[0]];
        return $out;
    }

    /** Columns and headers sent from the export dialog; remembered for this user. */
    private static function export_request($type) {
        $defs = self::export_columns($type);
        $cols = isset($_POST['cols']) && is_array($_POST['cols']) ? array_values(array_intersect(array_map('sanitize_key', wp_unslash($_POST['cols'])), array_keys($defs))) : [];
        if (!$cols) return self::export_choice($type);
        $in = isset($_POST['lbl']) && is_array($_POST['lbl']) ? wp_unslash($_POST['lbl']) : [];
        $labels = [];
        foreach ($defs as $k => $d) {
            $v = isset($in[$k]) ? mb_substr(trim(sanitize_text_field($in[$k])), 0, 60) : '';
            if ($v !== '' && $v !== $d[0]) $labels[$k] = $v;
        }
        update_user_meta(get_current_user_id(), 'twd_export_' . $type, ['cols' => $cols, 'labels' => $labels]);
        $out = [];
        foreach ($cols as $k) $out[] = [$k, $labels[$k] ?? $defs[$k][0]];
        return $out;
    }

    /** "Excel export" button + dialog: pick columns, rename headers. $url carries the list's current filters. */
    private static function export_button($type, $url, $label) {
        $defs = self::export_columns($type);
        $choice = self::export_choice($type);
        $chosen = [];
        foreach ($choice as $c) $chosen[$c[0]] = $c[1];
        $id = 'tw-export-' . $type;
        ?>
        <button type="button" class="page-title-action" data-tw-dialog="<?php echo esc_attr($id); ?>"><?php echo self::icon('download'); // phpcs:ignore ?> <?php echo esc_html($label); ?></button>
        <dialog class="tw-dialog" id="<?php echo esc_attr($id); ?>">
            <form method="post" action="<?php echo esc_url($url); ?>" class="tw-export-form">
                <h2>Εξαγωγή Excel</h2>
                <p class="description">Επιλέξτε ποιες στήλες θα έχει το αρχείο και, αν θέλετε, γράψτε άλλη επικεφαλίδα (π.χ. «Ηλ. ταχυδρομείο» αντί για «Email»). Οι επιλογές σας θυμούνται για την επόμενη φορά. Ισχύουν τα φίλτρα της λίστας.</p>
                <?php if ($type === 'serials') : ?><p class="description">Αν αλλάξετε επικεφαλίδες ή αφαιρέσετε τη στήλη «Σειριακός αριθμός», το αρχείο δεν θα μπορεί να ξαναεισαχθεί όπως είναι.</p><?php endif; ?>
                <p class="tw-export-tools"><button type="button" class="button" data-tw-cols="all">Όλες</button> <button type="button" class="button" data-tw-cols="none">Καμία</button> <button type="button" class="button" data-tw-cols="reset">Επαναφορά προεπιλογών</button></p>
                <div class="tw-export-scroll"><table class="tw-export-cols">
                    <thead><tr><th></th><th>Στήλη</th><th>Επικεφαλίδα στο αρχείο</th></tr></thead>
                    <tbody>
                    <?php foreach ($defs as $k => $d) : ?>
                        <tr>
                            <td><input type="checkbox" name="cols[]" value="<?php echo esc_attr($k); ?>" id="<?php echo esc_attr($id . '-' . $k); ?>" <?php checked(isset($chosen[$k])); ?>></td>
                            <td><label for="<?php echo esc_attr($id . '-' . $k); ?>"><?php echo esc_html($d[0]); ?></label></td>
                            <td><input type="text" name="lbl[<?php echo esc_attr($k); ?>]" value="<?php echo esc_attr(isset($chosen[$k]) && $chosen[$k] !== $d[0] ? $chosen[$k] : ''); ?>" placeholder="<?php echo esc_attr($d[0]); ?>" maxlength="60"></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table></div>
                <p class="tw-dialog-actions"><button type="submit" class="button button-primary"><?php echo self::icon('download'); // phpcs:ignore ?> Λήψη αρχείου</button> <button type="button" class="button" data-tw-close>Άκυρο</button></p>
            </form>
        </dialog>
        <?php
    }

    public static function handle_export() {
        global $wpdb;
        if (!current_user_can(self::cap())) wp_die('', 403);
        check_admin_referer('twd_export');
        @set_time_limit(0);
        $type = self::q('type') === 'serials' ? 'serials' : 'warranties';
        $stamp = current_time('Ymd-His');
        $defs = self::export_columns($type);
        $cols = self::export_request($type);
        $x = new TWD_Xlsx(array_map(function ($c) { return $c[1]; }, $cols));
        $row = function ($r) use ($cols, $defs) {
            return array_map(function ($c) use ($r, $defs) { return (string) call_user_func($defs[$c[0]][1], $r); }, $cols);
        };
        $last = 0;
        if ($type === 'serials') {
            $t = TWD_DB::table('serials');
            $where = ['1=1']; $p = [];
            if (self::q('s') !== '') { $l = '%' . $wpdb->esc_like(self::q('s')) . '%'; $where[] = '(serial_no LIKE %s OR product_name LIKE %s OR product_code LIKE %s)'; array_push($p, $l, $l, $l); }
            if (self::q('status') !== '') { $where[] = 'status = %s'; $p[] = self::q('status'); }
            if (self::q('batch') !== '') { $where[] = 'import_batch = %s'; $p[] = self::q('batch'); }
            do {
                $sql = "SELECT id, serial_no, product_code, product_name, status, import_batch, created_at FROM $t WHERE " . implode(' AND ', $where) . ' AND id > %d ORDER BY id LIMIT 2000';
                $rows = $wpdb->get_results($wpdb->prepare($sql, array_merge($p, [$last])));
                foreach ($rows as $r) { $x->add($row($r)); $last = (int) $r->id; }
            } while (count($rows) === 2000);
            TWD_DB::log_event('serials_exported', ['filters' => array_filter($_GET), 'columns' => count($cols)]);
            $x->download('seiriakoi-' . $stamp . '.xlsx', 'Σειριακοί');
        }
        $where = self::warranty_filters(['s' => self::q('s'), 'status' => self::q('status'), 'expiring' => (int) self::q('expiring'), 'from' => self::q('from'), 'to' => self::q('to')]);
        do {
            $rows = $wpdb->get_results($wpdb->prepare(TWD_Warranty::select_sql() . " WHERE $where AND w.id > %d ORDER BY w.id LIMIT 2000", $last));
            if (in_array('next_service', array_column($cols, 0), true)) TWD_Warranty::preload_services(array_map(function ($r) { return (int) $r->id; }, $rows));
            foreach ($rows as $r) { $x->add($row($r)); $last = (int) $r->id; }
        } while (count($rows) === 2000);
        TWD_DB::log_event('warranties_exported', ['filters' => array_filter($_GET), 'columns' => count($cols)]);
        $x->download('engyiseis-' . $stamp . '.xlsx', 'Εγγυήσεις');
    }
}
